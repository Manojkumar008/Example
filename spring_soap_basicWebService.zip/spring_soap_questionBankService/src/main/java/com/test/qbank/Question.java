package com.test.qbank;

public class Question {

}
