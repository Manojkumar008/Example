package com.test.qbank.service;

import java.util.List;

import com.test.qbank.Question;

public class QBankServiceImpl implements QBankService {

	public Integer addAQuestion(Question q) {
		// TODO Auto-generated method stub
		return null;
	}

	public Question fetchAQuestion(Integer Id) {
		// TODO Auto-generated method stub
		return null;
	}

	public Integer addAQuestionPaper(List<Question> questions) {
		// TODO Auto-generated method stub
		return null;
	}

	public Integer fetchAQuestionPaper(Integer Id) {
		// TODO Auto-generated method stub
		return null;
	}

}
