/**
 * Copyright 2015 Applied Card Technologies Ltd
 */
package net.weareact.app;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.net.URI;

import javax.servlet.FilterRegistration;

import org.eclipse.jetty.server.Connector;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlets.CrossOriginFilter;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.codahale.metrics.health.HealthCheckRegistry;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import io.dropwizard.jersey.setup.JerseyEnvironment;
import io.dropwizard.jetty.MutableServletContextHandler;
import io.dropwizard.jetty.setup.ServletEnvironment;
import io.dropwizard.lifecycle.setup.LifecycleEnvironment;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;
import net.weareact.app.exception.DashboardViewsException;
import net.weareact.common.data.client.ManagedDatastore;
import net.weareact.common.dropwizard.DropwizardConsulService;
import net.weareact.common.dropwizard.config.JwtConfiguration;
import net.weareact.common.dropwizard.security.PublicKeyProvider;
import net.weareact.common.dropwizard.security.PublicKeyProviderException;
import net.weareact.rabbit.RabbitMqConfiguration;

/**
 * @author tripatat
 */
public class DashboardViewsApplicationTest
{
    private static final String               APP_NAME                 = "DashboardViews";
    private static final String               HTTP_PROTOCOL            = "HTTP";
    private static final Integer              PORT                     = 8080;
    private static final String               CONTEXT_PATH             = "/v1";
    private static final String               HOST_NAME                = "hostName";
    private static final String               JWT_SECRET               = "0102030405060708";

    private final Bootstrap                   bootstrap                = mock( Bootstrap.class );
    private final Environment                 environment              = mock( Environment.class );
    private final ObjectMapper                mapper                   = spy( ObjectMapper.class );
    private final JerseyEnvironment           jersey                   = mock( JerseyEnvironment.class );
    private final ServletEnvironment          servlets                 = mock( ServletEnvironment.class );
    private final FilterRegistration.Dynamic  filterReg                = mock( FilterRegistration.Dynamic.class );
    private final HealthCheckRegistry         healthReg                = mock( HealthCheckRegistry.class );
    private final LifecycleEnvironment        mockLifecycleEnvironment = mock( LifecycleEnvironment.class );
    private final DropwizardConsulService     dropwizardConsulService  = mock( DropwizardConsulService.class );
    private final Server                      mockServer               = mock( Server.class );
    private final ManagedDatastore            mockDatastore            = mock( ManagedDatastore.class );
    private final PublicKeyProvider           mockKeyProvider          = mock( PublicKeyProvider.class );

    private final DashboardViewsApplication   application              = new DashboardViewsApplication()
                                                                       {
                                                                           @Override
                                                                           DropwizardConsulService getDropwizardConsulService(
                                                                                   final DashboardViewsConfiguration configuration )
                                                                           {
                                                                               return dropwizardConsulService;
                                                                           }

                                                                           @Override
                                                                           ManagedDatastore getManagedDataStore(
                                                                                   final DashboardViewsConfiguration configuration,
                                                                                   final Environment environment )
                                                                           {
                                                                               return mockDatastore;
                                                                           }

                                                                           @Override
                                                                           PublicKeyProvider getPublicKeyProvider(
                                                                                   final JwtConfiguration configuration )
                                                                                           throws PublicKeyProviderException
                                                                           {
                                                                               return mockKeyProvider;
                                                                           }
                                                                       };
    private final DashboardViewsConfiguration config                   = new DashboardViewsConfiguration();

    /**
     * Setup test details.
     *
     * @throws Exception
     *             when something goes wrong.
     */
    @Before
    public void setUp() throws Exception
    {
        when( environment.servlets() ).thenReturn( servlets );
        when( servlets.addFilter( "CORS", CrossOriginFilter.class ) ).thenReturn( filterReg );
        when( environment.jersey() ).thenReturn( jersey );
        when( environment.healthChecks() ).thenReturn( healthReg );
        when( environment.lifecycle() ).thenReturn( mockLifecycleEnvironment );
        when( environment.getObjectMapper() ).thenReturn( mapper );

        final MutableServletContextHandler mockMutableServletContextHandler = mock(
                MutableServletContextHandler.class );
        when( environment.getApplicationContext() ).thenReturn( mockMutableServletContextHandler );
        when( mockMutableServletContextHandler.getContextPath() ).thenReturn( CONTEXT_PATH );

        final URI mockUri = new URI( HTTP_PROTOCOL, null, HOST_NAME, 0, null, null, null );
        when( mockServer.getURI() ).thenReturn( mockUri );

        final Connector connector = mock( Connector.class );
        when( mockServer.getConnectors() ).thenReturn( new Connector[]
        { connector } );

        final JwtConfiguration jwtConfiguration = new JwtConfiguration();
        config.setJwtConfiguration( jwtConfiguration );
        jwtConfiguration.setEnforceScopes( false );
        doNothing().when( dropwizardConsulService ).registerService(
                DashboardViewsApplication.APP_NAME,
                DashboardViewsApplication.API_VERSION );

        config.setRabbitMq( new RabbitMqConfiguration() );
    }

    /**
     * @throws Exception
     *             Exception
     */
    @Test
    public void testTheMainMethod() throws Exception
    {
        DashboardViewsApplication.main( new String[]
        { "check", "src/main/resources/dashboardviews.yml" } );
    }

    /**
     * Test application fails to run without proper arguments.
     *
     * @throws Exception
     *             Exception
     */
    @Test( expected = DashboardViewsException.class )
    public void testTheMainMethodFails() throws Exception
    {
        DashboardViewsApplication.main( null );
    }

    /**
     * Test name is correct.
     *
     * @throws Exception
     *             when something goes wrong.
     */
    @Test
    public void testGetName() throws Exception
    {
        Assert.assertEquals( APP_NAME, application.getName() );
    }

    /**
     * Test initialization.
     *
     * @throws Exception
     *             when something goes wrong.
     */
    @Test
    @SuppressWarnings( "unchecked" )
    public void testInitialize() throws Exception
    {
        application.initialize( bootstrap );
    }

    /**
     * Test Running the App.
     *
     * @throws Exception
     *             when something goes wrong.
     */
    @Test
    public void testRun() throws Exception
    {
        application.run( config, environment );

        commonRunExpectations();
    }

    /**
     * Test Running the App.
     *
     * @throws Exception
     *             when something goes wrong.
     */
    @Test
    public void testRunWithPrettyPrint() throws Exception
    {
        config.setJsonPrettyPrint( true );
        application.run( config, environment );

        verify( mapper ).enable( SerializationFeature.INDENT_OUTPUT );

        commonRunExpectations();
    }

    private void commonRunExpectations()
    {

    }
}
