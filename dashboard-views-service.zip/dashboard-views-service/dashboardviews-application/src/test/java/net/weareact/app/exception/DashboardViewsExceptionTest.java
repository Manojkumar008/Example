/**
 * Copyright 2015 Applied Card Technologies Ltd
 */
package net.weareact.app.exception;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * @author tripatat
 */
public class DashboardViewsExceptionTest
{
    private final String message = "Something went wrong";

    /**
     * Ensure message is preserved.
     */
    @Test
    public void messageThrowable()
    {
        try
        {
            throw new DashboardViewsException( message );
        }
        catch ( DashboardViewsException ex )
        {
            // Expected
            assertTrue( message.equals( ex.getMessage() ) );
        }
    }

    /**
     * Ensure message and exception cause is preserved.
     */
    @Test
    public void messageThrowableCause()
    {
        Exception cause = new Exception();
        try
        {
            throw new DashboardViewsException( message, cause );
        }
        catch ( DashboardViewsException ex )
        {
            // Expected
            assertTrue( message.equals( ex.getMessage() ) );
            assertTrue( cause.equals( ex.getCause() ) );
        }
    }
}
