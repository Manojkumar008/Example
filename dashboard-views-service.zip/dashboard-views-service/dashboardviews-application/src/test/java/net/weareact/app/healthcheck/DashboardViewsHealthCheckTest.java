/**
 * Copyright 2015 Applied Card Technologies Ltd
 */
package net.weareact.app.healthcheck;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.codahale.metrics.health.HealthCheck.Result;

/**
 * @author tripatat
 */
public class DashboardViewsHealthCheckTest
{

    /**
     * Test service healthy.
     *
     * @throws Exception
     *             when something goes wrong.
     */
    @Test
    public void testServiceIsHealthy() throws Exception
    {
        Result expectedResult = Result.healthy();
        assertEquals( expectedResult, new DashboardViewsHealthCheck().check() );
    }
}
