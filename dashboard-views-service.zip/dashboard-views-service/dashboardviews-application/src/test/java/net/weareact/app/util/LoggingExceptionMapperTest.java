/**
 * Copyright 2015 Applied Card Technologies Ltd
 */
package net.weareact.app.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import javax.ws.rs.core.Response;

import org.apache.http.HttpStatus;
import org.junit.Before;
import org.junit.Test;

import net.weareact.api.ApiException;
import net.weareact.api.NotFoundException;
import net.weareact.model.ServiceError;

/**
 * @author tripatat
 */
public class LoggingExceptionMapperTest
{
    private LoggingExceptionMapper<Exception> mapper;

    @Before
    public void setUp() throws Exception
    {
        mapper = new LoggingExceptionMapper<Exception>()
        {
        };
    }

    @Test
    public void testGeneralException() throws Exception
    {
        final Response response = mapper.toResponse( new Exception( "It broke" ) );

        assertEquals( HttpStatus.SC_INTERNAL_SERVER_ERROR, response.getStatus() );
        final ServiceError responseError = ( ServiceError ) response.getEntity();
        assertEquals( String.valueOf( HttpStatus.SC_INTERNAL_SERVER_ERROR ), responseError.getErrorCode() );
        assertTrue( responseError.getUserMessage().contains( "An unexpected error occurred." ) );
        assertTrue(
                responseError
                        .getDeveloperMessage()
                        .contains( "Details about this error available in logs using unique reference: " ) );
    }

    @Test
    public void testApiException() throws Exception
    {
        final String msg = "Not allowed.";
        final Response response = mapper.toResponse( new ApiException( HttpStatus.SC_FORBIDDEN, msg ) );

        assertEquals( HttpStatus.SC_FORBIDDEN, response.getStatus() );
        final ServiceError responseError = ( ServiceError ) response.getEntity();
        assertEquals( String.valueOf( HttpStatus.SC_FORBIDDEN ), responseError.getErrorCode() );
        assertTrue( responseError.getUserMessage().contains( msg ) );
        assertTrue(
                responseError
                        .getDeveloperMessage()
                        .contains( "Details about this error available in logs using unique reference: " ) );
    }

    @Test
    public void testNotFoundException() throws Exception
    {
        final String msg = "Couldn't find it :(";
        final Response response = mapper.toResponse( new NotFoundException( msg ) );

        assertEquals( HttpStatus.SC_NOT_FOUND, response.getStatus() );
        final ServiceError responseError = ( ServiceError ) response.getEntity();
        assertEquals( String.valueOf( HttpStatus.SC_NOT_FOUND ), responseError.getErrorCode() );
        assertTrue( responseError.getUserMessage().contains( msg ) );
        assertNull( responseError.getDeveloperMessage() );
    }

}
