/**
 * Copyright 2015 Applied Card Technologies Ltd
 */
package net.weareact.app.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import javax.ws.rs.core.Response;

import org.apache.http.HttpStatus;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;

import net.weareact.model.ServiceError;

/**
 * @author tripatat
 */
public class JsonProcessingExceptionMapperTest
{
    private JsonProcessingExceptionMapper mapper;

    @Before
    public void setUp() throws Exception
    {
        mapper = new JsonProcessingExceptionMapper();
    }

    @Test
    public void testJsonGenerationError() throws Exception
    {
        final Response response = mapper.toResponse( new JsonGenerationException( "It broke" ) );

        assertEquals( HttpStatus.SC_INTERNAL_SERVER_ERROR, response.getStatus() );
        final ServiceError responseError = ( ServiceError ) response.getEntity();
        assertEquals( String.valueOf( HttpStatus.SC_INTERNAL_SERVER_ERROR ), responseError.getErrorCode() );
        assertTrue( responseError.getUserMessage().contains( "Server error while generating JSON response" ) );
        assertTrue(
                responseError
                        .getDeveloperMessage()
                        .contains( "Details about this error available in logs using unique reference: " ) );
    }

    @Test
    public void testJsonMappingErrorNoArgsConstructor() throws Exception
    {
        final Response response = mapper
                .toResponse( new JsonMappingException( "No suitable constructor found while doing something" ) );

        assertEquals( HttpStatus.SC_INTERNAL_SERVER_ERROR, response.getStatus() );
        final ServiceError responseError = ( ServiceError ) response.getEntity();
        assertEquals( String.valueOf( HttpStatus.SC_INTERNAL_SERVER_ERROR ), responseError.getErrorCode() );
        assertTrue( responseError.getUserMessage().contains( "Server error while generating JSON response" ) );
        assertTrue(
                responseError
                        .getDeveloperMessage()
                        .contains( "Details about this error available in logs using unique reference: " ) );
    }

    @Test
    public void testJsonMappingError() throws Exception
    {
        final Response response = mapper.toResponse( new JsonMappingException( "It broke. Again." ) );

        assertEquals( HttpStatus.SC_BAD_REQUEST, response.getStatus() );
        final ServiceError responseError = ( ServiceError ) response.getEntity();
        assertEquals( String.valueOf( HttpStatus.SC_BAD_REQUEST ), responseError.getErrorCode() );
        assertTrue(
                responseError
                        .getUserMessage()
                        .contains( "Object provided was not valid, please verify request contents and try again." ) );
        assertTrue(
                responseError
                        .getDeveloperMessage()
                        .contains( "Details about this error available in logs using unique reference: " ) );
    }
}
