/**
 * Copyright 2015 Applied Card Technologies Ltd
 */
package net.weareact.app.util;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;

import org.apache.http.HttpStatus;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonProcessingException;

import net.weareact.model.ServiceError;

/**
 * Ensures Exceptions that are to do with JSON serialisation are returned in the format defined by the ServiceError
 * class.
 *
 * @author tripatat
 */
public class JsonProcessingExceptionMapper extends AbstractExceptionMapper<JsonProcessingException>
        implements ExceptionMapper<JsonProcessingException>
{
    private static final String SERVER_ERROR_GENERATING_JSON = "Server error while generating JSON response";

    @Override
    public Response toResponse( final JsonProcessingException exception )
    {
        final ServiceError error = new ServiceError()
                .errorCode( String.valueOf( HttpStatus.SC_BAD_REQUEST ) )
                .userMessage( "Object provided was not valid, please verify request contents and try again." );

        // If the error is in the JSON generation, it's a server error.
        if ( exception instanceof JsonGenerationException )
        {
            error.setErrorCode( String.valueOf( HttpStatus.SC_INTERNAL_SERVER_ERROR ) );
            error.setUserMessage( SERVER_ERROR_GENERATING_JSON );
            logError( exception, error );

            return Response.serverError().entity( error ).build();
        }

        /*
         * If we can't deserialize the JSON because someone forgot a no-arg constructor, it's a server error and we
         * should inform the developer.
         */
        final String message = exception.getOriginalMessage();
        if ( message.startsWith( "No suitable constructor found" ) )
        {
            error.setErrorCode( String.valueOf( HttpStatus.SC_INTERNAL_SERVER_ERROR ) );
            error.setUserMessage( SERVER_ERROR_GENERATING_JSON );
            logError( exception, error );
            return Response.serverError().entity( error ).build();
        }

        // Otherwise, assume user error.
        logWarning( exception, error );

        return Response.status( HttpStatus.SC_BAD_REQUEST ).entity( error ).build();
    }

}
