/**
 * Copyright 2015 Applied Card Technologies Ltd
 */
package net.weareact.app.util;

import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.weareact.model.ServiceError;

public abstract class AbstractExceptionMapper<E extends Throwable>
{
    private static final Logger LOGGER = LoggerFactory.getLogger( AbstractExceptionMapper.class.getName() );

    /**
     * @param exception
     *            The exception.
     * @param error
     *            The ServiceError Object.
     */
    protected void logError( final E exception, final ServiceError error )
    {
        final UUID uuid = developerMsg( error );
        LOGGER.error( "Log ref: " + uuid.toString(), exception );
    }

    /**
     * @param exception
     *            The exception.
     * @param error
     *            The ServiceError Object.
     */
    protected void logWarning( final E exception, final ServiceError error )
    {
        final UUID uuid = developerMsg( error );
        LOGGER.warn( "Log ref: " + uuid.toString(), exception );
    }

    /**
     * @param error
     *            The error to set the developer message on.
     * @return The Unique logging identifier.
     */
    protected UUID developerMsg( final ServiceError error )
    {
        final UUID uuid = UUID.randomUUID();
        error.setDeveloperMessage(
                "Details about this error available in logs using unique reference: " + uuid.toString() );
        return uuid;
    }
}
