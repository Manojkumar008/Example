/* **************************************************************************
 *             Copyright 2015 Applied Card Technologies Ltd
 ****************************************************************************/
package net.weareact.app.healthcheck;

import com.codahale.metrics.health.HealthCheck;

/**
 * Default DashboardViews health check.
 *
 * @author tripatat
 */
@SuppressWarnings( "PMD.SignatureDeclareThrowsException" )
public class DashboardViewsHealthCheck extends HealthCheck
{
    @Override
    protected Result check() throws Exception
    {
        return Result.healthy();
    }
}
