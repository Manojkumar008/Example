/**
 * Copyright 2015 Applied Card Technologies Ltd
 */
package net.weareact.app.exception;

/**
 * General DashboardViews Exception.
 *
 * @author tripatat
 */
public class DashboardViewsException extends Exception
{

    /**
     * @param message
     *            Message for exception
     */
    public DashboardViewsException( final String message )
    {
        super( message );
    }

    /**
     * @param message
     *            Message for exception
     * @param throwable
     *            Exception cause
     */
    public DashboardViewsException( final String message, final Throwable throwable )
    {
        super( message, throwable );
    }

}
