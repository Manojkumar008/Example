/**
 * Copyright 2015 Applied Card Technologies Ltd
 */
package net.weareact.app;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import net.weareact.common.dropwizard.config.ActConfiguration;
import net.weareact.rabbit.RabbitMqConfiguration;

/**
 * DashboardViews Dropwizard application configuration.
 *
 * @author tripatat
 */
public class DashboardViewsConfiguration extends ActConfiguration
{
    @JsonProperty( "rabbitmq" )
    private RabbitMqConfiguration rabbitMq;

    @NotNull
    private Long                  defaultOffset;

    @NotNull
    private Long                  defaultLimit;

    /**
     * @return the defaultOffset
     */
    public Long getDefaultOffset()
    {
        return defaultOffset;
    }

    /**
     * @param defaultOffset
     *            the defaultOffset to set
     */
    public void setDefaultOffset( final Long defaultOffset )
    {
        this.defaultOffset = defaultOffset;
    }

    /**
     * @return the defaultLimit
     */
    public Long getDefaultLimit()
    {
        return defaultLimit;
    }

    /**
     * @param defaultLimit
     *            the defaultLimit to set
     */
    public void setDefaultLimit( final Long defaultLimit )
    {
        this.defaultLimit = defaultLimit;
    }

    @Override
    protected String getDefaultAppName()
    {
        return DashboardViewsApplication.APP_NAME;
    }

    /**
     * @return rabbitMQ configuration
     */
    public RabbitMqConfiguration getRabbitMq()
    {
        return rabbitMq;
    }

    /**
     * @param rabbitMq
     *            configuration for rabbitMQ
     */
    public void setRabbitMq( final RabbitMqConfiguration rabbitMq )
    {
        this.rabbitMq = rabbitMq;
    }
}
