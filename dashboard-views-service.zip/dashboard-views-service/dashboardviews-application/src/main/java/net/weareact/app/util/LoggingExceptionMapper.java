/**
 * Copyright 2015 Applied Card Technologies Ltd
 */
package net.weareact.app.util;

import java.util.UUID;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.weareact.api.ApiException;
import net.weareact.api.NotFoundException;
import net.weareact.model.ServiceError;

/**
 * Provides Exceptions that are thrown to the API in the manner defined by the ServiceError model. Ensures Any
 * non-specific ApiException will be reported as a general failure.
 *
 * @param <E>
 *            Exception type.
 * @author tripatat
 */
public abstract class LoggingExceptionMapper<E extends Throwable> implements ExceptionMapper<E>
{
    private static final Logger LOGGER = LoggerFactory.getLogger( LoggingExceptionMapper.class.getName() );

    @Override
    public Response toResponse( final E exception )
    {
        final ServiceError error = new ServiceError().userMessage( "An unexpected error occurred." );
        int intError = HttpStatus.SC_INTERNAL_SERVER_ERROR;

        if ( exception instanceof ApiException )
        {
            intError = ( ( ApiException ) exception ).getCode();
            error.setUserMessage( exception.getMessage() );
        }

        error.setErrorCode( String.valueOf( intError ) );

        if ( !( exception instanceof NotFoundException ) )
        {
            final UUID uuid = UUID.randomUUID();
            LOGGER.error( "Log ref: " + uuid.toString(), exception );
            error.developerMessage(
                    "Details about this error available in logs using unique reference: " + uuid.toString() );
        }

        return Response.status( intError ).entity( error ).build();
    }
}
