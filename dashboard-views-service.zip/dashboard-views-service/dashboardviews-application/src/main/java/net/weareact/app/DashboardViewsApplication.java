/**
 * Copyright 2015 Applied Card Technologies Ltd
 */
package net.weareact.app;

import static net.weareact.common.util.CorrelationIdUtils.CORRELATION_ID_HEADER;
import static net.weareact.common.util.CorrelationIdUtils.generateCorrelationId;

import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import javax.ws.rs.Path;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.container.ContainerResponseFilter;

import org.glassfish.hk2.utilities.binding.AbstractBinder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.codahale.metrics.health.HealthCheck;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JSR310Module;
import com.google.common.reflect.ClassPath;

import io.dropwizard.Application;
import io.dropwizard.Configuration;
import io.dropwizard.auth.AuthFactory;
import io.dropwizard.configuration.ConfigurationException;
import io.dropwizard.server.DefaultServerFactory;
import io.dropwizard.server.ServerFactory;
import io.dropwizard.server.SimpleServerFactory;
import io.dropwizard.setup.Environment;
import io.swagger.config.FilterFactory;
import io.swagger.models.auth.SecuritySchemeDefinition;
import net.weareact.api.ApiInfoProvider;
import net.weareact.api.impl.config.ConfigurationLoader;
import net.weareact.api.impl.config.DashBoardApiConfiguration;
import net.weareact.app.exception.DashboardViewsException;
import net.weareact.app.healthcheck.DashboardViewsHealthCheck;
import net.weareact.auditservice.client.AuditService;
import net.weareact.auditservice.client.Auditor;
import net.weareact.auditservice.client.JacksonJsonAuditRecordSerialiser;
import net.weareact.auditservice.client.RabbitMqAuditService;
import net.weareact.auditservice.client.model.Source;
import net.weareact.common.data.client.ManagedDatastore;
import net.weareact.common.data.client.factory.ManagedDatastoreFactory;
import net.weareact.common.data.client.factory.ManagedDatastoreFactoryException;
import net.weareact.common.dropwizard.DropwizardConsulService;
import net.weareact.common.dropwizard.DropwizardSwaggerInjector;
import net.weareact.common.dropwizard.config.JwtConfiguration;
import net.weareact.common.dropwizard.exception.ServiceDiscoveryException;
import net.weareact.common.dropwizard.filter.InternalParameterFilter;
import net.weareact.common.dropwizard.security.ACTClaims;
import net.weareact.common.dropwizard.security.ACTClaimsAuthenticator;
import net.weareact.common.dropwizard.security.JWTAuthFactory;
import net.weareact.common.dropwizard.security.JWTTokenExtractor;
import net.weareact.common.dropwizard.security.JWTTokenVerifierPublicKey;
import net.weareact.common.dropwizard.security.PublicKeyProvider;
import net.weareact.common.dropwizard.security.PublicKeyProviderException;
import net.weareact.common.dropwizard.security.PublicKeyProviderJKS;
import net.weareact.common.dropwizard.security.ScopedResourceInterceptionServiceBinder;
import net.weareact.common.exceptionhandling.BadParameterExceptionMapper;
import net.weareact.common.exceptionhandling.BadRequestExceptionMapper;
import net.weareact.common.exceptionhandling.ConstraintViolationExceptionMapper;
import net.weareact.common.exceptionhandling.ForbiddenExceptionMapper;
import net.weareact.common.exceptionhandling.GeneralExceptionMapper;
import net.weareact.common.exceptionhandling.JettyNotFoundExceptionMapper;
import net.weareact.common.exceptionhandling.JsonProcessingExceptionMapper;
import net.weareact.common.exceptionhandling.NotAllowedExceptionMapper;
import net.weareact.common.exceptionhandling.NotAuthorizedExceptionMapper;
import net.weareact.common.exceptionhandling.QueryParamExceptionMapper;
import net.weareact.common.jackson.ModuleFactory;
import net.weareact.common.util.CorrelationIdUtils.IdType;
import net.weareact.correlation.CorrelationServicePlugin;
import net.weareact.rabbit.RabbitManager;
import net.weareact.rabbit.RabbitServicePlugin;
import net.weareact.rabbit.notifier.MessageNotifier;

/**
 * @author tripatat
 */
public class DashboardViewsApplication extends Application<DashboardViewsConfiguration>
{
    public static final String   APP_NAME      = "DashboardViews";
    public static final String   API_VERSION   = "v1";
    public static final String   API_BASE_PATH = "/" + API_VERSION;

    private static final Logger  LOGGER        = LoggerFactory.getLogger( DashboardViewsApplication.class.getName() );
    private static final String  API_PKG       = "net.weareact.api";
    private static final boolean ENABLE_CORS   = true;

    /**
     * Main application entry point.
     *
     * @param args
     *            Dropwizard entry points
     * @throws DashboardViewsException
     *             When something goes wrong
     */
    public static void main( final String[] args ) throws DashboardViewsException

    {
        try
        {
            new DashboardViewsApplication().run( args );
        }
        catch ( Exception ex )
        {
            throw new DashboardViewsException( "Unable to run " + APP_NAME + " application.", ex );
        }
    }

    @Override
    public String getName()
    {
        return APP_NAME;
    }

    @Override
    public void run( final DashboardViewsConfiguration configuration, final Environment environment )
            throws IOException,
            InstantiationException,
            IllegalAccessException,
            ManagedDatastoreFactoryException,
            PublicKeyProviderException,
            ConfigurationException

    {
        new CorrelationServicePlugin().register( configuration, environment );

        new RabbitServicePlugin().register( configuration, environment );

        registerJWTAuthenticator( configuration.getJwtConfiguration(), environment );

        registerExceptionMappers( configuration, environment );

        registerFilters( environment );

        if ( configuration.isRegisterWithConsul() )
        {
            registerService( configuration );
        }

        // locate and register binders
        final Set<ClassPath.ClassInfo> serviceBindModuleClassInfos = ClassPath
                .from( Thread.currentThread().getContextClassLoader() )
                .getTopLevelClasses( API_PKG + ".bind" );

        for ( ClassPath.ClassInfo serviceBindModuleClassInfo : serviceBindModuleClassInfos )
        {
            Class<?> serviceBindModuleClass = serviceBindModuleClassInfo.load();

            if ( AbstractBinder.class.isAssignableFrom( serviceBindModuleClass ) )
            {
                environment.jersey().register( serviceBindModuleClass.newInstance() );
            }
        }

        // Register default offset and limit for use in the resource / pagination.
        environment.jersey().register( new AbstractBinder()
        {
            @Override
            protected void configure()
            {
                bind( configuration.getDefaultLimit() ).to( Long.class ).named( "defaultLimit" );
                bind( configuration.getDefaultOffset() ).to( Long.class ).named( "defaultOffset" );
            }
        } );

        // setup internal configuration File
        ConfigurationLoader configurationLoader = new ConfigurationLoader( new DashBoardApiConfiguration() );
        environment.lifecycle().manage( configurationLoader );

        if ( configurationLoader.getDashBoardApiConfiguration() != null )
        {
            environment.jersey().register( new AbstractBinder()
            {
                @Override
                protected void configure()
                {
                    bind( configurationLoader.getDashBoardApiConfiguration() ).to( DashBoardApiConfiguration.class );
                }
            } );
        }

        environment.getObjectMapper().registerModule( new JSR310Module() );
        environment.getObjectMapper().disable( SerializationFeature.WRITE_DATES_AS_TIMESTAMPS );
        environment.getObjectMapper().registerModule( ModuleFactory.buildZoneDateTimeModule() );
        environment.getObjectMapper().setSerializationInclusion( JsonInclude.Include.NON_NULL );

        if ( configuration.isJsonPrettyPrint() )
        {
            environment.getObjectMapper().enable( SerializationFeature.INDENT_OUTPUT );
        }

        environment.jersey().register( new AbstractBinder()
        {
            @Override
            protected void configure()
            {
                bind( environment.getObjectMapper() ).to( ObjectMapper.class );
            }
        } );

        final AuditService auditService = getAuditService( configuration, environment );
        final Auditor auditor = registerAuditor( auditService, environment );

        environment.jersey().register( new AbstractBinder()
        {
            @Override
            protected void configure()
            {
                bind( auditor ).to( Auditor.class );
            }
        } );

        // locate and register resources
        final Set<ClassPath.ClassInfo> apiClassInfos = ClassPath
                .from( Thread.currentThread().getContextClassLoader() )
                .getTopLevelClasses( API_PKG );

        for ( final ClassPath.ClassInfo apiClassInfo : apiClassInfos )
        {
            final Class<?> apiClass = apiClassInfo.load();

            if ( apiClass.isAnnotationPresent( Path.class ) )
            {
                environment.jersey().register( apiClass );
            }
        }

        // Inject Swagger Generation
        new DropwizardSwaggerInjector().setup(
                environment,
                ENABLE_CORS,
                API_BASE_PATH,
                API_PKG,
                ApiInfoProvider.getApiSwaggerInfo(),
                getSecurityDefinitions() );

        // Hide any internal parameters from swagger output
        FilterFactory.setFilter( new InternalParameterFilter() );

        final HealthCheck healthCheck = new DashboardViewsHealthCheck();
        environment.healthChecks().register( "application", healthCheck );
    }

    private void registerService( final DashboardViewsConfiguration configuration )
    {
        try
        {
            final DropwizardConsulService dcs = getDropwizardConsulService( configuration );
            dcs.registerService( configuration.getApplicationName(), API_VERSION );

            Runtime.getRuntime().addShutdownHook( new Thread()
            {
                @Override
                public void run()
                {
                    dcs.deRegisterService();
                    LOGGER.info( "--- " + APP_NAME + " Shutdown ---" );
                }
            } );
        }
        catch ( Exception ex )
        {
            LOGGER.error( "Cannot register service: " + ex );
        }
    }

    /**
     * @param configuration
     *            Application configuration.
     * @param environment
     *            Dropwizard environment.
     */
    private void registerExceptionMappers( final Configuration configuration, final Environment environment )
    {
        // Disable default dropwizard mappers being added automatically as some are overridden.
        final ServerFactory serverFactory = configuration.getServerFactory();
        if ( serverFactory instanceof DefaultServerFactory )
        {
            ( ( DefaultServerFactory ) serverFactory ).setRegisterDefaultExceptionMappers( false );
        }
        else if ( serverFactory instanceof SimpleServerFactory )
        {
            ( ( SimpleServerFactory ) serverFactory ).setRegisterDefaultExceptionMappers( false );
        }

        // Register the custom exception mappers
        environment.jersey().register( new GeneralExceptionMapper( APP_NAME ) );
        environment.jersey().register( new JsonProcessingExceptionMapper( APP_NAME ) );
        environment.jersey().register( new JettyNotFoundExceptionMapper( APP_NAME ) );
        environment.jersey().register( new QueryParamExceptionMapper( APP_NAME ) );
        environment.jersey().register( new ConstraintViolationExceptionMapper( APP_NAME ) );
        environment.jersey().register( new BadParameterExceptionMapper( APP_NAME ) );
        environment.jersey().register( new NotAuthorizedExceptionMapper( APP_NAME ) );
        environment.jersey().register( new ForbiddenExceptionMapper( APP_NAME ) );
        environment.jersey().register( new NotAllowedExceptionMapper( APP_NAME ) );
        environment.jersey().register( new BadRequestExceptionMapper( APP_NAME ) );
    }

    private void registerFilters( final Environment environment )
    {
        environment.jersey().register( new ContainerRequestFilter()
        {

            @Override
            public void filter( final ContainerRequestContext requestContext ) throws IOException
            {
                final Optional<Map.Entry<String, List<String>>> header = requestContext
                        .getHeaders()
                        .entrySet()
                        .stream()
                        .filter( hdr -> CORRELATION_ID_HEADER.equals( hdr.getKey() ) )
                        .findAny();
                if ( !header.isPresent() )
                {
                    requestContext.getHeaders().add( CORRELATION_ID_HEADER, generateCorrelationId( IdType.MISSING ) );
                }
            }

        } );

        environment.jersey().register( new ContainerResponseFilter()
        {
            @Override
            public void filter(
                    final ContainerRequestContext requestContext,
                    final ContainerResponseContext responseContext ) throws IOException
            {
                final Optional<Map.Entry<String, List<String>>> header = requestContext
                        .getHeaders()
                        .entrySet()
                        .stream()
                        .filter( hdr -> CORRELATION_ID_HEADER.equals( hdr.getKey() ) )
                        .findAny();
                if ( !header.isPresent() || ( header.isPresent() && header.get().getValue().isEmpty() ) )
                {
                    responseContext.getHeaders().add( CORRELATION_ID_HEADER, generateCorrelationId( IdType.MISSING ) );
                }
                else
                {
                    responseContext.getHeaders().add( header.get().getKey(), header.get().getValue().get( 0 ) );
                }
            }
        } );
    }

    /**
     * @return Swagger security definitions for the API.
     */
    private Map<String, SecuritySchemeDefinition> getSecurityDefinitions()
    {
        final Map<String, SecuritySchemeDefinition> securityDefinitions = new HashMap<>();

        /*
         * Add security definitions here. If there are none, you can remove this method and omit the parameter from the
         * DropwizardSwaggerInjector constructor call.
         */

        return securityDefinitions;
    }

    /**
     * @param configuration
     *            Dropwizard Configuration.
     * @param environment
     *            Dropwizard environment.
     * @return Managed data store
     * @throws ManagedDatastoreFactoryException
     *             If it fails to create the datastore.
     */
    ManagedDatastore getManagedDataStore(
            final DashboardViewsConfiguration configuration,
            final Environment environment ) throws ManagedDatastoreFactoryException

    {
        return new ManagedDatastoreFactory().make( "elasticsearch", configuration.getDatastore(), environment );
    }

    /**
     * @param configuration
     *            Dropwizard Configuration.
     * @return Dropwizard Consul Service instance.
     * @throws ServiceDiscoveryException
     *             If it fails to initialise the Consul Service instance correctly.
     */
    DropwizardConsulService getDropwizardConsulService( final DashboardViewsConfiguration configuration )
            throws ServiceDiscoveryException

    {
        return new DropwizardConsulService( configuration.getConsulServer(), configuration );
    }

    /**
     * @param configuration
     *            Dropwizard Configuration.
     * @param environment
     *            Dropwizard Environment.
     */
    private void registerJWTAuthenticator( final JwtConfiguration configuration, final Environment environment )
            throws PublicKeyProviderException

    {
        environment.jersey().register( new AbstractBinder()
        {
            @Override
            protected void configure()
            {
                bind( API_PKG ).to( String.class ).named( "ApiPackageName" );
            }
        } );

        PublicKeyProvider provider = getPublicKeyProvider( configuration );

        environment.jersey().register( AuthFactory.binder(
                new JWTAuthFactory<>(
                        new ACTClaimsAuthenticator(),
                        ACTClaims.class,
                        new JWTTokenExtractor(),
                        new JWTTokenVerifierPublicKey( provider ) ) ) );

        if ( configuration.isEnforceScopes() )
        {
            environment.jersey().register( new ScopedResourceInterceptionServiceBinder() );
        }
    }

    PublicKeyProvider getPublicKeyProvider( final JwtConfiguration configuration ) throws PublicKeyProviderException
    {
        PublicKeyProvider provider;

        try
        {
            final KeyStore keyStore = KeyStore.getInstance( "JKS" );
            keyStore.load(
                    new FileInputStream( configuration.getKeyStorePath() ),
                    configuration.getKeyStorePassword().toCharArray() );

            provider = new PublicKeyProviderJKS( keyStore );
        }
        catch ( CertificateException | IOException | KeyStoreException | NoSuchAlgorithmException ex )
        {
            throw new PublicKeyProviderException( ex );
        }

        return provider;
    }

    private Auditor registerAuditor( final AuditService auditService, final Environment environment )
    {
        final Source source = new Source();
        source.setAppName( APP_NAME );
        source.setOsUser( System.getProperty( "user.name" ) );

        return new Auditor( auditService, source );
    }

    AuditService getAuditService( final DashboardViewsConfiguration configuration, final Environment environment )

    {
        final MessageNotifier messageNotifier = RabbitManager.getMessageNotifier( configuration.getRabbitMq() );

        return new RabbitMqAuditService(
                messageNotifier,
                new JacksonJsonAuditRecordSerialiser( environment.getObjectMapper() ),
                configuration.getRabbitMq().getRoutingKeyPrefix() );
    }
}
