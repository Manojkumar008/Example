package net.weareact.api.bind;

import org.glassfish.hk2.utilities.binding.AbstractBinder;

import net.weareact.api.DashboardAggregationApiService;
import net.weareact.api.impl.DashboardAggregationApiServiceImpl;

/**
 * @author Auto-generated
 */
public class DashboardAggregationApiBinder extends AbstractBinder
{
    @Override
    protected void configure()
    {
        bind( DashboardAggregationApiServiceImpl.class ).to( DashboardAggregationApiService.class );
    }
}
