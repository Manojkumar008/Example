package net.weareact.api.bind;

import org.glassfish.hk2.utilities.binding.AbstractBinder;

import net.weareact.api.DashboardViewsApiService;
import net.weareact.api.impl.DashboardViewsApiServiceImpl;

/**
 * @author Auto-generated
 */
public class DashboardViewsApiBinder extends AbstractBinder
{
    @Override
    protected void configure()
    {
        bind( DashboardViewsApiServiceImpl.class ).to( DashboardViewsApiService.class );
    }
}
