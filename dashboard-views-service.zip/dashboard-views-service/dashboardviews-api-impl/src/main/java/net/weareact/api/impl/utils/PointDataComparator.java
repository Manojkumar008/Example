package net.weareact.api.impl.utils;

import java.util.Comparator;

import net.weareact.model.PointData;

public class PointDataComparator implements Comparator<PointData>
{

    @Override
    public int compare( PointData p1, PointData p2 )
    {

        return p1.getPointKey().get( "en" ).compareTo( p2.getPointKey().get( "en" ) );
    }

}
