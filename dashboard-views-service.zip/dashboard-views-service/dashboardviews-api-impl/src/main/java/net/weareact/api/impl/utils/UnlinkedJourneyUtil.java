package net.weareact.api.impl.utils;

import java.net.URLEncoder;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.JsonNode;

import net.weareact.api.impl.GraphDataCreatorFromJourneysSummary;
import net.weareact.api.impl.config.DashboardConfigurationUtil;
import net.weareact.common.dropwizard.security.ACTClaims;
import net.weareact.common.dropwizard.security.ResourceLink;
import net.weareact.common.exceptionhandling.BadParameterException;
import net.weareact.financial.model.FinancialPeriod;
import net.weareact.financial.model.FinancialPeriodsResponse;
import net.weareact.journeys.model.GroupSummary;
import net.weareact.journeys.model.SummaryResponse;
import net.weareact.model.GraphDataPoint;
import net.weareact.model.PointData;
import net.weareact.model.ServiceError;

public class UnlinkedJourneyUtil
{

    private static final Logger         LOGGER               = LoggerFactory
                                                                     .getLogger(
                                                                             DashboardViewsImplUtil.class.getName() );

    private static final String         EQUALS_OPERATOR      = "=";

    private static final String         HTTP_HEADER_JWT      = "X-JWT-Assertion";
    private static final String         DATA_POINT_LEGEND    = "dataPointLegend";
    private static final String         POINT_LEGEND         = "pointLegend";

    GraphDataCreatorFromJourneysSummary creator              = new GraphDataCreatorFromJourneysSummary();
    GroupSummary                        averageSummary;
    Map<String, Integer>                totalAverageSummary  = new HashMap<>();
    private static final String         JWT_ASSERTION_HEADER = "X-JWT-Assertion";

    private static final String         UNALLOCATED          = "unallocated";
    private static Client               apiClient            = ClientBuilder.newClient();

    /**
     * This method fetch the unlinked journey graph data based on the financial period and journey summary
     *
     * @param xJWTAssertion
     * @param q
     * @param graphConfig
     * @param claims
     * @return
     * @throws net.weareact.api.NotFoundException
     * @throws BadParameterException
     */
    public List<GraphDataPoint> getGraphDataForUnlinkedJourney(
            final String xJWTAssertion,
            final String q,
            final JsonNode graphConfig,
            ACTClaims claims ) throws net.weareact.api.NotFoundException
    {

        String financialPeriodQuery = "";
        Map<String, Integer> unlocatedJourneyMap = new LinkedHashMap<String, Integer>();

        List<GraphDataPoint> graphDataPointList;
        Map<String, String> queryString = getQueryString( graphConfig, q, claims );

        // create query to fetch the financial period details for given scheme
        financialPeriodQuery = buildQuery( graphConfig, q, claims, queryString );

        // method to get the noOffinancialPeriods
        int noOffinancialPeriods = Integer
                .parseInt( queryString.get( graphConfig.get( "queryFieldNoOfFP" ).asText() ) );

        // make a call to FinancialPeriod API end point to get the List of FinancialPeriod objects
        List<FinancialPeriod> financialPeriodLists = manageFPEndpointCall(
                graphConfig,
                financialPeriodQuery,
                xJWTAssertion );

        // Sort the FinancialPeriod Lists based on the start date
        Collections.sort( financialPeriodLists, ( p1, p2 ) -> p2.getStartDate().compareTo( p1.getStartDate() ) );

        // get the required number of financial period object from the FinancialPeriod list
        List<FinancialPeriod> financialPeriodListsSubList = financialPeriodLists.subList( 0, noOffinancialPeriods );
        financialPeriodListsSubList.forEach( fp ->
        {
            // make a call to JourneySummery API end point to get the no of journey details
            Integer noOfJourney = callJourneySummery( fp, graphConfig, xJWTAssertion );
            String key = fp.getName() + " - " + fp.getPeriod();
            unlocatedJourneyMap.put( key, noOfJourney );
        } );

        // aggregate the response and create the GraphDataPoint object
        graphDataPointList = splitUnlocatedJourneyMap( unlocatedJourneyMap, graphConfig );
        return graphDataPointList;
    }

    private Map<String, String> getQueryString( JsonNode graphConfig, String q, ACTClaims claims )
    {
        String schemeLink = graphConfig.get( "queryFieldSchemeName" ).asText();
        String numberOfFinancialPeriods = graphConfig.get( "queryFieldNoOfFP" ).asText();
        return getValue( graphConfig, q, schemeLink, numberOfFinancialPeriods, claims );

    }

    /**
     * to aggregate the response and create the GraphDataPoint object
     * 
     * @param graphConfig
     * @param unlocatedJourneyMap
     * @return List<GraphDataPoint> objects
     */
    private List<GraphDataPoint> splitUnlocatedJourneyMap(
            Map<String, Integer> unlocatedJourneyMap,
            final JsonNode graphConfig )
    {
        DashboardConfigurationUtil conUtil = new DashboardConfigurationUtil();
        List<GraphDataPoint> graphDataPointList = new ArrayList<>();
        GraphDataPoint graphDataPoint = new GraphDataPoint();
        graphDataPoint.setDataPointLegend( conUtil.readValue( graphConfig, DATA_POINT_LEGEND, UNALLOCATED ) );
        List<PointData> dataPointList = new ArrayList<>();

        unlocatedJourneyMap.forEach( ( dateTime, count ) ->
        {
            PointData pointData = new PointData();
            pointData.setPointLegend( conUtil.readValue( graphConfig, POINT_LEGEND, UNALLOCATED ) );

            Map<String, String> pointKey = new HashMap<>();
            pointKey.put( "en", dateTime );
            pointData.setPointKey( pointKey );
            pointData.setPointValue( count );
            dataPointList.add( pointData );

        } );
        graphDataPoint.setDataPointValues( dataPointList );
        graphDataPointList.add( graphDataPoint );
        return graphDataPointList;
    }

    /**
     * method to call JourneySummery API end point to get the no of journey details
     * 
     * @param financialPeriod
     * @param graphConfig
     * @param xJWTAssertion
     * @return noOfJourney
     */
    private Integer callJourneySummery( FinancialPeriod financialPeriod, JsonNode graphConfig, String xJWTAssertion )
    {
        String journeyQuery = createJourneyQuery( financialPeriod.getStartDate(), financialPeriod.getEndDate() );
        String endPoint = graphConfig.get( "journeySummeryEndPoint" ).asText();
        WebTarget target = apiClient.target( endPoint + "?q=" + URLEncoder.encode( journeyQuery ) );
        // WebTarget target1 = apiClient.target( endPoint ).queryParam( "q", journeyQuery );

        Response apiResponse = target.request().header( JWT_ASSERTION_HEADER, xJWTAssertion ).get();
        SummaryResponse summaryResponse = new SummaryResponse();
        checkResponse( apiResponse, summaryResponse );

        summaryResponse = apiResponse.readEntity( SummaryResponse.class );

        GroupSummary groupSummary = summaryResponse.getSummary();
        return groupSummary.getTotal();

    }

    /**
     * This method creates the query to fetch journey records
     * 
     * @param startDate
     * @param endDate
     * @return query to fetch the journey details
     */
    public String createJourneyQuery( ZonedDateTime startDate, ZonedDateTime endDate )
    {
        return "startDateTime >=" + startDate.toInstant() + " AND startDateTime <=" + endDate.toInstant();

    }

    /**
     * This method checks the apiResponse and logs errors and throws proper exception
     * 
     * @param apiResponse
     * @param responseType
     */
    public void checkResponse( Response apiResponse, Object responseType )
    {
        LOGGER.debug( "Response is:" + apiResponse );
        if ( apiResponse.getStatus() == HttpStatus.SC_NOT_FOUND )
        {
            LOGGER.error( responseType.getClass() + " is Not found" );

        }
        else if ( apiResponse.getStatus() == HttpStatus.SC_UNAUTHORIZED )
        {
            LOGGER.error( "User is not authorised to access " + responseType.getClass() );
            throw new BadParameterException( "User is not authorised to access " + responseType.getClass() );
        }

    }

    /**
     * method to call the checks the FinancialPeriod API end point
     * 
     * @param graphConfig
     * @param queryString
     * @param xJWTAssertion
     * @return list of FinancialPeriod
     * 
     */
    private List<FinancialPeriod> manageFPEndpointCall(
            final JsonNode graphConfig,
            final String queryString,
            final String xJWTAssertion ) throws net.weareact.api.NotFoundException
    {
        List<FinancialPeriod> financialPeriodFinal = new ArrayList<>();
        FinancialPeriodsResponse fPResponse = null;
        int count = 0;
        int offset = 0;
        do
        {
            if ( count > 0 && fPResponse != null )
            {
                offset = offset + ( fPResponse.getMeta().getLimit().intValue() );
            }

            Response apiResponse = callEndpointToFetchData( graphConfig, queryString, offset, xJWTAssertion );
            fPResponse = apiResponse.readEntity( FinancialPeriodsResponse.class );

            financialPeriodFinal.addAll( fPResponse.getFinancialPeriods() );
            count++;
        }
        while ( fPResponse.getMeta() != null && financialPeriodFinal.size() < fPResponse.getMeta().getTotalCount() );

        return financialPeriodFinal;
    }

    /**
     * method to fetch the FinancialPeriod object by calling the FinancialPeriod API end point
     * 
     * @param graphConfig
     * @param queryString
     * @param xJWTAssertion
     * @return list of FinancialPeriod
     * 
     */
    Response callEndpointToFetchData(
            final JsonNode graphConfig,
            final String queryString,
            final int offset,
            final String xJWTAssertion ) throws net.weareact.api.NotFoundException
    {
        LOGGER.info( "Method callFPEndpoint:: Going to hit Financial Period API" );
        Response response = null;

        String endPoint = graphConfig.get( "fpEndPoint" ).asText();
        if ( queryString != null && !queryString.isEmpty() )
        {
            // hit the Financial Period API to fetch the data
            WebTarget target;
            if ( offset > 0 )
            {
                target = apiClient.target( endPoint ).queryParam( "q", queryString ).queryParam( "offset", offset );
            }
            else
            {
                target = apiClient.target( endPoint ).queryParam( "q", queryString );
            }

            // find out how to pass the jwt user has sent
            LOGGER.info(
                    "Method callFPEndpoint:: Calling endpoint - ["
                            + endPoint
                            + "] with queryString ["
                            + queryString
                            + "]" );

            try
            {

                response = target.request().header( HTTP_HEADER_JWT, xJWTAssertion ).get();
            }
            catch ( Exception ex )
            {
                // Financial Period is unavailable!
                LOGGER.error( String.format( "Financial Period is unavailable - %s", ex ) );
                throw new net.weareact.api.NotFoundException(
                        String.format( "Financial Period is unavailable - %s", ex.getMessage() ) );
            }

            if ( response.getStatus() != HttpStatus.SC_OK )
            {
                LOGGER.error( "Method callFPEndpoint:: Bad Request:: API Response is - " + response.toString() );
                ServiceError targetApiServiceError = response.readEntity( ServiceError.class );
                throw new BadParameterException( targetApiServiceError.getUserMessage() );
            }
        }
        LOGGER.info( "Method callFPEndpoint:: Returning response - " + response );
        return response;
    }

    /**
     *
     * This method builds the query based on the query and path parameter received .
     *
     * @param queryConfig
     * @param q
     *            : query parameter received
     * @param claims
     * @param schemeLinkValue
     * @return : returns the query to hit the financial period API
     *
     */
    public static String buildQuery(
            final JsonNode queryConfig,
            final String q,
            ACTClaims claims,
            Map<String, String> schemeLinkValue )
    {
        LOGGER.info( "Method buildQuery:: Passed [q param] value is - " + q );
        StringBuilder query = new StringBuilder();

        // Get default query params from configuration files
        String schemeLink = queryConfig.get( "queryFieldSchemeName" ).asText();

        if ( claims.getSchemes().stream().map( ResourceLink::getLink ).anyMatch(
                sc -> sc.equals( schemeLinkValue.get( schemeLink ).trim() ) ) )
        {
            query.append( schemeLink ).append( EQUALS_OPERATOR ).append( schemeLinkValue.get( schemeLink ).trim() );
        }
        else
        {
            LOGGER.error( "Scheme name is not maching with FinancialPeriod scheme" );
            throw new BadParameterException( "Scheme name is not maching with FinancialPeriod scheme" );
        }

        LOGGER.info( "Method buildQuery:: Returned [q param] value is - " + query.toString() );
        return query.toString().trim();
    }

    /**
     *
     * to validate the scheme name and numberOfFinancialPeriods .
     * 
     * @param graphConfig
     *
     * @param value
     * @param q
     *            : query parameter received
     * @param claims
     * @return : returns the value of scheme.link and numberOfFinancialPeriods
     *
     */
    private static Map<String, String> getValue(
            JsonNode graphConfig,
            final String q,
            String schemeLink,
            String numberOfFinancialPeriods,
            ACTClaims claims )
    {
        Map<String, String> maps = new HashMap<>();
        Collection<ResourceLink> schemes = claims.getSchemes();
        String link = null;
        if ( StringUtils.isEmpty( q ) || StringUtils.isBlank( q ) )
        {

            for ( ResourceLink resourceLink : schemes )
            {
                link = resourceLink.getLink();
                break;
            }
            maps.put( schemeLink, link );
            maps.put( numberOfFinancialPeriods, graphConfig.get( "defaultNoOfFP" ).asText() );

        }
        else
        {

            String substring = q.substring( 2, q.length() );

            if ( q.contains( "AND" ) )
            {
                String[] pairs = substring.split( "AND" );
                for ( String pair : pairs )
                {
                    String[] parts = pair.split( EQUALS_OPERATOR );
                    if ( parts[ 0 ].equalsIgnoreCase( schemeLink ) )
                    {
                        maps.put( "scheme.link", parts[ 1 ] );
                    }
                    if ( parts[ 0 ].trim().equalsIgnoreCase( numberOfFinancialPeriods ) )
                    {
                        maps.put( "numberOfFinancialPeriods", parts[ 1 ] );
                    }
                }
            }
            else
            {
                String[] parts = substring.split( EQUALS_OPERATOR );
                if ( parts[ 0 ].equalsIgnoreCase( schemeLink ) )
                {
                    maps.put( "scheme.link", parts[ 1 ] );
                }
                else
                {

                    for ( ResourceLink resourceLink : schemes )
                    {
                        link = resourceLink.getLink();
                        break;
                    }
                    maps.put( "scheme.link", link );
                }

                if ( parts[ 0 ].trim().equalsIgnoreCase( numberOfFinancialPeriods ) )
                {
                    maps.put( "numberOfFinancialPeriods", parts[ 1 ] );
                }
                else
                    maps.put( "numberOfFinancialPeriods", graphConfig.get( "defaultNoOfFP" ).asText() );
            }
        }
        return maps;
    }

}
