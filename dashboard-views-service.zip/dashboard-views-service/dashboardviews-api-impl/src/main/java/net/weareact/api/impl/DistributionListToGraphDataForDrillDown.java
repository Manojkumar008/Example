package net.weareact.api.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.JsonNode;

import net.weareact.api.impl.config.DashboardConfigurationUtil;
import net.weareact.dashboardview.model.DistributionList;
import net.weareact.dashboardview.model.DistributionList.GenerationStatusEnum;
import net.weareact.dashboardview.model.ReceivedDistributionList;
import net.weareact.dashboardview.model.SchemeLink;
import net.weareact.model.GraphDataPoint;
import net.weareact.model.PointData;
import net.weareact.scheme.model.SchemeResponse;

/**
 * DistributionListToGraphDataForDrillDown.
 * <p>
 * Copyright 2016 Applied Card Technologies Ltd
 *
 * @author kuyatega
 */

public class DistributionListToGraphDataForDrillDown
{

    private static final String STATUS_UNSCHEDULED = "unscheduled";
    private static final String POINT_LEGEND       = "pointLegend";
    private static final String STATUS_FAILED      = "failed";
    private static final String STATUS_SUCCESS     = "success";
    private static final String DATA_POINT_LEGEND  = "dataPointLegend";
    private static final String SCHEME_END_POINT   = "schemeEndPoint";
    private static final String LOCALE_ALL         = "en";
    private static final Logger LOGGER             = LoggerFactory
                                                           .getLogger(
                                                                   DistributionListToGraphDataForDrillDown.class
                                                                           .getName() );
    private static final String HTTP_HEADER_JWT    = "X-JWT-Assertion";

    public List<GraphDataPoint> convertDLtoGraphData(
            List<DistributionList> distributionList,
            JsonNode graphConfig,
            String xJWTAssertion,
            List<SchemeLink> missingSchemeList )
    {
        // DVS-136
        List<GraphDataPoint> graphData = new ArrayList<>();

        if ( !distributionList.isEmpty() )
        {

            DashboardConfigurationUtil conUtil = new DashboardConfigurationUtil();

            LOGGER.info( "Method getAllGraphData:: get GraphDataPoint for Success_Faild_Partial Legend " );

            GraphDataPoint unscheduleGraphData = new GraphDataPoint();
            unscheduleGraphData
                    .setDataPointLegend( conUtil.readValue( graphConfig, DATA_POINT_LEGEND, STATUS_UNSCHEDULED ) );

            GraphDataPoint successGraphData = new GraphDataPoint();
            successGraphData.setDataPointLegend( conUtil.readValue( graphConfig, DATA_POINT_LEGEND, STATUS_SUCCESS ) );

            GraphDataPoint failedGraphData = new GraphDataPoint();
            failedGraphData.setDataPointLegend( conUtil.readValue( graphConfig, DATA_POINT_LEGEND, STATUS_FAILED ) );

            List<PointData> unscheduleDataPointList = new ArrayList<>();
            List<PointData> successDataPointList = new ArrayList<>();
            List<PointData> failedDataPointList = new ArrayList<>();

            distributionList
                    .stream()
                    .filter(
                            dl -> dl.getUnscheduled()
                                    && ( dl.getGenerationStatus() == GenerationStatusEnum.GENERATED ) )
                    .forEach( dl ->
                    {
                        PointData unschedulePointData = new PointData();
                        unschedulePointData.setPointValue( dl.getSize() );
                        // get PointKey for corresponding schemelink from scheme service
                        // pass scheme link uid to scheme service endpoint "/scheme/{uid}"
                        Map<String, String> pointKeyValue = callSchemeService(
                                graphConfig,
                                dl.getScheme(),
                                xJWTAssertion );
                        unschedulePointData.setPointKey( pointKeyValue );
                        unschedulePointData
                                .setPointLegend( conUtil.readValue( graphConfig, POINT_LEGEND, STATUS_UNSCHEDULED ) );
                        unscheduleDataPointList.add( unschedulePointData );
                        successDataPointList.add(
                                conUtil.getEmptyPointData( pointKeyValue, graphConfig, POINT_LEGEND, STATUS_SUCCESS ) );
                        failedDataPointList.add(
                                conUtil.getEmptyPointData( pointKeyValue, graphConfig, POINT_LEGEND, STATUS_FAILED ) );
                    } );

            distributionList
                    .stream()
                    .filter( dl -> !dl.getUnscheduled() )
                    .filter( d -> d.getGenerationStatus() == GenerationStatusEnum.GENERATED )
                    .forEach( dl ->
                    {
                        PointData successPointData = new PointData();
                        successPointData.setPointValue( dl.getSize() );
                        // get PointKey for corresponding schemelink from scheme service
                        // pass scheme link uid to scheme service endpoint "/scheme/{uid}"
                        Map<String, String> pointKeyValue = callSchemeService(
                                graphConfig,
                                dl.getScheme(),
                                xJWTAssertion );
                        successPointData.setPointKey( pointKeyValue );
                        successPointData
                                .setPointLegend( conUtil.readValue( graphConfig, POINT_LEGEND, STATUS_SUCCESS ) );
                        successDataPointList.add( successPointData );
                        unscheduleDataPointList.add(
                                conUtil.getEmptyPointData(
                                        pointKeyValue,
                                        graphConfig,
                                        POINT_LEGEND,
                                        STATUS_UNSCHEDULED ) );
                        failedDataPointList.add(
                                conUtil.getEmptyPointData( pointKeyValue, graphConfig, POINT_LEGEND, STATUS_FAILED ) );
                    } );

            distributionList
                    .stream()
                    .filter( d -> d.getGenerationStatus() == GenerationStatusEnum.FAILED_TO_GENERATE )
                    .forEach( dl ->
                    {
                        PointData failedPointData = new PointData();
                        failedPointData.setPointValue( dl.getSize() );
                        // get PointKey for corresponding schemelink from scheme service
                        // pass scheme link uid to scheme service endpoint "/scheme/{uid}"
                        Map<String, String> pointKeyValue = callSchemeService(
                                graphConfig,
                                dl.getScheme(),
                                xJWTAssertion );
                        failedPointData.setPointKey( pointKeyValue );
                        failedPointData.setPointLegend( conUtil.readValue( graphConfig, POINT_LEGEND, STATUS_FAILED ) );
                        failedDataPointList.add( failedPointData );
                        unscheduleDataPointList.add(
                                conUtil.getEmptyPointData(
                                        pointKeyValue,
                                        graphConfig,
                                        POINT_LEGEND,
                                        STATUS_UNSCHEDULED ) );
                        successDataPointList.add(
                                conUtil.getEmptyPointData( pointKeyValue, graphConfig, POINT_LEGEND, STATUS_SUCCESS ) );
                    } );
            // Populate 0 Value for missing schemes
            addEmptyPointDataForMissingSchemes(
                    graphConfig,
                    xJWTAssertion,
                    missingSchemeList,
                    conUtil,
                    unscheduleDataPointList,
                    successDataPointList,
                    failedDataPointList );
            unscheduleGraphData.setDataPointValues( unscheduleDataPointList );
            successGraphData.setDataPointValues( successDataPointList );
            failedGraphData.setDataPointValues( failedDataPointList );
            graphData.add( unscheduleGraphData );
            graphData.add( successGraphData );
            graphData.add( failedGraphData );
        }
        return graphData;
    }

    private Map<String, String> callSchemeService( JsonNode graphConfig, SchemeLink schemeLink, String xJWTAssertion )
    {
        Map<String, String> pointKeyMap = new HashMap<>();
        try
        {
            Client apiClient = ClientBuilder.newClient();

            String schemeEndPoint = graphConfig.get( SCHEME_END_POINT ).asText();
            WebTarget target = apiClient.target( schemeEndPoint ).path( schemeLink.getLink() );
            Response response = target.request().header( HTTP_HEADER_JWT, xJWTAssertion ).get();

            if ( response.getStatus() == HttpStatus.SC_OK )
            {
                pointKeyMap = response.readEntity( SchemeResponse.class ).getScheme().getName();
            }
            else
            {
                pointKeyMap.putIfAbsent( LOCALE_ALL, schemeLink.getAbbreviation() );
            }
        }
        catch ( Exception ex )
        {
            LOGGER.error(
                    "Method getAllGraphData:Set PointKey when SchemeService not providing proper response : " + ex );
        }
        finally
        {
            pointKeyMap.putIfAbsent( LOCALE_ALL, schemeLink.getAbbreviation() );
        }
        return pointKeyMap;
    }

    public List<GraphDataPoint> convertReceivedDLtoGraphData(
            List<ReceivedDistributionList> receivedDistributionList,
            JsonNode graphConfig,
            String xJWTAssertion,
            List<SchemeLink> missingSchemeList )
    {
        List<GraphDataPoint> graphData = new ArrayList<>();

        if ( !receivedDistributionList.isEmpty() )
        {

            DashboardConfigurationUtil conUtil = new DashboardConfigurationUtil();
            LOGGER.info( "Get MeGraphDataPoint for Unscheduled, Success and Failed Legends " );

            GraphDataPoint unscheduleGraphData = new GraphDataPoint();
            unscheduleGraphData
                    .setDataPointLegend( conUtil.readValue( graphConfig, DATA_POINT_LEGEND, STATUS_UNSCHEDULED ) );

            GraphDataPoint successGraphData = new GraphDataPoint();
            successGraphData.setDataPointLegend( conUtil.readValue( graphConfig, DATA_POINT_LEGEND, STATUS_SUCCESS ) );

            GraphDataPoint failedGraphData = new GraphDataPoint();
            failedGraphData.setDataPointLegend( conUtil.readValue( graphConfig, DATA_POINT_LEGEND, STATUS_FAILED ) );

            List<PointData> unscheduleDataPointList = new ArrayList<>();
            List<PointData> successDataPointList = new ArrayList<>();
            List<PointData> failedDataPointList = new ArrayList<>();

            receivedDistributionList.forEach( dl ->
            {
                PointData successPointData = new PointData();
                successPointData.setPointValue( dl.getSize() );

                // get PointKey for corresponding schemelink from scheme service
                // pass scheme link uid to scheme service endpoint "/scheme/{uid}"
                Map<String, String> pointKeyValue = callSchemeService( graphConfig, dl.getScheme(), xJWTAssertion );
                successPointData.setPointKey( pointKeyValue );
                successPointData.setPointLegend( conUtil.readValue( graphConfig, POINT_LEGEND, STATUS_SUCCESS ) );
                successDataPointList.add( successPointData );
                unscheduleDataPointList.add(
                        conUtil.getEmptyPointData( pointKeyValue, graphConfig, POINT_LEGEND, STATUS_UNSCHEDULED ) );
                failedDataPointList
                        .add( conUtil.getEmptyPointData( pointKeyValue, graphConfig, POINT_LEGEND, STATUS_FAILED ) );
            } );
            // Populate 0 Value for missing schemes
            addEmptyPointDataForMissingSchemes(
                    graphConfig,
                    xJWTAssertion,
                    missingSchemeList,
                    conUtil,
                    unscheduleDataPointList,
                    successDataPointList,
                    failedDataPointList );

            unscheduleGraphData.setDataPointValues( unscheduleDataPointList );
            successGraphData.setDataPointValues( successDataPointList );
            failedGraphData.setDataPointValues( failedDataPointList );
            graphData.add( unscheduleGraphData );
            graphData.add( successGraphData );
            graphData.add( failedGraphData );
        }
        LOGGER.info( "Method convertReceivedDLtoGraphData:: Returning graphDataPoint " );
        return graphData;
    }

    /**
     * Method calls Scheme Service, gets Point Key Value For Missing Schemes and adds Empty Point Data for all 3 legends
     * 
     * @param graphConfig
     * @param xJWTAssertion
     * @param missingSchemeList
     * @param conUtil
     * @param unscheduleDataPointList
     * @param successDataPointList
     * @param failedDataPointList
     */
    private void addEmptyPointDataForMissingSchemes(
            JsonNode graphConfig,
            String xJWTAssertion,
            List<SchemeLink> missingSchemeList,
            DashboardConfigurationUtil conUtil,
            List<PointData> unscheduleDataPointList,
            List<PointData> successDataPointList,
            List<PointData> failedDataPointList )
    {
        missingSchemeList.forEach( schemeLinkObj ->
        {
            Map<String, String> pointKeyValueForMissingScheme = callSchemeService(
                    graphConfig,
                    schemeLinkObj,
                    xJWTAssertion );
            unscheduleDataPointList.add( conUtil.getEmptyPointData(
                    pointKeyValueForMissingScheme,
                    graphConfig,
                    POINT_LEGEND,
                    STATUS_UNSCHEDULED ) );
            successDataPointList.add(
                    conUtil.getEmptyPointData(
                            pointKeyValueForMissingScheme,
                            graphConfig,
                            POINT_LEGEND,
                            STATUS_SUCCESS ) );
            failedDataPointList.add(
                    conUtil.getEmptyPointData(
                            pointKeyValueForMissingScheme,
                            graphConfig,
                            POINT_LEGEND,
                            STATUS_FAILED ) );
        } );
    }
}
