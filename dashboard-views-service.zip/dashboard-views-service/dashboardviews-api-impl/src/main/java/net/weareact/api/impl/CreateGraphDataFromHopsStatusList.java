package net.weareact.api.impl;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.JsonNode;
import com.google.common.collect.Multimap;
import com.google.common.collect.Multimaps;

import net.weareact.api.NotFoundException;
import net.weareact.api.impl.utils.DashboardViewsImplQueryUtil;
import net.weareact.api.impl.utils.DateUtils;
import net.weareact.api.impl.utils.HopsCmsUtil;
import net.weareact.common.exceptionhandling.BadParameterException;
import net.weareact.hopsstatus.model.HopsStatus;
import net.weareact.hopsstatus.model.HopsStatusesResponse;
import net.weareact.hopsstatus.model.MessageQueueContent;
import net.weareact.model.GraphDataPoint;
import net.weareact.model.PointData;

/**
 * This class is used to create the GraphDataPoint objects from HopsStatus list. CreateGraphDataFromHopsStatusList.
 * <p>
 * Copyright 2016 Applied Card Technologies Ltd
 *
 * @author patilsan
 */
public class CreateGraphDataFromHopsStatusList
{

    private static final Logger LOGGER            = LoggerFactory
                                                          .getLogger(
                                                                  CreateGraphDataFromHopsStatusList.class.getName() );

    private static final String POINT_LEGEND      = "pointLegend";

    private static final String CURRENT_LINE      = "current";

    private static final String AVERAGE_LINE      = "averageLine";

    private static final String DATA_POINT_LEGEND = "dataPointLegend";

    private static final String LOCALE_ALL        = "locale-all";

    private final HopsCmsUtil   hopsCmsUtil       = new HopsCmsUtil();

    /**
     * This method creates the GraphDataPoint for average line displayed in graph
     *
     * @param graphConfig
     *            {@link JsonNode}
     * @param hopsStatusCurrentData
     *            {@link List}
     * @return averageLineGraphData {@link GraphDataPoint}
     * @throws NotFoundException
     * @throws BadParameterException
     */
    public GraphDataPoint convertHopsStatusToGraphDataForAverageLine(
            final JsonNode graphConfig,
            final List<HopsStatus> hopsStatusCurrentData,
            final String key,
            final String jwtToken ) throws BadParameterException, NotFoundException
    {
        GraphDataPoint averageLineGraphData = new GraphDataPoint();

        averageLineGraphData.setDataPointLegend(
                hopsCmsUtil
                        .readValueAndAppendProductNameToLegends( graphConfig, DATA_POINT_LEGEND, AVERAGE_LINE, key ) );
        String defaultLocale = graphConfig.get( LOCALE_ALL ).asText();
        List<PointData> pointDataList = new ArrayList<>();

        /*
         * find earliest date, sort hops statuses by date
         */

        HopsStatus lastStatus = hopsStatusCurrentData.get( hopsStatusCurrentData.size() - 1 );
        ZonedDateTime earliestDate = lastStatus.getDateTime();

        // build query to fetch rollBackNumber records for average calculation
        int rollBackNumber;
        JsonNode rollBackNode = graphConfig.get( "rollBackNumber" );
        if ( rollBackNode.get( key ) != null )
        {
            rollBackNumber = rollBackNode.get( key ).asInt();
        }
        else
        {
            rollBackNumber = rollBackNode.get( "default" ).asInt();
        }

        String query = DashboardViewsImplQueryUtil.buildQueryToFetchDataForAvergaeLineCalculation(
                graphConfig,
                key,
                earliestDate,
                "hopsNameParameterName" );

        HopsCmsUtil util = new HopsCmsUtil();

        Response response = util.callServiceToFetchHistoryData( graphConfig, query, jwtToken, rollBackNumber );

        HopsStatusesResponse hopsStatusesResponse = response.readEntity( HopsStatusesResponse.class );
        List<HopsStatus> hopsStatusesHistoryData = hopsStatusesResponse.getHopsStatuses();

        List<HopsStatus> hopsStatusesCurrentPlusHistoryData = new ArrayList<>();
        hopsStatusesCurrentPlusHistoryData.addAll( hopsStatusCurrentData );
        hopsStatusesCurrentPlusHistoryData.addAll( hopsStatusesHistoryData );

        int sizeOfListOfAverageCalculation = hopsStatusesCurrentPlusHistoryData.size();

        for ( int index = 0; index < hopsStatusCurrentData.size(); index++ )
        {
            HopsStatus h = hopsStatusCurrentData.get( index );
            int startIndex = index;

            int endIndex = ( startIndex + rollBackNumber ) > sizeOfListOfAverageCalculation
                    ? sizeOfListOfAverageCalculation
                    : ( startIndex + rollBackNumber );

            List<HopsStatus> hopsStatusSubList = hopsStatusesCurrentPlusHistoryData.subList( startIndex, endIndex );
            int total = hopsStatusSubList
                    .stream()
                    .map( HopsStatus::getMessageQueueContent )
                    .map( MessageQueueContent::getTotalSize )
                    .reduce( 0, ( a, b ) -> a + b );
            Integer average = Math.round( total / hopsStatusSubList.size() );

            PointData data = new PointData();
            data.setPointValue( average );
            data.setPointLegend(
                    util.readValueAndAppendProductNameToLegends(
                            graphConfig,
                            POINT_LEGEND,
                            AVERAGE_LINE,
                            h.getName() ) );
            Map<String, String> pointKeyMap = new HashMap<>();
            pointKeyMap.put( defaultLocale, DateUtils.converDateToString( h.getDateTime() ) );
            data.setPointKey( pointKeyMap );
            pointDataList.add( data );

        }

        // Since the data is in descending order, the point data list must be reversed
        Collections.reverse( pointDataList );
        averageLineGraphData.setDataPointValues( pointDataList );
        return averageLineGraphData;
    }

    /**
     * This method creates the GraphDataPoint for current line displayed in graph
     *
     * @param graphConfig
     *            {@link JsonNode}
     * @param hopsStatusList
     *            {@link List}
     *
     * @return currentLineGraphData {@link GraphDataPoint}
     */
    public GraphDataPoint convertHopsStatusToGraphDataForCurrentLine(
            final JsonNode graphConfig,
            final List<HopsStatus> hopsStatusList,
            final String key )
    {

        GraphDataPoint currentLineGraphData = new GraphDataPoint();

        currentLineGraphData.setDataPointLegend(
                hopsCmsUtil
                        .readValueAndAppendProductNameToLegends( graphConfig, DATA_POINT_LEGEND, CURRENT_LINE, key ) );

        String defaultLocale = graphConfig.get( LOCALE_ALL ).asText();
        List<PointData> pointDataList = new ArrayList<>();

        hopsStatusList.forEach( h ->
        {
            PointData data = new PointData();
            data.setPointValue( h.getMessageQueueContent().getTotalSize() );
            data.setPointLegend(
                    hopsCmsUtil.readValueAndAppendProductNameToLegends(
                            graphConfig,
                            POINT_LEGEND,
                            CURRENT_LINE,
                            h.getName() ) );
            Map<String, String> pointKeyMap = new HashMap<>();
            pointKeyMap.put( defaultLocale, DateUtils.converDateToString( h.getDateTime() ) );
            data.setPointKey( pointKeyMap );
            pointDataList.add( data );
        } );

        // need to reverse the list, as hopsStatusList was in descending order.
        Collections.reverse( pointDataList );
        currentLineGraphData.setDataPointValues( pointDataList );
        return currentLineGraphData;

    }

    public List<GraphDataPoint> create(
            final String xJWTAssertion,
            final JsonNode graphConfig,
            final List<HopsStatus> hopsStatusListAll ) throws BadParameterException, NotFoundException
    {
        List<GraphDataPoint> graphDataPointList = new ArrayList<>();
        // This function return name for each HopsStatus object
        // Function<HopsStatus, String> hopsNameFunction =

        // Below function returns MultiMap, having Cms Name as key for each map and CmsStatus objects list at
        // that Cms Name as value to map.

        Multimap<String, HopsStatus> hopsStatusMultiMap = Multimaps
                .index( hopsStatusListAll, ( final HopsStatus from ) -> from.getName() );

        // for each hops create current line and average line
        hopsStatusMultiMap.keySet().forEach( hopsName ->
        {// create GraphDataPoint for AverageLine
            try
            {
                GraphDataPoint averageLineGraphDataPoint = convertHopsStatusToGraphDataForAverageLine(
                        graphConfig,
                        new ArrayList<>( hopsStatusMultiMap.get( hopsName ) ),
                        hopsName,
                        xJWTAssertion );
                graphDataPointList.add( averageLineGraphDataPoint );
                // create GraphDataPoint for CurrentLine
                GraphDataPoint currentLineGraphDataPoint = convertHopsStatusToGraphDataForCurrentLine(
                        graphConfig,
                        new ArrayList<>( hopsStatusMultiMap.get( hopsName ) ),
                        hopsName );
                graphDataPointList.add( currentLineGraphDataPoint );
                for ( int index = 0; index < averageLineGraphDataPoint.getDataPointValues().size(); index++ )
                {
                    hopsCmsUtil.setIrregular(
                            graphConfig,
                            hopsName,
                            averageLineGraphDataPoint.getDataPointValues().get( index ),
                            currentLineGraphDataPoint.getDataPointValues().get( index ) );
                }
            }
            catch ( NotFoundException e )
            {
                LOGGER.error( "Error ocured while creating  GraphDataPoint for AverageLine of HOPS satatus :" + e );
            }
        } );
        return graphDataPointList;
    }

}
