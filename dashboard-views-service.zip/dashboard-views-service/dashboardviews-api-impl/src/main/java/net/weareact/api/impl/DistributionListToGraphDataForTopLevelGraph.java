/*
 * ************************************************************************** Copyright 2010 Applied Card Technologies
 * Ltd
 *
 * What : RetriveGraphDataFromDistributionList Who : kuyatega When : Jan 27, 2016
 *
 * Source control $Revision: 91803 $ $Author: markh2 $ $Date: 2012-11-12 14:00:56 +0000 (Mon, 12 Nov 2012) $
 *
 ****************************************************************************/

package net.weareact.api.impl;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Function;
import com.google.common.collect.Multimap;
import com.google.common.collect.Multimaps;

import net.weareact.api.impl.utils.DateUtils;
import net.weareact.dashboardview.model.DistributionList;
import net.weareact.dashboardview.model.DistributionList.GenerationStatusEnum;
import net.weareact.dashboardview.model.ReceivedDistributionList;
import net.weareact.model.GraphDataPoint;
import net.weareact.model.PointData;

/**
 * @author kuyatega
 *
 *         This class convert DistributionList to DashboardView response. Similarly, ReceivedDistributionList to
 *         DashboardView response. For translation, we have used MultiMap and etc.
 *
 *         MultiMap: A collection that maps keys to values, similar to Map, but in which each key may be associated with
 *         multiple values. You can visualize the contents of a multimap either as a map from keys to nonempty
 *         collections of values.
 */

public class DistributionListToGraphDataForTopLevelGraph
{
    private static final String STATUS_NEXT         = "next";

    private static final String STATUS_UNSCHEDULED  = "unscheduled";

    private static final String POINT_LEGEND        = "pointLegend";

    private static final String STATUS_FAILED       = "failed";

    private static final String STATUS_SUCCESS      = "success";

    private static final String STATUS_PARTIAL      = "partial";

    private static final String DATA_POINT_LEGEND   = "dataPointLegend";

    private static final String LOCALE_ALL          = "locale-all";

    private static final Logger LOGGER              = LoggerFactory
                                                            .getLogger(
                                                                    DistributionListToGraphDataForTopLevelGraph.class
                                                                            .getName() );
    private GraphDataPoint      unscheduleGraphData = new GraphDataPoint();
    private GraphDataPoint      nextGraphData       = new GraphDataPoint();
    private GraphDataPoint      partialGraphData    = new GraphDataPoint();
    private GraphDataPoint      successGraphData    = new GraphDataPoint();
    private GraphDataPoint      failedGraphData     = new GraphDataPoint();

    /**
     * Method Splits the DistributionList list according to dateTime Generated Map, dateTime as key and List
     * <DistributionList> as value.
     *
     * @param distributionList
     * @param graphConfig
     * @return List<GraphDataPoint>
     */
    public List<GraphDataPoint> splitDistributionListByTime(
            final List<DistributionList> distributionList,
            final JsonNode graphConfig )
    {
        LOGGER.info( "Method splitDistributionListByTime:: Convert DL to List<GraphDataPoint>" );

        // This function return generationStartDateTime for each Dl object
        Function<DistributionList, String> timeFunction = ( final DistributionList from ) -> DateUtils
                .converDateToString( from.getGenerationStartDateTime() );

        // Below function returns MultiMap, having generationStartDateTime as key for each map and DL objects list at
        // that generationStartDateTime as value to map.

        Multimap<String, DistributionList> distListMultiMap = Multimaps.index( distributionList, timeFunction );

        // get UNSCHEDULED GraphDataPoint
        GraphDataPoint unscheduleGraphDataPoint = getUnscheduledGraphDataPoint( distListMultiMap, graphConfig );

        // get Next GraphDataPoint
        GraphDataPoint nextGraphDataPoint = getNextGraphDataPoint( distListMultiMap, graphConfig );

        // get Success, Failed and Partial GraphDataPoint
        List<GraphDataPoint> graphData = getAllGraphData( distListMultiMap, graphConfig );
        graphData.add( unscheduleGraphDataPoint );
        graphData.add( nextGraphDataPoint );

        // check for all DataPointValues are empty or not.
        // if Yes then set empty ArrayList to GraphData. This will avoid hardcoded legend definition
        boolean graphFlag = graphData.stream().map( GraphDataPoint::getDataPointValues ).allMatch( dp -> dp.isEmpty() );
        if ( graphFlag )
        {
            graphData = new ArrayList<>();
        }
        return graphData;
    }

    /**
     * This block gives the Unscheduled GraphDataPoint. We have condition like, those Dl object are Unscheduled mark
     * them Under Unscheduled GraphDataPoint and log those DL object which are Unscheduled and from Future
     *
     * @param distListMultiMap
     * @param graphConfig
     * @return GraphDataPoint
     *
     */
    private GraphDataPoint getUnscheduledGraphDataPoint(
            final Multimap<String, DistributionList> distListMultiMap,
            final JsonNode graphConfig )
    {
        List<PointData> unscheduleDataPointList = new ArrayList<>();
        distListMultiMap.keySet().forEach( dateTime ->
        {
            String defaultLocale = graphConfig.get( LOCALE_ALL ).asText();
            Map<String, String> pointKeyMap = new HashMap<>();
            pointKeyMap.put( defaultLocale, dateTime );
            PointData unscheduledPointData = new PointData();
            // For getting total count at specific time for legend Unscheduled
            int unscheduleCount = distListMultiMap
                    .get( dateTime )
                    .stream()
                    .filter( dl -> dl.getUnscheduled() )
                    .filter( d -> d.getGenerationStatus().equals( GenerationStatusEnum.GENERATED ) )
                    .map( str -> isDLFromFuture( str ) ? fromFutureDlObject( str, STATUS_UNSCHEDULED ) : str )
                    .map( DistributionList::getSize )
                    .reduce( 0, ( a, b ) -> a + b );
            // setting PointData for each time instance
            unscheduledPointData.setPointValue( unscheduleCount );
            unscheduledPointData.setPointKey( pointKeyMap );
            unscheduledPointData.setPointLegend( readValue( graphConfig, POINT_LEGEND, STATUS_UNSCHEDULED ) );
            unscheduleDataPointList.add( unscheduledPointData );
        } );
        // setting DataPointLegend , legend are reads from configuration file
        unscheduleGraphData.setDataPointLegend( readValue( graphConfig, DATA_POINT_LEGEND, STATUS_UNSCHEDULED ) );
        unscheduleGraphData.setDataPointValues( unscheduleDataPointList );

        return unscheduleGraphData;
    }

    /**
     * This block gives the Next GraphDataPoint. We have condition like, those Dl object are from Future and having
     * Status as Pending mark them Under Next GraphDataPoint and log those DL object which are Unscheduled Pending and
     * from Future.
     *
     * @param distListMultiMap
     * @param graphConfig
     * @return GraphDataPoint for Next Legend
     *
     */
    private GraphDataPoint getNextGraphDataPoint(
            final Multimap<String, DistributionList> distListMultiMap,
            final JsonNode graphConfig )
    {
        List<PointData> nextDataPointList = new ArrayList<>();

        String defaultLocale = graphConfig.get( LOCALE_ALL ).asText();

        // Below block will set Next Legend
        distListMultiMap.keySet().forEach( dateTime ->
        { // Point Data for Next
            PointData nextPointData = new PointData();
            // For getting total count at specific time for legend Next
            int nextCount = distListMultiMap
                    .get( dateTime )
                    .stream()
                    .filter( dl -> dl.getGenerationStartDateTime().isAfter( ZonedDateTime.now() ) )
                    .filter( d -> d.getGenerationStatus().equals( GenerationStatusEnum.PENDING ) )
                    .map( str -> isDLFromFuture( str ) ? fromFutureDlObject( str, STATUS_NEXT ) : str )
                    .map( DistributionList::getSize )
                    .reduce( 0, ( a, b ) -> a + b );
            // setting PointData for each time instance
            nextPointData.setPointValue( nextCount );
            Map<String, String> pointKeyMap = new HashMap<>();
            pointKeyMap.put( defaultLocale, dateTime );
            nextPointData.setPointKey( pointKeyMap );
            nextPointData.setPointLegend( readValue( graphConfig, POINT_LEGEND, STATUS_NEXT ) );
            nextDataPointList.add( nextPointData );
        } );
        // setting DataPointLegend , legend are reads from configuration file
        nextGraphData.setDataPointLegend( readValue( graphConfig, DATA_POINT_LEGEND, STATUS_NEXT ) );
        nextGraphData.setDataPointValues( nextDataPointList );
        return nextGraphData;
    }

    /**
     * This block returns the GraphDataPoints for Success, Failed and Partial. For Partial : At same time, having
     * Generated and Failed object with unscheduled flag as false, mark them as Partial.
     *
     * @param distListMultiMap
     * @param graphConfig
     * @return List<GraphDataPoint>
     *
     *
     */
    private List<GraphDataPoint> getAllGraphData(
            final Multimap<String, DistributionList> distListMultiMap,
            final JsonNode graphConfig )
    {
        List<GraphDataPoint> graphData = new ArrayList<>();
        LOGGER.info( "Method getUnscheduledGraphData:: get GraphDataPoint for Unscheduled " );

        List<PointData> failedDataPointList = new ArrayList<>();
        List<PointData> successDataPointList = new ArrayList<>();
        List<PointData> partialDataPointList = new ArrayList<>();

        String defaultLocale = graphConfig.get( LOCALE_ALL ).asText();

        // Handled Partial , Success and Failed
        distListMultiMap.keySet().forEach( dateTime ->
        {
            Map<String, String> pointKeyMap = new HashMap<>();
            pointKeyMap.put( defaultLocale, dateTime );

            // --------------Partial Legend----------------------
            // getting count of Generated and failed Dl , as both having count greater than zero, then set as Partial
            int generatedCount = ( int ) distListMultiMap
                    .get( dateTime )
                    .stream()
                    .filter( dl -> !dl.getUnscheduled() )
                    .filter( dl -> dl.getGenerationStatus().equals( GenerationStatusEnum.GENERATED ) )
                    .count();
            int failedCount = ( int ) distListMultiMap
                    .get( dateTime )
                    .stream()
                    .filter( dl -> !dl.getUnscheduled() )
                    .filter( dl -> dl.getGenerationStatus().equals( GenerationStatusEnum.FAILED_TO_GENERATE ) )
                    .count();

            // building GraphData for Partial legend
            if ( generatedCount > 0 && failedCount > 0 )
            {
                PointData partialPointData = new PointData();

                // For getting total count at specific time for legend Partial
                int partialCount = distListMultiMap
                        .get( dateTime )
                        .stream()
                        .filter( dl -> !dl.getUnscheduled() )
                        .filter( d -> d.getGenerationStatus() != GenerationStatusEnum.PENDING )
                        .map( str -> isDLFromFuture( str ) ? fromFutureDlObject( str, STATUS_PARTIAL ) : str )
                        .map( DistributionList::getSize )
                        .reduce( 0, ( a, b ) -> a + b );

                partialPointData.setPointKey( pointKeyMap );

                partialPointData.setPointValue( partialCount );
                partialPointData.setPointLegend( readValue( graphConfig, POINT_LEGEND, STATUS_PARTIAL ) );
                // For setting Empty values for Successful , Failed legend

                PointData emptyPointDataSuccess = new PointData();
                emptyPointDataSuccess.setPointKey( pointKeyMap );
                emptyPointDataSuccess.setPointValue( 0 );
                emptyPointDataSuccess.setPointLegend( readValue( graphConfig, POINT_LEGEND, STATUS_SUCCESS ) );

                PointData emptyPointDataFailed = new PointData();
                emptyPointDataFailed.setPointKey( pointKeyMap );
                emptyPointDataFailed.setPointValue( 0 );
                emptyPointDataFailed.setPointLegend( readValue( graphConfig, POINT_LEGEND, STATUS_FAILED ) );

                successDataPointList.add( emptyPointDataSuccess );
                failedDataPointList.add( emptyPointDataFailed );
                partialDataPointList.add( partialPointData );
            }
            else
            {
                // set empty PointData for Partial DataPointLegend
                PointData emptyPointData = new PointData();
                emptyPointData.setPointKey( pointKeyMap );
                emptyPointData.setPointValue( 0 );
                emptyPointData.setPointLegend( readValue( graphConfig, POINT_LEGEND, STATUS_PARTIAL ) );

                PointData successPointData1 = new PointData();
                successPointData1.setPointKey( pointKeyMap );
                successPointData1.setPointLegend( readValue( graphConfig, POINT_LEGEND, STATUS_SUCCESS ) );

                PointData failedPointData1 = new PointData();
                failedPointData1.setPointKey( pointKeyMap );
                failedPointData1.setPointLegend( readValue( graphConfig, POINT_LEGEND, STATUS_FAILED ) );

                // For getting total count at specific time for legend Successful
                int successCount = distListMultiMap
                        .get( dateTime )
                        .stream()
                        .filter( dl -> !dl.getUnscheduled() )
                        .filter( d -> d.getGenerationStatus() == GenerationStatusEnum.GENERATED )
                        .map( str -> isDLFromFuture( str ) ? fromFutureDlObject( str, STATUS_SUCCESS ) : str )
                        .map( DistributionList::getSize )
                        .reduce( 0, ( a, b ) -> a + b );
                successPointData1.setPointValue( successCount );

                // For getting total count at specific time for legend Failed
                int faileCount = distListMultiMap
                        .get( dateTime )
                        .stream()
                        .filter( d -> d.getGenerationStatus() == GenerationStatusEnum.FAILED_TO_GENERATE )
                        .map( str -> isDLFromFuture( str ) ? fromFutureDlObject( str, STATUS_FAILED ) : str )
                        .map( DistributionList::getSize )
                        .reduce( 0, ( a, b ) -> a + b );
                failedPointData1.setPointValue( faileCount );

                // addding PointData to DataPointValue
                successDataPointList.add( successPointData1 );
                failedDataPointList.add( failedPointData1 );
                partialDataPointList.add( emptyPointData );

            }

        } );

        // setting DataPointLegend , legend are reads from configuration file
        successGraphData.setDataPointLegend( readValue( graphConfig, DATA_POINT_LEGEND, STATUS_SUCCESS ) );
        failedGraphData.setDataPointLegend( readValue( graphConfig, DATA_POINT_LEGEND, STATUS_FAILED ) );
        partialGraphData.setDataPointLegend( readValue( graphConfig, DATA_POINT_LEGEND, STATUS_PARTIAL ) );

        // Putting PointData List for each Lisi<P:ointData>
        successGraphData.setDataPointValues( successDataPointList );
        failedGraphData.setDataPointValues( failedDataPointList );
        partialGraphData.setDataPointValues( partialDataPointList );

        graphData.add( successGraphData );
        graphData.add( partialGraphData );
        graphData.add( failedGraphData );

        return graphData;
    }

    // CHECKING FOR Dl object is from Future on not
    public boolean isDLFromFuture( final DistributionList dl )
    {
        return dl.getGenerationStartDateTime().isAfter( ZonedDateTime.now() );
    }

    public DistributionList fromFutureDlObject( final DistributionList dl, final String status )
    {
        switch ( status )
        {
        case STATUS_UNSCHEDULED:
            LOGGER.warn(
                    "The DL object with scheme link as "
                            + dl.getScheme().getLink()
                            + " is from Future and Unscheduled and having status as "
                            + dl.getGenerationStatus() );
            break;
        case STATUS_NEXT:
            if ( dl.getUnscheduled() )
            {
                LOGGER.warn(
                        "The DL object with scheme link as "
                                + dl.getScheme().getLink()
                                + " is from Future and having status as "
                                + dl.getGenerationStatus() );
            }
            break;
        case STATUS_FAILED:
            LOGGER.warn(
                    "The DL object with scheme link as "
                            + dl.getScheme().getLink()
                            + " is from Future and having status as "
                            + dl.getGenerationStatus() );
            break;
        case STATUS_SUCCESS:
            LOGGER.warn(
                    "The DL object with scheme link as "
                            + dl.getScheme().getLink()
                            + " is from Future and having status as "
                            + dl.getGenerationStatus() );
            break;
        case STATUS_PARTIAL:
            LOGGER.warn(
                    "The DL object with scheme link as "
                            + dl.getScheme().getLink()
                            + " is from Future and having status as "
                            + dl.getGenerationStatus() );
            break;
        default:
            break;
        }

        return dl;
    }

    // CHECKING FOR RDl object is from Future on not
    public boolean isRDLFromFuture( final ReceivedDistributionList rdl )
    {
        return rdl.getReceivedDateTime().isAfter( ZonedDateTime.now() );
    }

    // placing proper LOGGER.warn for Future RDL object
    public ReceivedDistributionList fromFutureRDlObject( final ReceivedDistributionList dl )
    {
        LOGGER.warn( "The ReceivedDL object with scheme link as " + dl.getScheme().getLink() + " is from Future" );
        return dl;

    }

    /**
     * This method reads the value of status in dataPointLegend or pointLegend nodes
     *
     * @param graphConfig
     * @param legendField
     * @param statusField
     * @return
     */
    private Map<String, String> readValue(
            final JsonNode graphConfig,
            final String legendField,
            final String statusField )
    {
        JsonNode dpLegend = graphConfig.get( legendField );
        Map<String, Map<String, String>> legends = new ObjectMapper().convertValue( dpLegend, Map.class );
        return legends.get( statusField );
    }

    // Received ****************************************

    public List<GraphDataPoint> splitRecDistributionListByTime(
            final List<ReceivedDistributionList> recDistributionList,
            final JsonNode graphConfig )
    {
        LOGGER.info( "Method splitRecDistributionListByTime:: Convert Received DL to List<GraphDataPoint :::::" );
        List<GraphDataPoint> allGraphData = new ArrayList<>();

        Function<ReceivedDistributionList, String> timeFunction = ( final ReceivedDistributionList from ) -> DateUtils
                .converDateToString( from.getReceivedDateTime() );

        Multimap<String, ReceivedDistributionList> mmap = Multimaps.index( recDistributionList, timeFunction );

        GraphDataPoint receivedGraphDataPoint = getReceivedGraphData( mmap, graphConfig );
        allGraphData.add( receivedGraphDataPoint );

        boolean graphFlag = allGraphData
                .stream()
                .map( GraphDataPoint::getDataPointValues )
                .allMatch( dp -> dp.isEmpty() );
        if ( graphFlag )
        {
            allGraphData = new ArrayList<>();
        }

        LOGGER.info( "Method splitRecDistributionListByTime:: Returning Graph Data :::::" );
        return allGraphData;
    }

    /**
     * @param mmap
     * @param graphConfig
     * @return Unscheduled GraphDataPoint
     */
    private GraphDataPoint getReceivedGraphData(
            final Multimap<String, ReceivedDistributionList> mmap,
            final JsonNode graphConfig )
    {
        LOGGER.info( "Method getReceivedGraphData:: get GraphDataPoints " );
        GraphDataPoint receivedGraphData = new GraphDataPoint();

        receivedGraphData.setDataPointLegend( readValue( graphConfig, DATA_POINT_LEGEND, STATUS_SUCCESS ) );

        String defaultLocale = graphConfig.get( LOCALE_ALL ).asText();

        List<PointData> receivedDataPointList = new ArrayList<>();

        // For each time get corresponding DL list and map DL list to GraphDataPoint list
        mmap.keySet().forEach( dateTime ->
        {
            // Point Data for Unscheduled
            PointData receivedPointData = new PointData();

            // For getting total count at specific time for legend Unscheduled
            int receivedCount = mmap
                    .get( dateTime )
                    .stream()
                    .map( str -> isRDLFromFuture( str ) ? fromFutureRDlObject( str ) : str )
                    .map( ReceivedDistributionList::getSize )
                    .reduce( 0, ( a, b ) -> a + b );
            Map<String, String> pointKeyMap = new HashMap<>();
            pointKeyMap.put( defaultLocale, dateTime );
            // setting PointData for each time instance
            receivedPointData.setPointValue( receivedCount );
            receivedPointData.setPointKey( pointKeyMap );
            receivedPointData.setPointLegend( readValue( graphConfig, POINT_LEGEND, STATUS_SUCCESS ) );
            receivedDataPointList.add( receivedPointData );
        } );
        receivedGraphData.setDataPointValues( receivedDataPointList );
        return receivedGraphData;
    }

}
