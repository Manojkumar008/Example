package net.weareact.api.impl.utils;

import java.time.DayOfWeek;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.JsonNode;

import net.weareact.api.impl.config.DashBoardApiConfiguration;
import net.weareact.common.exceptionhandling.BadParameterException;

public class DashboardViewsImplQueryUtil
{

    private static final Logger LOGGER                            = LoggerFactory
                                                                          .getLogger(
                                                                                  DashboardViewsImplQueryUtil.class
                                                                                          .getName() );

    private static final String AND_OPERATOR                      = " AND ";
    private static final String EQUALS_OPERATOR                   = " = ";
    private static final String GREATER_THAN_EQUALS_OPERATOR      = ">=";
    private static final String LESS_THAN_EQUALS_OPERATOR         = "<=";
    private static final Object LESS_THAN_OPERATOR                = "<";
    private static final String SORT_BY                           = "sortBy";
    private static final Object DESC                              = "desc";

    private static final String MANAGEMENT_DASHBOARD              = "MANAGEMENT_DASHBOARD";

    private static final String OPERATIONAL_DASHBOARD             = "OPERATIONS_DASHBOARD";

    private static final String GRAPH_ID                          = "graph";

    private static final String DASH_BOARD                        = "dashboard";

    private static final String DEFAULT_BAD_PARAMETER_REQUEST_MSG = "Invalid Parameter are passed to request .";

    private static final String LAST_8_DAYS                       = "LAST_8_DAYS";
    private static final String LAST_8_WEEKS                      = "LAST_8_WEEKS";
    private static final String LAST_8_MONTHS                     = "LAST_8_MONTHS";

    private static final int    SEVEN                             = 7;
    private static final int    EIGHT                             = 8;
    private static final int    TWENTY_THREE                      = 23;
    private static final int    FIFTY_NINE                        = 59;

    private static final String QUERY_KEY                         = "query";

    /**
     *
     * This method builds the query based on the query parameter and path parameter received .
     *
     * @param graph
     *            : graph ID received in the path parameter
     * @param queryConfig
     * @param q
     *            : query parameter received
     * @return : returns the query to hit the distribution list API
     *
     */
    public static String buildQuery( final JsonNode queryConfig, final String q )
    {
        LOGGER.info( "Method buildQuery:: Passed [q param] value is - " + q );
        StringBuilder query = new StringBuilder();

        // Get default query params from configuration
        String typeField = queryConfig.get( "typeParameterName" ).asText();
        String typeValue = queryConfig.get( "typeParameterValue" ).asText();
        String dateField = queryConfig.get( "timeParameterName" ).asText();
        String queryFieldStartDate = queryConfig.get( "queryFieldStartDate" ).asText();
        String queryFieldEndDate = queryConfig.get( "queryFieldEndDate" ).asText();
        String queryFieldAtTime = queryConfig.get( "queryFieldAtTime" ).asText();

        query.append( typeField ).append( EQUALS_OPERATOR ).append( typeValue );

        buildDateQuery( q, query, dateField, queryFieldStartDate, queryFieldEndDate, queryFieldAtTime, true );

        LOGGER.info( "Method buildQuery:: Returned [q param] value is - " + query.toString() );
        return query.toString();
    }

    private static String buildSchemeQuery(
            String q,

            final String queryFieldSecheme,
            final String schemeParameterName )
    {
        Optional<String> qParam = Optional.ofNullable( q );
        StringBuilder query = new StringBuilder();
        // Check if q param has time param
        // If so, use it in final query
        if ( qParam.isPresent() && qParam.get().contains( queryFieldSecheme ) )
        {
            String qString = q.replace( queryFieldSecheme, schemeParameterName );

            query.append( qString );
        }
        // else, Do nothing as no scheme filter applied
        else
        {
            LOGGER.debug( " Scheme filter Not Applied " );
            return q;
        }
        return query.toString();

    }

    /**
     * This method appends the date criteria to the query.
     *
     * @param q
     *            {@link String} Actual query coming in
     * @param query
     *            {@link StringBuffer} Used to build the query
     * @param dateField
     *            {@link String} Date field to be replaced with in query
     * @param queryFieldStartDate
     *            {@link String} startDate coming in
     * @param queryFieldEndDate
     *            {@link String} endDate coming in
     * @param queryFieldAtTime
     *            {@link String} time coming in
     */
    private static void buildDateQuery(
            String q,
            final StringBuilder query,
            final String dateField,
            final String queryFieldStartDate,
            final String queryFieldEndDate,
            final String queryFieldAtTime,
            final boolean hasPreCondition )
    {
        Optional<String> qParam = Optional.ofNullable( q );
        // Check if q param has time param
        // If so, use it in final query
        if ( qParam.isPresent()
                && qParam.get().contains( queryFieldStartDate )
                && qParam.get().contains( queryFieldEndDate ) )
        {
            if ( hasPreCondition )
            {
                query.append( AND_OPERATOR );
            }
            q = q.replace( queryFieldStartDate, dateField );
            q = q.replace( queryFieldEndDate, dateField );
            q = q.replace( queryFieldAtTime, dateField );
            query.append( q );
        }
        // else, use default time param of 24 hours
        else
        {

            ZonedDateTime currentDate = ZonedDateTime.now();
            ZonedDateTime nextDate = currentDate.plusDays( 1 );
            String startdateTime = DateUtils.converDateToStringwithTimeZero( currentDate );
            String enddateTime = DateUtils.converDateToStringwithTimeZero( nextDate );
            if ( hasPreCondition )
            {
                query.append( AND_OPERATOR );
            }
            query.append(
                    dateField
                            + GREATER_THAN_EQUALS_OPERATOR
                            + startdateTime
                            + AND_OPERATOR
                            + dateField
                            + LESS_THAN_EQUALS_OPERATOR
                            + enddateTime );

            // add the rest of the q param
            if ( qParam.isPresent() )
            {
                query.append( AND_OPERATOR );
                query.append( q );

            }

        }

    }

    /**
     * This method builds the query for HopsQueuedMessages It replaces the date attributed received in query with actual
     * attributes from HopsStatus.
     *
     * @param queryConfig
     *            {@link JsonNode}
     * @param q
     *            {@link String}
     * @return
     */
    public static String buildQueryForProductQueuedMessages( final JsonNode queryConfig, String q )
    {

        String dateField = queryConfig.get( "timeParameterName" ).asText();
        String queryFieldStartDate = queryConfig.get( "queryFieldStartDate" ).asText();
        String queryFieldEndDate = queryConfig.get( "queryFieldEndDate" ).asText();
        String queryFieldAtTime = queryConfig.get( "queryFieldAtTime" ).asText();
        String queryFieldSecheme = queryConfig.get( "queryFieldScheme" ).asText();
        String schemeParameterName = queryConfig.get( "schemeParameterName" ).asText();

        StringBuilder query = new StringBuilder();
        if ( q != null )
        {
            q = buildSchemeQuery( q, queryFieldSecheme, schemeParameterName );
        }
        buildDateQuery( q, query, dateField, queryFieldStartDate, queryFieldEndDate, queryFieldAtTime, false );

        query.append( " " + SORT_BY + " " ).append( dateField ).append( " " + DESC );

        return query.toString();

    }

    /**
     *
     * @param q
     * @return a list of GraphIDs
     *
     *         Parse the q param to see what was passed in: /dashboard-views/q=dashboard={Dashboard ID} OR
     *         /dashboard-views/q=graph IN ({graphid1},{graphid2}..)
     *
     *         DVS-169: global scheme / time period filters can also be passed in:
     *         /dashboard-views/q=dashboard={Dashboard ID}[ AND scheme.link IN (schemelink1,
     *         ..)&startDate=...&endDate=...] OR /dashboard-views/q=graph IN ({graphid1},{graphid2}..)[ AND scheme.link
     *         IN (schemelink1, ..)&startDate=...&endDate=...]
     *
     *         Return the list of graphIDs corresponding to the DashBoard ID passed in OR the list of graph IDs
     *         directly.
     */
    public static List<String> getGraphIDsFromQParam( final String q, final DashBoardApiConfiguration apiConfiguration )
    {
        if ( StringUtils.isEmpty( q ) )
        {
            // Error - we got an empty query string - who would do this to us :(
            throw new BadParameterException(
                    String.format( "Empty q param - expected either of %s or %s", DASH_BOARD, GRAPH_ID ) );

        }

        ArrayList<String> graphIDs = null;
        String commaSeparatedGraphIDs;
        if ( q.contains( DASH_BOARD ) ) // we got a dashboard id. Check what it is
        {
            // see if there is more than one query param
            final int nextQueryParam = q.indexOf( "AND" );
            // +1 to account for the = sign
            String dashboard = q
                    .substring( q.indexOf( "=" ) + 1, nextQueryParam != -1 ? nextQueryParam : q.length() )
                    .trim();

            // see what graphs are configured for this dashboard
            switch ( dashboard )
            {
            case OPERATIONAL_DASHBOARD:
                LOGGER.debug( String.format( "Dashboard ID is %s", OPERATIONAL_DASHBOARD ) );
                commaSeparatedGraphIDs = apiConfiguration.getOperationalDashboard().get( "graphs" ).asText();
                break;

            case MANAGEMENT_DASHBOARD:
                LOGGER.debug( String.format( "Dashboard ID is %s", MANAGEMENT_DASHBOARD ) );
                commaSeparatedGraphIDs = apiConfiguration.getManagementDashboard().get( "graphs" ).asText();
                break;

            default:
                // Error - Found a dashboard that doesn't exist
                throw new BadParameterException( String.format( "Unknown Dashboard %s", dashboard ) );

            }
            LOGGER.debug( String.format( "Graphs for %s dashboard are %s", dashboard, commaSeparatedGraphIDs ) );
        }
        else if ( q.contains( GRAPH_ID ) )
        {
            // we got a query param in the form q=graph IN ({graphid1},{graphid2}..)
            commaSeparatedGraphIDs = q.substring( q.indexOf( "(" ) + 1, q.indexOf( ")" ) );
            LOGGER.debug( String.format( "Graphs in q param are %s", commaSeparatedGraphIDs ) );
        }
        else
        {
            // Error - we did not get either of the fields we were expecting
            throw new BadParameterException(
                    String.format( "Unknown field in q param - expected either of %s or %s", DASH_BOARD, GRAPH_ID ) );
        }
        graphIDs = new ArrayList<>( Arrays.asList( commaSeparatedGraphIDs.split( "\\s*,\\s*" ) ) );

        return graphIDs;
    }

    /**
     * @param graphId
     * @param q
     *            validating mandatory query parameter for drill down graph
     */
    public static void validateQueryParams( final String graphId, final String q )
    {
        if ( graphId.matches(
                "^.*?(ACTIONLISTGENERATIONDRILLDOWN|ACTIONLISTRECEIVEDDRILLDOWN|HOTLISTGENERATIONDRILLDOWN|HOTLISTRECEIVEDDRILLDOWN).*$" ) )
        {
            Optional<String> qParam = Optional.ofNullable( q );
            // Check if q param has time param // If so, use it in final query
            if ( !( qParam.isPresent()
                    && qParam.get().contains( "startDate" )
                    && qParam.get().contains( "endDate" )
                    && qParam.get().contains( "time" ) ) )
            {
                LOGGER.error( "Invalid query parameter for " + graphId + " graph ." );
                throw new BadParameterException( DEFAULT_BAD_PARAMETER_REQUEST_MSG );
            }
        }
    }

    /**
     * This method builds the query to fetch data for average line's average calculation
     *
     * @param graphConfig
     * @param key
     * @param earliestDate
     * @param rollBackNumber
     * @param query
     */
    public static String buildQueryToFetchDataForAvergaeLineCalculation(
            final JsonNode graphConfig,
            final String key,
            final ZonedDateTime earliestDate,
            final String nameParameter )
    {

        StringBuilder query = new StringBuilder();
        // read name and date parameter names
        String dateField = graphConfig.get( "timeParameterName" ).asText();
        String name = graphConfig.get( nameParameter ).asText();
        query
                .append( dateField )
                .append( LESS_THAN_OPERATOR )
                .append( DateUtils.converDateToString( earliestDate ) )
                .append( AND_OPERATOR )
                .append( name )
                .append( EQUALS_OPERATOR )
                .append( key )
                .append( " " + SORT_BY + " " )
                .append( dateField )
                .append( " " + DESC );

        return query.toString();

    }

    private static String queryForm(
            ZonedDateTime previous_date,
            ZonedDateTime currentDate,
            String timeFilter,
            String remainingQuery )
    {
        String query;
        String updated_previous_date = DateUtils.converDateToString( previous_date );
        String updated_currentDate = DateUtils.converDateToString( currentDate );
        query = timeFilter
                + GREATER_THAN_EQUALS_OPERATOR
                + updated_previous_date
                + " AND "
                + timeFilter
                + LESS_THAN_EQUALS_OPERATOR
                + updated_currentDate;
        if ( !( remainingQuery.isEmpty() ) )
        {
            query = query + " AND " + remainingQuery;
        }

        return query;
    }

    public static String buildQueryJourneySummary(
            Map<String, String> queryMap,
            JsonNode graphConfig,
            boolean historyData )
    {
        String timeFilter = graphConfig.get( "timeFilter" ).asText();
        String quryFeildStartDate = graphConfig.get( "queryFieldStartDate" ).asText();
        int rollBackNumber = graphConfig.get( "rollBackNumber" ).asInt();

        ZonedDateTime currentDate = ZonedDateTime.now();
        String buildQuery = null;
        ZonedDateTime currentDataEndDate = null;
        ZonedDateTime currentDataStartDate = null;
        ZonedDateTime averageDataEndDate = null;
        ZonedDateTime averageDataStartDate = null;

        switch ( queryMap.get( timeFilter ) )
        {
        case LAST_8_DAYS:
            currentDataEndDate = currentDate.withHour( TWENTY_THREE ).withMinute( FIFTY_NINE ).withSecond( FIFTY_NINE );
            currentDataStartDate = currentDataEndDate.minusDays( EIGHT ).plusSeconds( 1 );

            averageDataEndDate = currentDataStartDate.minusSeconds( 1 );
            averageDataStartDate = currentDataStartDate.minusDays( rollBackNumber * SEVEN );

            break;
        case LAST_8_WEEKS:
            currentDataEndDate = currentDate
                    .with( DayOfWeek.SUNDAY )
                    .withHour( TWENTY_THREE )
                    .withMinute( FIFTY_NINE )
                    .withSecond( FIFTY_NINE );
            currentDataStartDate = currentDataEndDate
                    .minusWeeks( EIGHT )
                    .plusDays( 1 )
                    .withHour( 00 )
                    .withMinute( 00 )
                    .withSecond( 00 );

            averageDataEndDate = currentDataStartDate.minusSeconds( 1 );
            averageDataStartDate = currentDataStartDate.minusWeeks( rollBackNumber );
            break;

        case LAST_8_MONTHS:
            currentDataEndDate = currentDate
                    .plusDays( currentDate.getMonth().maxLength() - currentDate.getDayOfMonth() );
            currentDataEndDate = currentDataEndDate
                    .withHour( TWENTY_THREE )
                    .withMinute( FIFTY_NINE )
                    .withSecond( FIFTY_NINE );
            currentDataStartDate = currentDataEndDate.minusMonths( EIGHT );
            currentDataStartDate = currentDataStartDate
                    .withDayOfMonth( currentDataStartDate.getMonth().maxLength() )
                    .plusSeconds( 1 );
            // go to next day 0:0:0

            averageDataEndDate = currentDataStartDate.minusSeconds( 1 );
            averageDataStartDate = currentDataStartDate.minusMonths( rollBackNumber );
            break;
        default:
            throw new BadParameterException(
                    "None of the filters matched for "
                            + timeFilter
                            + " should be either LAST_8_DAYS, LAST_8_WEEKS or LAST_8_MONTHS" );
        }
        if ( historyData )
        {
            buildQuery = queryForm(
                    averageDataStartDate,
                    averageDataEndDate,
                    quryFeildStartDate,
                    queryMap.get( QUERY_KEY ) );
        }
        else
        {
            buildQuery = queryForm(
                    currentDataStartDate,
                    currentDataEndDate,
                    quryFeildStartDate,
                    queryMap.get( QUERY_KEY ) );
        }
        LOGGER.info( "Query  " + queryMap.get( timeFilter ) + " data" + " >>>>>>>>>  " + buildQuery );
        return buildQuery;
    }
}
