package net.weareact.api.impl.utils;

import java.time.DayOfWeek;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import net.weareact.api.NotFoundException;
import net.weareact.api.impl.GraphDataCreatorFromJourneysSummary;
import net.weareact.common.dropwizard.security.ACTClaims;
import net.weareact.common.exceptionhandling.BadParameterException;
import net.weareact.journeys.model.GroupSummary;
import net.weareact.journeys.model.SummaryResponse;
import net.weareact.model.GraphDataPoint;
import net.weareact.model.PointData;
import net.weareact.model.ServiceError;

public class JourneyRecordsReceivedUtil
{

    private static final String         QUERY_KEY                    = "query";

    private static final Logger         LOGGER                       = LoggerFactory
                                                                             .getLogger(
                                                                                     DashboardViewsImplUtil.class
                                                                                             .getName() );

    private static final String         AND_OPERATOR                 = " AND ";
    private static final String         EQUALS_OPERATOR              = " = ";
    private static final String         GREATER_THAN_EQUALS_OPERATOR = ">=";
    private static final String         LESS_THAN_EQUALS_OPERATOR    = "<=";
    private static final String         LAST_8_DAYS                  = "LAST_8_DAYS";

    private static final String         LAST_8_WEEKS                 = "LAST_8_WEEKS";
    private static final String         LAST_8_MONTHS                = "LAST_8_MONTHS";

    private static final String         HTTP_HEADER_JWT              = "X-JWT-Assertion";
    private static final String         RECEIVED_JOURNEYS_LEGEND     = "received";
    private static final String         DATA_POINT_LEGEND            = "dataPointLegend";
    private static final String         LOCALE_ALL                   = "locale-all";
    GraphDataCreatorFromJourneysSummary creator                      = new GraphDataCreatorFromJourneysSummary();
    GroupSummary                        averageSummary;
    Map<String, Integer>                totalAverageSummary          = new HashMap<>();

    List<GraphDataPoint> getGraphDataForJourneyRecordsReceivedDrilldown(
            String xJWTAssertion,
            String q,
            JsonNode graphConfig,
            ACTClaims claims ) throws NotFoundException
    {
        List<GraphDataPoint> graphDataPoints = new ArrayList<>();
        GraphDataPoint averageGraphDataPoint;
        // Parse q param to get query and time filter

        String timeFilter = graphConfig.get( "timeFilter" ).asText();
        String columnIndex = graphConfig.get( "columnIndex" ).asText();
        String drilldownGrouping = graphConfig.get( "drilldownGrouping" ).asText();
        int rollBackNumber = graphConfig.get( "rollBackNumber" ).asInt();

        Map<String, String> queryMap = parseQueryString( q, timeFilter, columnIndex );

        // validate that we got a columnIndex between 1 and 8 incl
        int colIndex = Integer.parseInt( queryMap.get( columnIndex ) );
        if ( colIndex < 1 || colIndex > 8 )
        {
            LOGGER.error( " getGraphDataForJourneyRecordsReceivedDrilldown - did not get columnIndex value " );
            throw new BadParameterException( "columnIndex is missing or invalid" );
        }

        // Figure out time period of journey summaries to fetch from q and time filter
        String queryString = buildQueryForDrilldown( queryMap, graphConfig, false, 0 );

        // call the journey service summary endpoint - get list of JourneySummary s
        String endPoint = graphConfig.get( "endPoint" ).asText();
        GroupSummary summary = callJourneySummaryService( endPoint, queryString, xJWTAssertion, drilldownGrouping );

        // create graph data points for current data
        GraphDataPoint currentGraphDataPoint = createGraphDataForJourneyReceivedDrilldown(
                graphConfig,
                queryMap,
                summary,
                claims );
        LOGGER.info( "Current  Day Data : " + currentGraphDataPoint );

        // For average GraphDataPoint

        if ( queryMap.get( timeFilter ).equals( LAST_8_DAYS ) )
        {
            String buildQuery;

            // iterating upto rollBackNummber, create multiple query
            for ( int i = 1; i <= rollBackNumber; i++ )
            {

                buildQuery = buildQueryForDrilldown( queryMap, graphConfig, true, i );

                averageSummary = callJourneySummaryService( endPoint, buildQuery, xJWTAssertion, drilldownGrouping );

                Map<String, GroupSummary> eachSummary = averageSummary.getSubGroups();
                eachSummary.keySet().forEach( key ->
                {

                    if ( totalAverageSummary.containsKey( key ) )
                    {
                        Integer journeyCountForDay = totalAverageSummary.get( key );
                        totalAverageSummary.put( key, journeyCountForDay + eachSummary.get( key ).getTotal() );
                    }
                    else
                    {
                        totalAverageSummary.put( key, eachSummary.get( key ).getTotal() );
                    }

                } );
            }
        }
        else
        {
            String averageQuery = buildQueryForDrilldown( queryMap, graphConfig, true, 0 );
            GroupSummary avgSummary = callJourneySummaryService(
                    endPoint,
                    averageQuery,
                    xJWTAssertion,
                    drilldownGrouping );
            Map<String, GroupSummary> eachSummary = avgSummary.getSubGroups();
            eachSummary.keySet().forEach( key ->
            {

                if ( totalAverageSummary.containsKey( key ) )
                {
                    Integer journeyCountForDay = totalAverageSummary.get( key );
                    totalAverageSummary.put( key, journeyCountForDay + eachSummary.get( key ).getTotal() );
                }
                else
                {
                    totalAverageSummary.put( key, eachSummary.get( key ).getTotal() );
                }

            } );

        }

        averageGraphDataPoint = creator
                .createAverageGraphDataForDrillDown( graphConfig, queryMap.get( timeFilter ), totalAverageSummary );
        LOGGER.info( "Average 8 Day filter : " + averageGraphDataPoint );

        graphDataPoints = creator.setEmptyPointDataInCurrentAndAverageDrilldown(
                graphConfig,
                currentGraphDataPoint,
                averageGraphDataPoint );

        return graphDataPoints;
    }

    /**
     * <pre>
     * Process the summary response in this format:
     * "summary": {
     * "total": 82,
     * "subGroups": {
     *   "SCHEME.ABBREV": {
     *     "total": 2,
     *     "subGroups": {}
     *   },
     *   "ACT": {
     *     "total": 2,
     *     "subGroups": {}
     *   }
     *  }
     * </pre>
     * 
     * And convert into a list of @see PointValue
     */
    private GraphDataPoint createGraphDataForJourneyReceivedDrilldown(
            JsonNode graphConfig,
            Map<String, String> queryMap,
            GroupSummary summary,
            ACTClaims claims )
    {
        String defaultLocale = graphConfig.get( LOCALE_ALL ).asText();
        GraphDataPoint graphDataPoint = new GraphDataPoint();
        Map<String, GroupSummary> subGroups = summary.getSubGroups();
        Map<String, String> legends = readValue( graphConfig, DATA_POINT_LEGEND, RECEIVED_JOURNEYS_LEGEND );
        graphDataPoint.setDataPointLegend( legends );

        // prepare the list of DataPointValues
        List<PointData> pointDataList = new ArrayList<>();
        // iterate over the map of subGroups
        subGroups.forEach( ( k, v ) ->
        {
            PointData pointData = new PointData();
            pointData.setPointValue( v.getTotal() );
            pointData.setPointLegend( legends );

            Map<String, String> pointKeyMap = new HashMap<String, String>();
            pointKeyMap.put( defaultLocale, k );
            pointData.setPointKey( pointKeyMap );

            pointDataList.add( pointData );
        } );
        graphDataPoint.setDataPointValues( pointDataList );
        // TODO: add zero value points for all schemes which are in claims but missing from the response
        return graphDataPoint;
    }

    public String buildQueryForDrilldown(
            Map<String, String> queryMap,
            JsonNode graphConfig,
            boolean averageQuery,
            int i )
    {
        String timeFilter = graphConfig.get( "timeFilter" ).asText();
        String columnIndex = graphConfig.get( "columnIndex" ).asText();
        String queryFieldStartDate = graphConfig.get( "queryFieldStartDate" ).asText();
        int rollBackNumber = graphConfig.get( "rollBackNumber" ).asInt();
        int column = Integer.parseInt( queryMap.get( columnIndex ) );

        ZonedDateTime today = getCurrentDate(); // easier to test than calling a static ZonedDateTime.now method
        String buildQuery = null;
        ZonedDateTime currentDataEndDate = null, currentDataStartDate = null;
        ZonedDateTime averageDataEndDate = null, averageDataStartDate = null;

        switch ( queryMap.get( timeFilter ) )
        {
        case LAST_8_DAYS:
            // column index is the index of the top level graph's column which was selected
            // columns are numbered left to right so get the column's date wrt the current date
            currentDataStartDate = today.minusDays( 8 - column ).withHour( 00 ).withMinute( 00 ).withSecond( 00 );
            currentDataEndDate = today.minusDays( 8 - column ).withHour( 23 ).withMinute( 59 ).withSecond( 59 );

            averageDataStartDate = currentDataStartDate.minusDays( i * 7 );
            averageDataEndDate = currentDataEndDate.minusDays( i * 7 );

            break;
        case LAST_8_WEEKS:
            currentDataEndDate = today
                    .minusWeeks( 8 - column )
                    .with( DayOfWeek.SUNDAY )
                    .withHour( 23 )
                    .withMinute( 59 )
                    .withSecond( 59 );
            currentDataStartDate = currentDataEndDate.minusDays( 6 ).withHour( 00 ).withMinute( 00 ).withSecond( 00 );

            averageDataStartDate = currentDataStartDate.minusWeeks( rollBackNumber );
            averageDataEndDate = currentDataStartDate.minusSeconds( 1 );
            break;

        case LAST_8_MONTHS:
            ZonedDateTime month = today.minusMonths( 8 - column );
            currentDataEndDate = month
                    .withDayOfMonth( month.getMonth().maxLength() )
                    .withHour( 23 )
                    .withMinute( 59 )
                    .withSecond( 59 );
            // currentDataStartDate = currentDataEndDate.minusMonths( month.getMonth().maxLength() - 1 );
            currentDataStartDate = currentDataEndDate
                    .withDayOfMonth( 1 )
                    .withHour( 00 )
                    .withMinute( 00 )
                    .withSecond( 00 );

            averageDataStartDate = currentDataStartDate.minusMonths( rollBackNumber );
            averageDataEndDate = currentDataStartDate.minusSeconds( 1 );

            break;

        default:
            throw new BadParameterException(
                    "None of the filters matched for "
                            + timeFilter
                            + " should be either LAST_8_DAYS, LAST_8_WEEKS or LAST_8_MONTHS" );

        }
        if ( averageQuery )
        {
            buildQuery = queryFieldStartDate
                    + GREATER_THAN_EQUALS_OPERATOR
                    + DateUtils.converDateToString( averageDataStartDate )
                    + AND_OPERATOR
                    + queryFieldStartDate
                    + LESS_THAN_EQUALS_OPERATOR
                    + DateUtils.converDateToString( averageDataEndDate );
            if ( !StringUtils.isBlank( queryMap.get( QUERY_KEY ) ) )
            {
                buildQuery = buildQuery + AND_OPERATOR + queryMap.get( QUERY_KEY );
            }
        }
        else
        {
            buildQuery = queryFieldStartDate
                    + GREATER_THAN_EQUALS_OPERATOR
                    + DateUtils.converDateToString( currentDataStartDate )
                    + AND_OPERATOR
                    + queryFieldStartDate
                    + LESS_THAN_EQUALS_OPERATOR
                    + DateUtils.converDateToString( currentDataEndDate );
            if ( !StringUtils.isBlank( queryMap.get( QUERY_KEY ) ) )
            {
                buildQuery = buildQuery + AND_OPERATOR + queryMap.get( QUERY_KEY );
            }
        }

        LOGGER.info( "Query for " + timeFilter + " days data" + " >>>>>>>>>  " + buildQuery );

        return buildQuery;
    }

    protected ZonedDateTime getCurrentDate()
    {
        return ZonedDateTime.now();
    }

    List<GraphDataPoint> getGraphDataForJourneyRecordsReceived( String xJWTAssertion, String q, JsonNode graphConfig )
            throws NotFoundException
    {

        String timeFilter = graphConfig.get( "timeFilter" ).asText();
        String grouping = graphConfig.get( "grouping" ).asText();

        List<GraphDataPoint> graphDataPoints = new ArrayList<>();
        Map<String, String> queryMap = parseQueryString( q, timeFilter, "-1" );

        String queryString = DashboardViewsImplQueryUtil.buildQueryJourneySummary( queryMap, graphConfig, false );

        // make a call to the end point to get List Of JourneySummary Objects
        String endPoint = graphConfig.get( "endPoint" ).asText();
        GroupSummary summary = callJourneySummaryService( endPoint, queryString, xJWTAssertion, grouping );

        // create Graph Data for current data
        GraphDataPoint currentGraphDataPoint = creator
                .createCurrentGraphDataForReceivedJourneys( graphConfig, queryMap.get( timeFilter ), summary );

        graphDataPoints.add( currentGraphDataPoint );

        String avgQueryString = DashboardViewsImplQueryUtil.buildQueryJourneySummary( queryMap, graphConfig, true );
        GroupSummary averageSummary = callJourneySummaryService( endPoint, avgQueryString, xJWTAssertion, grouping );
        GraphDataPoint averageGraphDataPoint = creator
                .createAverageGraphDataForReceivedJourneys( graphConfig, queryMap.get( timeFilter ), averageSummary );

        graphDataPoints.add( averageGraphDataPoint );

        return graphDataPoints;
    }

    /**
     * This method breaks the query and extracts value for "timeFilter" parameter and also extracts remaining query
     * excluding timeFilter
     * 
     * @param query
     * @param timeFilter
     * @param columnIndex
     * @return {@link Map}
     * 
     *         drilldown graph query would be of the form
     *         /dashboard-views/JOURNEY_RECEIVED_DRILLDOWN?q=timeFilter=LAST_8_DAYS AND columnIndex=3 [AND scheme.link
     *         IN (…. )]
     * 
     * 
     */
    Map<String, String> parseQueryString( String query, String timeFilter, String columnIndex )
    {
        Map<String, String> queryMap = new HashMap<>();
        // Query Parsing logic
        Optional<String> qParam = Optional.ofNullable( query );
        String valueOfTimeParameter = LAST_8_DAYS;
        String valueOfColumnIndexParameter = "-1";
        StringBuilder queryBuilder = new StringBuilder();
        if ( qParam.isPresent() )
        {
            // query contains atleast 2 params separated by AND
            if ( qParam.get().contains( AND_OPERATOR ) )
            {
                // split by AND - this would be much easier if we had actual query params
                String[] queryParams = qParam.get().split( AND_OPERATOR );
                for ( int i = 0; i < queryParams.length; i++ )
                {
                    // is this a timeFilter = blah part?
                    if ( queryParams[ i ].startsWith( timeFilter ) )
                    {
                        String[] timeParameterQuery = queryParams[ i ].split( EQUALS_OPERATOR.trim() );
                        valueOfTimeParameter = timeParameterQuery[ 1 ];
                    }
                    // is this a columnIndex = bleh part?
                    else if ( queryParams[ i ].startsWith( columnIndex ) )
                    {
                        String[] columnIndexQuery = queryParams[ i ].split( EQUALS_OPERATOR.trim() );
                        valueOfColumnIndexParameter = columnIndexQuery[ 1 ];
                    }
                    // has to be something else - lump it with the rest
                    else
                    {
                        if ( queryBuilder.length() != 0 )
                        {
                            queryBuilder.append( AND_OPERATOR );
                        }
                        queryBuilder.append( queryParams[ i ] );

                    }

                }

            }
            // no ANDs in the q string - did we get only a timeFilter?
            else if ( qParam.get().startsWith( timeFilter ) )
            {
                String[] timeParameterQuery = qParam.get().split( EQUALS_OPERATOR.trim() );
                valueOfTimeParameter = timeParameterQuery[ 1 ];
            }
            // no? did we get a columnIndex then ?
            else if ( qParam.get().startsWith( columnIndex ) )
            {
                String[] columnIndexQuery = qParam.get().split( EQUALS_OPERATOR.trim() );
                valueOfColumnIndexParameter = columnIndexQuery[ 1 ];
            }

            // must be something else. lump it in the query
            else
            {
                if ( !StringUtils.isEmpty( query ) )
                {
                    queryBuilder.append( query );
                }

            }

        }
        queryMap.put( timeFilter, valueOfTimeParameter.trim() );
        queryMap.put( QUERY_KEY, queryBuilder.toString().trim() );
        queryMap.put( columnIndex, valueOfColumnIndexParameter.trim() );
        return queryMap;
    }

    GroupSummary callJourneySummaryService( String endPoint, String queryString, String xJWTAssertion, String groupby )
            throws NotFoundException
    {
        LOGGER.info( "Method callJourneyServiceEndpoint:: Going to hit /journeys/summary" );
        Response response = null;

        // hit the JourneyService API to fetch the data
        Client apiClient = ClientBuilder.newClient();
        WebTarget target;

        // TODO remove hardcoded value for grouping
        target = apiClient.target( endPoint ).queryParam( "q", queryString ).queryParam( "grouping", groupby );

        LOGGER.info(
                "Method callJourneyServiceEndpoint:: Calling endpoint - ["
                        + endPoint
                        + "] with queryString ["
                        + queryString
                        + "] with grouping ["
                        + groupby
                        + "]" );

        try
        {

            response = target.request().header( HTTP_HEADER_JWT, xJWTAssertion ).get();
        }
        catch ( Exception ex )
        {
            // JourneyService is unavailable!
            LOGGER.error( String.format( "Journey Summary is unavailable - %s", ex ) );
            throw new net.weareact.api.NotFoundException(
                    String.format( "Journey Summary is unavailable - %s", ex.getMessage() ) );
        }

        if ( response.getStatus() != HttpStatus.SC_OK )
        {
            LOGGER.error(
                    "Method callJourneyServiceEndpoint:: Bad Request:: API Response is - " + response.toString() );
            ServiceError targetApiServiceError = response.readEntity( ServiceError.class );
            throw new BadParameterException( targetApiServiceError.getUserMessage() );
        }

        SummaryResponse summaryResponse = response.readEntity( SummaryResponse.class );
        LOGGER.info( "Method callJourneyServiceEndpoint:: Returning response - " + summaryResponse );
        return summaryResponse.getSummary();
    }

    /**
     * This method reads the value of status in dataPointLegend or pointLegend nodes
     * 
     * @param graphConfig
     * @param legendField
     * @param statusField
     * @return
     */
    @SuppressWarnings( "unchecked" )
    private Map<String, String> readValue( JsonNode graphConfig, String legendField, String statusField )
    {
        JsonNode dpLegend = graphConfig.get( legendField );
        Map<String, Map<String, String>> legends = new ObjectMapper().convertValue( dpLegend, Map.class );
        return legends.get( statusField );
    }

}
