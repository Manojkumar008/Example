package net.weareact.api.impl.config;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.validation.Validation;

import org.apache.commons.io.IOUtils;

import io.dropwizard.configuration.ConfigurationException;
import io.dropwizard.configuration.ConfigurationFactory;
import io.dropwizard.jackson.Jackson;
import io.dropwizard.lifecycle.Managed;

/**
 * @author mehtapra
 * 
 *         This class is a managed Bean to load the configuration file which defines parameters to call Distribution
 *         List Service
 * 
 *         for example host , port, endpoint and parameter names to build the query parameter .
 *
 */
public class ConfigurationLoader implements Managed
{

    private final DashBoardApiConfiguration dashBoardApiConfiguration;

    /**
     * @param dashBoardApiConfiguration
     *            : Custom Configuration Object
     * @throws IOException
     * @throws ConfigurationException
     * 
     *             This methods includes the code to read the Yaml File.
     */
    public ConfigurationLoader( DashBoardApiConfiguration dashBoardApiConfiguration )
            throws IOException,
            ConfigurationException
    {

        ConfigurationFactory<DashBoardApiConfiguration> configurationFactory = new ConfigurationFactory(
                DashBoardApiConfiguration.class,
                Validation.buildDefaultValidatorFactory().getValidator(),
                Jackson.newObjectMapper(),
                "d" );
        InputStream stream = this.getClass().getClassLoader().getResourceAsStream( "dashboard-internal.yml" );
        File tempFile = File.createTempFile( "dashboard-internal", "tmp" );
        tempFile.deleteOnExit();
        FileOutputStream out = new FileOutputStream( tempFile );
        IOUtils.copy( stream, out );

        this.dashBoardApiConfiguration = configurationFactory.build( tempFile );
    }

    @Override
    public void start() throws Exception
    {

    }

    @Override
    public void stop() throws Exception
    {

    }

    public DashBoardApiConfiguration getDashBoardApiConfiguration()
    {
        return dashBoardApiConfiguration;
    }

}
