/*
 * ************************************************************************** Copyright 2016 Applied Card Technologies
 * Ltd
 ****************************************************************************/

package net.weareact.api.impl.utils;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import net.weareact.api.NotFoundException;
import net.weareact.api.impl.CreateGraphDataFromCmsStatusList;
import net.weareact.api.impl.CreateGraphDataFromHopsStatusList;
import net.weareact.api.impl.DistributionListToGraphDataForDrillDown;
import net.weareact.api.impl.DistributionListToGraphDataForTopLevelGraph;
import net.weareact.api.impl.config.DashBoardApiConfiguration;
import net.weareact.cmsstatuses.model.CmsStatus;
import net.weareact.cmsstatuses.model.CmsStatusesResponse;
import net.weareact.common.dropwizard.security.ACTClaims;
import net.weareact.common.dropwizard.security.ResourceLink;
import net.weareact.common.exceptionhandling.BadParameterException;
import net.weareact.dashboardview.model.DistributionList;
import net.weareact.dashboardview.model.DistributionListsResponse;
import net.weareact.dashboardview.model.ReceivedDistributionList;
import net.weareact.dashboardview.model.ReceivedDistributionListsResponse;
import net.weareact.dashboardview.model.SchemeLink;
import net.weareact.hopsstatus.model.HopsStatus;
import net.weareact.hopsstatus.model.HopsStatusesResponse;
import net.weareact.model.DashboardView;
import net.weareact.model.DashboardView.GraphTypeEnum;
import net.weareact.model.GraphDataPoint;
import net.weareact.model.LegendKey;
import net.weareact.model.ServiceError;

/**
 * @author mehtapra
 *
 */
public class DashboardViewsImplUtil
{
    private static final Logger             LOGGER                      = LoggerFactory
            .getLogger( DashboardViewsImplUtil.class.getName() );
    private static final String             DEFAULT_USER_ERROR_MSG      = "An unknown Error has occoured while processing your Request.";
    private static final String             DEFAULT_DEVELOPER_ERROR_MSG = "Details about this error available in logs using unique reference: ";

    private static final String             DEFAULT_CASE_MSG            = "Invalid graph Id passed to request.";

    private final DashBoardApiConfiguration apiConfiguration;

    private static final String             HTTP_HEADER_JWT             = "X-JWT-Assertion";

    public DashboardViewsImplUtil( final DashBoardApiConfiguration apiConfiguration )
    {
        this.apiConfiguration = apiConfiguration;
    }

    public DashboardView prepareGraphData(
            final ACTClaims claim,
            final String graph,
            final String xJWTAssertion,
            final String q ) throws BadParameterException, NotFoundException
    {

        LOGGER.info( "Method prepareGraphData:: Graph ID is [" + graph + "]" );

        List<GraphDataPoint> graphDataPointList = null;
        JsonNode graphConfig = null;

        switch ( graph.toUpperCase() )
        {
        case "ACTIONLIST_GENERATION":
            graphConfig = apiConfiguration.getActionListGeneration();
            graphDataPointList = getGraphDataForDistributionListsGenerated( xJWTAssertion, q, graphConfig );
            break;
        case "HOTLIST_GENERATION":
            graphConfig = apiConfiguration.getHotListGeneration();
            graphDataPointList = getGraphDataForDistributionListsGenerated( xJWTAssertion, q, graphConfig );
            break;
        case "ACTIONLIST_RECEIVED":
            graphConfig = apiConfiguration.getActionListReceived();
            graphDataPointList = getGraphDataForDistributionListReceived( xJWTAssertion, q, graphConfig );
            break;
        case "HOTLIST_RECEIVED":
            graphConfig = apiConfiguration.getHotListReceived();
            graphDataPointList = getGraphDataForDistributionListReceived( xJWTAssertion, q, graphConfig );
            break;
        case "ACTIONLIST_GENERATION_DRILLDOWN":
            graphConfig = apiConfiguration.getActionListGenerationDrillDown();
            graphDataPointList = getGraphDataForDistributionListsGeneratedGrillDown(
                    xJWTAssertion,
                    q,
                    graphConfig,
                    claim );
            break;
        case "ACTIONLIST_RECEIVED_DRILLDOWN":
            graphConfig = apiConfiguration.getActionListReceivedDrillDown();
            graphDataPointList = getGraphDataForDistributionListsReceivedDrillDown(
                    xJWTAssertion,
                    q,
                    graphConfig,
                    claim );
            break;
        case "HOTLIST_RECEIVED_DRILLDOWN":
            graphConfig = apiConfiguration.getHotListReceivedDrillDown();
            graphDataPointList = getGraphDataForDistributionListsReceivedDrillDown(
                    xJWTAssertion,
                    q,
                    graphConfig,
                    claim );
            break;
        case "HOTLIST_GENERATION_DRILLDOWN":
            graphConfig = apiConfiguration.getHotListGenerationDrillDown();
            graphDataPointList = getGraphDataForDistributionListsGeneratedGrillDown(
                    xJWTAssertion,
                    q,
                    graphConfig,
                    claim );
            break;
        case "HOPS_QUEUED_MESSAGES":
            graphConfig = apiConfiguration.getHopsQueuedMessages();
            graphDataPointList = getGraphDataForHopsQueuedMessages( xJWTAssertion, q, graphConfig );
            break;
        case "CMS_QUEUED_MESSAGES":
            graphConfig = apiConfiguration.getCmsQueuedMessages();
            graphDataPointList = getGraphDataForCmsQueuedMessages( xJWTAssertion, q, graphConfig );
            break;
        case "JOURNEY_RECORDS_RECEIVED":
            graphConfig = apiConfiguration.getJourneyRecordReceived();
            graphDataPointList = new JourneyRecordsReceivedUtil()
                    .getGraphDataForJourneyRecordsReceived( xJWTAssertion, q, graphConfig );
            break;
        case "JOURNEY_RECORDS_RECEIVED_DRILLDOWN":
            graphConfig = apiConfiguration.getJourneyRecordReceived();
            graphDataPointList = new JourneyRecordsReceivedUtil()
                    .getGraphDataForJourneyRecordsReceivedDrilldown( xJWTAssertion, q, graphConfig, claim );
            break;

        case "UNLINKED_JOURNEYS":
            // to fetch the basic configuration details about unlinked journey graph data
            graphConfig = apiConfiguration.getUnlinkedJourney();
            // to fetch the unlinked journey graph data based on the financial period and journey summary
            graphDataPointList = new UnlinkedJourneyUtil()
                    .getGraphDataForUnlinkedJourney( xJWTAssertion, q, graphConfig, claim );
            break;
        default:
            LOGGER.info( "Method prepareGraphData:: No Case Matched :::::" );
            throw new BadParameterException( DEFAULT_CASE_MSG );
        }

        // preparing response
        LOGGER.info( "Method prepareGraphData:: Preparing DashboardView object :::::" );

        DashboardView dashboardView = new DashboardView();
        JsonNode xAxisLabelNode = graphConfig.get( "xAxisLabel" );
        JsonNode yAxisLabelNode = graphConfig.get( "yAxisLabel" );
        String graphType = graphConfig.get( "graphType" ).asText();
        JsonNode graphLegendNode = graphConfig.get( "graphLegend" );

        ObjectMapper mapper = new ObjectMapper();
        Map<String, String> xAxisLabelMap = mapper.convertValue( xAxisLabelNode, Map.class );
        Map<String, String> yAxisLabelMap = mapper.convertValue( yAxisLabelNode, Map.class );
        List<Map<String, String>> temp = mapper.convertValue( graphLegendNode, List.class );

        List<LegendKey> graphLegends = new ArrayList<>();

        for ( Map<String, String> map : temp )
        {
            LegendKey lk = new LegendKey();
            lk.setKey( map );
            graphLegends.add( lk );

        }

        dashboardView.setXAxisLabel( xAxisLabelMap );
        dashboardView.setYAxisLabel( yAxisLabelMap );
        dashboardView.setGraphType( mapStringToGraphType( graphType ) );
        dashboardView.setGraphLegend( graphLegends );

        dashboardView.graphData( graphDataPointList );
        dashboardView.setGraph( graph );

        LOGGER.info( "Method prepareGraphData:: Returning DashboardView object :::::" );
        return dashboardView;
    }

    /**
     * This medhod hits hops-status service to retrieve HopsStatusResponse and translate it into DahsboardViw for
     * HopsQueueStatus graph
     *
     * @param xJWTAssertion
     * @param q
     * @param graphConfig
     * @return
     * @throws NotFoundException
     * @throws BadParameterException
     */
    private List<GraphDataPoint> getGraphDataForHopsQueuedMessages(
            final String xJWTAssertion,
            final String q,
            final JsonNode graphConfig ) throws BadParameterException, NotFoundException
    {
        String queryString = DashboardViewsImplQueryUtil.buildQueryForProductQueuedMessages( graphConfig, q );

        // make a call to the end point to get List Of HopsStatus Objects
        List<HopsStatus> hopsStatusListAll = callHopsStatusService( graphConfig, queryString, xJWTAssertion );

        return new CreateGraphDataFromHopsStatusList().create( xJWTAssertion, graphConfig, hopsStatusListAll );

    }

    private List<HopsStatus> callHopsStatusService(
            final JsonNode graphConfig,
            final String queryString,
            final String xJWTAssertion ) throws BadParameterException, NotFoundException
    {
        List<HopsStatus> hopsStatusList = new ArrayList<>();
        HopsStatusesResponse response = null;
        int count = 0;
        int offset = 0;
        do
        {

            if ( count > 0 && response != null )
            {
                offset = offset + ( response.getMeta().getLimit().intValue() );
            }

            Response apiResponse = callEndpointToFetchData( graphConfig, queryString, offset, xJWTAssertion );
            response = apiResponse.readEntity( HopsStatusesResponse.class );

            hopsStatusList.addAll( response.getHopsStatuses() );
            count++;
        }
        while ( response.getMeta() != null && hopsStatusList.size() < response.getMeta().getTotalCount() );

        return hopsStatusList;
    }

    /**
     * This medhod hits Cms-status service to retrieve CmsStatusResponse and translate it into DahsboardViw for
     * CmsQueueStatus graph
     *
     * @param xJWTAssertion
     * @param q
     * @param graphConfig
     * @return
     * @throws NotFoundException
     * @throws BadParameterException
     */
    private List<GraphDataPoint> getGraphDataForCmsQueuedMessages(
            final String xJWTAssertion,
            final String q,
            final JsonNode graphConfig ) throws BadParameterException, NotFoundException
    {
        String queryString = DashboardViewsImplQueryUtil.buildQueryForProductQueuedMessages( graphConfig, q );

        // make a call to the end point to get List Of CmsStatus Objects
        List<CmsStatus> cmsStatusListAll = callCmsStatusService( graphConfig, queryString, xJWTAssertion );

        return new CreateGraphDataFromCmsStatusList().create( xJWTAssertion, graphConfig, cmsStatusListAll );

    }

    private List<CmsStatus> callCmsStatusService(
            final JsonNode graphConfig,
            final String queryString,
            final String xJWTAssertion ) throws BadParameterException, NotFoundException
    {
        List<CmsStatus> cmsStatusList = new ArrayList<>();
        CmsStatusesResponse response = null;
        int count = 0;
        int offset = 0;
        do
        {

            if ( count > 0 && response != null )
            {
                offset = offset + ( response.getMeta().getLimit().intValue() );
            }

            Response apiResponse = callEndpointToFetchData( graphConfig, queryString, offset, xJWTAssertion );

            response = apiResponse.readEntity( CmsStatusesResponse.class );

            cmsStatusList.addAll( response.getCmsStatuses() );
            count++;
        }
        while ( response.getMeta() != null && cmsStatusList.size() < response.getMeta().getTotalCount() );

        return cmsStatusList;
    }

    /**
     * This method hits {received-distribution-lists} end point to retrieve ReceivedDistributionListsResponse response
     * and aggregate data by date-time
     *
     * @param xJWTAssertion
     * @param q
     * @param graphConfig
     * @param dataFromDistributionList
     * @return
     * @throws net.weareact.api.NotFoundException
     * @throws BadParameterException
     */
    private List<GraphDataPoint> getGraphDataForDistributionListReceived(
            final String xJWTAssertion,
            final String q,
            final JsonNode graphConfig ) throws BadParameterException, net.weareact.api.NotFoundException
    {
        List<GraphDataPoint> graphDataPointList;
        String queryString = DashboardViewsImplQueryUtil.buildQuery( graphConfig, q );

        // make a call to Distribution-list for {received-distribution-lists} end-point
        List<ReceivedDistributionList> recDistributionList = manageReceivedDLEndpointCall(
                graphConfig,
                queryString,
                xJWTAssertion );

        graphDataPointList = new DistributionListToGraphDataForTopLevelGraph()
                .splitRecDistributionListByTime( recDistributionList, graphConfig );
        return graphDataPointList;
    }

    /**
     * This method gets the graph data for both ACTIONLIST generated and HOTLIST generated.
     *
     * @param xJWTAssertion
     * @param q
     * @param graphConfig
     * @return
     * @throws net.weareact.api.NotFoundException
     * @throws BadParameterException
     */
    private List<GraphDataPoint> getGraphDataForDistributionListsGenerated(
            final String xJWTAssertion,
            final String q,
            final JsonNode graphConfig ) throws BadParameterException, net.weareact.api.NotFoundException
    {

        DistributionListToGraphDataForTopLevelGraph dataFromDistributionList = new DistributionListToGraphDataForTopLevelGraph();
        String queryString;

        List<GraphDataPoint> graphDataPointList;
        // form query - this will take care of any params in q as well
        queryString = DashboardViewsImplQueryUtil.buildQuery( graphConfig, q );

        // make a call to the end point to get the List of DistributionList objects
        List<DistributionList> distributionLists = manageDLEndpointCall( graphConfig, queryString, xJWTAssertion );

        // remove pending records which has generation Date before current time
        List<DistributionList> filtertedDlResponse = filterDLResponse( distributionLists );

        // aggregate the response
        graphDataPointList = dataFromDistributionList.splitDistributionListByTime( filtertedDlResponse, graphConfig );
        return graphDataPointList;
    }

    private List<DistributionList> manageDLEndpointCall(
            final JsonNode graphConfig,
            final String queryString,
            final String xJWTAssertion ) throws BadParameterException, net.weareact.api.NotFoundException
    {
        List<DistributionList> distributionListsFinal = new ArrayList<>();
        DistributionListsResponse dLResponse = null;
        int count = 0;
        int offset = 0;
        do
        {

            if ( count > 0 && dLResponse != null )
            {
                offset = offset + ( dLResponse.getMeta().getLimit().intValue() );
            }

            Response apiResponse = callEndpointToFetchData( graphConfig, queryString, offset, xJWTAssertion );
            dLResponse = apiResponse.readEntity( DistributionListsResponse.class );

            distributionListsFinal.addAll( dLResponse.getDistributionLists() );
            count++;
        }
        while ( dLResponse.getMeta() != null && distributionListsFinal.size() < dLResponse.getMeta().getTotalCount() );

        return distributionListsFinal;
    }

    private List<GraphDataPoint> getGraphDataForDistributionListsGeneratedGrillDown(
            final String xJWTAssertion,
            final String q,
            final JsonNode graphConfig,
            final ACTClaims claim ) throws BadParameterException, net.weareact.api.NotFoundException
    {

        DistributionListToGraphDataForDrillDown dataFromDistributionList = new DistributionListToGraphDataForDrillDown();
        String queryString;

        List<GraphDataPoint> graphDataPointList;
        // form query - this will take care of any params in q as well
        queryString = DashboardViewsImplQueryUtil.buildQuery( graphConfig, q );

        // make a call to the end point
        List<DistributionList> distributionLists = manageDLEndpointCall( graphConfig, queryString, xJWTAssertion );

        // remove pending records which has generation Date before current time
        List<DistributionList> filtertedDlResponse = filterDLResponse( distributionLists );

        // DVS-136
        // Pass dist list not filtered list as filtered list may drop schemes
        List<String> passedSchemes = fetchSchemesFromQParamOrClaims( q, claim );
        List<SchemeLink> missingSchemeList = getMissingSchemes( passedSchemes, distributionLists, null, claim, true );

        // aggregate the response
        graphDataPointList = dataFromDistributionList
                .convertDLtoGraphData( filtertedDlResponse, graphConfig, xJWTAssertion, missingSchemeList );
        return graphDataPointList;
    }

    private List<GraphDataPoint> getGraphDataForDistributionListsReceivedDrillDown(
            final String xJWTAssertion,
            final String q,
            final JsonNode graphConfig,
            final ACTClaims claim ) throws BadParameterException, net.weareact.api.NotFoundException
    {

        DistributionListToGraphDataForDrillDown dataFromDistributionList = new DistributionListToGraphDataForDrillDown();
        String queryString;

        List<GraphDataPoint> graphDataPointList;
        // form query - this will take care of any params in q as well
        queryString = DashboardViewsImplQueryUtil.buildQuery( graphConfig, q );

        // make a call to the end point to get List Of DistributionList Objects
        List<ReceivedDistributionList> receivedDistributionLists = manageReceivedDLEndpointCall(
                graphConfig,
                queryString,
                xJWTAssertion );

        // DVS-136 - Send 0 values for schemes which do not have any data
        // Not passing filtered list as filtered list may drop schemes
        List<String> passedSchemes = fetchSchemesFromQParamOrClaims( q, claim );
        List<SchemeLink> missingSchemeList = getMissingSchemes(
                passedSchemes,
                null,
                receivedDistributionLists,
                claim,
                false );

        // aggregate the response
        graphDataPointList = dataFromDistributionList.convertReceivedDLtoGraphData(
                receivedDistributionLists,
                graphConfig,
                xJWTAssertion,
                missingSchemeList );
        return graphDataPointList;
    }

    private List<ReceivedDistributionList> manageReceivedDLEndpointCall(
            final JsonNode graphConfig,
            final String queryString,
            final String xJWTAssertion ) throws BadParameterException, net.weareact.api.NotFoundException
    {
        List<ReceivedDistributionList> receivedDistributionListsFinal = new ArrayList<>();

        ReceivedDistributionListsResponse dLResponse = null;
        int count = 0;
        int offset = 0;
        do
        {

            if ( count > 0 && dLResponse != null )
            {
                offset = offset + ( dLResponse.getMeta().getLimit().intValue() );
            }

            Response apiResponse = callEndpointToFetchData( graphConfig, queryString, offset, xJWTAssertion );
            dLResponse = apiResponse.readEntity( ReceivedDistributionListsResponse.class );

            receivedDistributionListsFinal.addAll( dLResponse.getDistributionLists() );
            count++;
        }
        while ( dLResponse.getMeta() != null
                && receivedDistributionListsFinal.size() < dLResponse.getMeta().getTotalCount() );

        return receivedDistributionListsFinal;
    }

    private GraphTypeEnum mapStringToGraphType( final String graphType )
    {
        GraphTypeEnum enumType = GraphTypeEnum.BAR;
        switch ( graphType.toUpperCase() )
        {
        case "BAR":
            enumType = GraphTypeEnum.BAR;
            break;
        case "LINE":
            enumType = GraphTypeEnum.LINE;
            break;
        case "PIE":
            enumType = GraphTypeEnum.PIE;
            break;
        default:
            throw new IllegalArgumentException();
        }
        return enumType;

    }

    /**
     *
     * This method is responsible to remove all the DL objects which has generation time before current time and has
     * generation status as "PENDING".
     *
     * @param distList
     *            : the response returned from Distribution List API call
     * @return : List of distribution filtered objects
     */
    public List<DistributionList> filterDLResponse( final List<DistributionList> distList )
    {
        LOGGER.info( "The total size of DistributionList before appying filter is :" + distList.size() );

        List<DistributionList> dl = filterPastPendingRecords( distList );
        LOGGER.info( "The total size of DistributionList after applying filter PastPendingRecord is: " + dl.size() );

        List<DistributionList> dl1 = filterFutureSuccess_FailedRecords( dl );
        LOGGER.info(
                "The total size of DistributionList after applying filter FutureSuccess_FailedRecords is: "
                        + dl1.size() );

        List<DistributionList> dl2 = filterUnscheduledPendingRecords( dl1 );
        LOGGER.info(
                "The total size of DistributionList after applying filter UnscheduledPendingRecords is: "
                        + dl2.size() );

        return dl2;
    }

    private List<DistributionList> filterPastPendingRecords( final List<DistributionList> distList )
    {
        List<DistributionList> filteredList = distList
                .stream()
                .filter(
                        dl -> ( dl.getGenerationStartDateTime().isAfter( ZonedDateTime.now() )
                                && dl.getGenerationStatus().equals( DistributionList.GenerationStatusEnum.PENDING ) )
                                || !dl.getGenerationStatus().equals( DistributionList.GenerationStatusEnum.PENDING ) )
                .collect( Collectors.toList() );

        distList
                .stream()
                .filter(
                        dl -> dl.getGenerationStartDateTime().isBefore( ZonedDateTime.now() )
                                && dl.getGenerationStatus().equals( DistributionList.GenerationStatusEnum.PENDING ) )
                .forEach( dl -> LOGGER.info(
                        "Filtering "
                                + dl.getScheme().getLink()
                                + " DL object as it is from past and having Pending Status  " ) );
        return filteredList;
    }

    private List<DistributionList> filterFutureSuccess_FailedRecords( final List<DistributionList> distList )
    {

        List<DistributionList> filteredList = distList
                .stream()
                .filter(
                        dl -> ( dl.getGenerationStartDateTime().isBefore( ZonedDateTime.now() )
                                && !dl.getGenerationStatus().equals( DistributionList.GenerationStatusEnum.PENDING ) )
                                || dl.getGenerationStatus().equals( DistributionList.GenerationStatusEnum.PENDING ) )
                .collect( Collectors.toList() );
        distList
                .stream()
                .filter(
                        dl -> dl.getGenerationStartDateTime().isAfter( ZonedDateTime.now() )
                                && !dl.getGenerationStatus().equals( DistributionList.GenerationStatusEnum.PENDING ) )
                .forEach( dl -> LOGGER.info(
                        "Filtering "
                                + dl.getScheme().getLink()
                                + " DL object as it is from Future and having "
                                + dl.getGenerationStatus()
                                + " Status " ) );
        return filteredList;
    }

    private List<DistributionList> filterUnscheduledPendingRecords( final List<DistributionList> distList )
    {
        List<DistributionList> filteredList = distList
                .stream()
                .filter(
                        d -> !( d.getUnscheduled()
                                && d.getGenerationStatus().equals( DistributionList.GenerationStatusEnum.PENDING ) )
                                || !d.getGenerationStatus().equals( DistributionList.GenerationStatusEnum.PENDING ) )
                .collect( Collectors.toList() );

        distList
                .stream()
                .filter(
                        d -> d.getUnscheduled()
                                && d.getGenerationStatus().equals( DistributionList.GenerationStatusEnum.PENDING ) )
                .forEach( dl -> LOGGER.info(
                        "Filtering "
                                + dl.getScheme().getLink()
                                + " DL object as it is unscheduled and having Pending Status " ) );

        return filteredList;
    }

    Response callEndpointToFetchData(
            final JsonNode graphConfig,
            final String queryString,
            final int offset,
            final String xJWTAssertion ) throws BadParameterException, net.weareact.api.NotFoundException
    {
        LOGGER.info( "Method callDLSEndpoint:: Going to hit distribution-lists API" );
        Response response = null;

        String endPoint = graphConfig.get( "endPoint" ).asText();
        if ( queryString != null && !queryString.isEmpty() )
        {

            // hit the distribution list API to fetch the data
            Client apiClient = ClientBuilder.newClient();
            WebTarget target;
            if ( offset > 0 )
            {
                target = apiClient.target( endPoint ).queryParam( "q", queryString ).queryParam( "offset", offset );
            }
            else
            {
                target = apiClient.target( endPoint ).queryParam( "q", queryString );
            }

            // find out how to pass the jwt user has sent
            LOGGER.info(
                    "Method callDLSEndpoint:: Calling endpoint - ["
                            + endPoint
                            + "] with queryString ["
                            + queryString
                            + "]" );

            try
            {

                response = target.request().header( HTTP_HEADER_JWT, xJWTAssertion ).get();
            }
            catch ( Exception ex )
            {
                // Distribution List is unavailable!
                LOGGER.error( String.format( "Distribution List is unavailable - %s", ex ) );
                throw new net.weareact.api.NotFoundException(
                        String.format( "Distribution List is unavailable - %s", ex.getMessage() ) );
            }

            if ( response.getStatus() != HttpStatus.SC_OK )
            {
                LOGGER.error( "Method callDLSEndpoint:: Bad Request:: API Response is - " + response.toString() );
                ServiceError targetApiServiceError = response.readEntity( ServiceError.class );
                throw new BadParameterException( targetApiServiceError.getUserMessage() );
            }
        }
        LOGGER.info( "Method callDLSEndpoint:: Returning response - " + response );
        return response;
    }

    /**
     * Method builds Error response using ServiceError class. {@link ServiceError}}
     *
     * @param exception
     * @return
     */
    public static Response buildErrorResponse( final Exception exception )
    {
        ServiceError error = new ServiceError();
        Response apiErrorResponse = null;

        final UUID uuid = UUID.randomUUID();
        error.setDeveloperMessage( DEFAULT_DEVELOPER_ERROR_MSG + uuid.toString() );

        if ( BadParameterException.class.isInstance( exception ) )
        {
            error.errorCode( String.valueOf( HttpStatus.SC_BAD_REQUEST ) ).userMessage( exception.getMessage() );
            apiErrorResponse = Response.status( HttpStatus.SC_BAD_REQUEST ).entity( error ).build();
        }
        else if ( net.weareact.api.NotFoundException.class.isInstance( exception ) )
        {
            error.errorCode( String.valueOf( HttpStatus.SC_NOT_FOUND ) ).userMessage( exception.getMessage() );
            apiErrorResponse = Response.status( HttpStatus.SC_NOT_FOUND ).entity( error ).build();
        }
        else
        {
            error.errorCode( String.valueOf( HttpStatus.SC_INTERNAL_SERVER_ERROR ) ).userMessage(
                    DEFAULT_USER_ERROR_MSG );
            apiErrorResponse = Response.serverError().entity( error ).build();
        }
        return apiErrorResponse;
    }

    /**
     *
     * @param claim
     * @param xJWTAssertion
     * @param q
     * @return the full Dashboard View
     *
     *         This method is used by the /dashboard-views endpoint to return data for a full DashBoard or set of Graphs
     * @throws net.weareact.api.NotFoundException
     * @throws BadParameterException
     */
    public List<DashboardView> prepareDashBoardData( final ACTClaims claim, final String xJWTAssertion, String q )
            throws BadParameterException,
            net.weareact.api.NotFoundException
    {
        List<DashboardView> views = new ArrayList<>();

        // Check if we got a dashboard id or set of graphs in the q param
        List<String> graphIds = DashboardViewsImplQueryUtil.getGraphIDsFromQParam( q, apiConfiguration );

        final int nextQueryParam = q.indexOf( "AND" ); // see if there is more than one query param
        // keep the other query params to passon to the individual graphs
        q = nextQueryParam != -1 ? q.substring( nextQueryParam + 3 ).trim() : null;

        // Call the prepare Graph Data function for each graph id in the list and collate the data
        for ( String graphID : graphIds )
            views.add( prepareGraphData( claim, graphID, xJWTAssertion, q ) ); // DVS-169: pass on the other q param
                                                                               // values to individual graphs

        // Return the whole thing
        return views;
    }

    /**
     * Method fetches passed schemes either from query parameter or ACTClaims object
     *
     * @param query
     * @param claims
     * @return List of passed schemes
     */
    private List<String> fetchSchemesFromQParamOrClaims( final String query, final ACTClaims claims )
    {
        LOGGER.info( "Method::fetchSchemesFromQParamOrClaims called with query as - " + query );

        List<String> passedSchemes = new ArrayList<>();

        // Check if schemes are passed in query parameter then don't check ACT Claim Object
        if ( StringUtils.isNotEmpty( query ) && query.indexOf( "scheme.link" ) != -1 )
        {
            int indexOfSchemeLink = query.indexOf( "scheme.link" );
            String strAfterSchemeParam = query.substring( indexOfSchemeLink );

            // Get first occurrence of "(" and ")" after scheme.link text in query parameter
            int indexOfStartBracket = strAfterSchemeParam.indexOf( "(" );
            int indexOfEndBracket = strAfterSchemeParam.indexOf( ")" );

            String commaSepratedSchemes = strAfterSchemeParam.substring( indexOfStartBracket + 1, indexOfEndBracket );
            LOGGER.info(
                    "Method::fetchSchemesFromQParamOrClaims >> commaSepratedSchemes from query parameter  - "
                            + commaSepratedSchemes );

            passedSchemes = Arrays.asList( commaSepratedSchemes.trim().split( "," ) );
        }
        else
        {
            Collection<ResourceLink> resourceLinks = claims.getSchemes();
            passedSchemes = resourceLinks.stream().map( ResourceLink::getLink ).collect( Collectors.toList() );
        }
        LOGGER.info( "Method::fetchSchemesFromQParamOrClaims >> Passed Schemes are  - " + passedSchemes );
        return passedSchemes;
    }

    /**
     * Method compares Passed Schemes (as part of q parameter or ACTClaims) and All Schemes inside returned
     * Distribution/Received Distribution List Response and returns missing schemes
     *
     * @param passedSchemes
     * @param distList
     *            (Distribution List Response returned by Distribution List Service)
     * @param recDistList
     *            (Received Distribution List Response returned by Distribution List Service)
     * @return List of Missing Schemes
     */
    private List<SchemeLink> getMissingSchemes(
            final List<String> passedSchemes,
            final List<DistributionList> distList,
            final List<ReceivedDistributionList> recDistList,
            final ACTClaims claims,
            final boolean isDistList )
    {
        List<String> missingSchemes = new ArrayList<>();

        List<String> retrievedSchemesFromDistServiceResponse = new ArrayList<>();

        if ( isDistList )
        {
            distList.forEach( distListObj ->

            retrievedSchemesFromDistServiceResponse.add( distListObj.getScheme().getLink().trim() ) );
        }
        else
        {
            recDistList.forEach( recDistListObj ->

            retrievedSchemesFromDistServiceResponse.add( recDistListObj.getScheme().getLink().trim() ) );
        }

        // Remove all schemes from Passed Scheme List which are present in Distribution
        // Service Response
        List<String> tempPassedSchemeList = new ArrayList<>( passedSchemes );
        tempPassedSchemeList.removeAll( retrievedSchemesFromDistServiceResponse );

        missingSchemes.addAll( tempPassedSchemeList );

        // Build List of SchemeLink Objects as same needs to be passed further
        List<SchemeLink> missingSchemeLinkList = new ArrayList<>();
        missingSchemes.forEach( schemeLinkStr ->
        {
            SchemeLink schemeLinkObj = new SchemeLink();
            schemeLinkObj.setAbbreviation( getAbbreviation( claims, schemeLinkStr ) );
            schemeLinkObj.setLink( schemeLinkStr );
            missingSchemeLinkList.add( schemeLinkObj );
        } );

        return missingSchemeLinkList;
    }

    /**
     * Method retrieves abbreviation for given scheme
     *
     * @param claims
     * @param schemeLink
     * @return
     */
    private String getAbbreviation( final ACTClaims claims, final String schemeLink )
    {
        String schemeAbbreviation = "";
        Collection<ResourceLink> resourceLinks = claims.getSchemes();

        // Apply filter to fetch only matched objects, fetch the first matching object
        Optional<ResourceLink> matchedResourceLink = resourceLinks
                .stream()
                .filter( resourceLinkObj -> schemeLink.equals( resourceLinkObj.getLink() ) )
                .findFirst();
        if ( matchedResourceLink.isPresent() )
        {
            schemeAbbreviation = matchedResourceLink.get().getAbbreviation();
        }
        return schemeAbbreviation;
    }

}
