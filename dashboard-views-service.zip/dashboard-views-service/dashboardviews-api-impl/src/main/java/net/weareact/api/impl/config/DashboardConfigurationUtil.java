package net.weareact.api.impl.config;

import java.util.Map;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import net.weareact.model.PointData;

public class DashboardConfigurationUtil
{
    @SuppressWarnings( "unchecked" )
    public Map<String, String> readValue( JsonNode graphConfig, String legendField, String statusField )
    {
        JsonNode dpLegend = graphConfig.get( legendField );
        Map<String, Map<String, String>> legends = new ObjectMapper().convertValue( dpLegend, Map.class );
        return legends.get( statusField );
    }

    public PointData getEmptyPointData(
            Map<String, String> pointKeyValue,
            JsonNode graphConfig,
            String legend,
            String status )
    {

        PointData emptyPointData = new PointData();
        emptyPointData.setPointKey( pointKeyValue );
        emptyPointData.setPointValue( 0 );
        emptyPointData.setPointLegend( readValue( graphConfig, legend, status ) );

        return emptyPointData;

    }

}
