package net.weareact.api.impl.config;

import com.fasterxml.jackson.databind.JsonNode;

import io.dropwizard.Configuration;

/**
 * @author mehtapra
 *
 *         the model which is mapped to YAML nodes
 */

public class DashBoardApiConfiguration extends Configuration
{

    private JsonNode actionListGeneration;
    private JsonNode actionListReceived;
    private JsonNode hotListGeneration;
    private JsonNode hotListReceived;
    private JsonNode actionListGenerationDrillDown;
    private JsonNode actionListReceivedDrillDown;
    private JsonNode hotListReceivedDrillDown;
    private JsonNode hotListGenerationDrillDown;
    private JsonNode operationalDashboard;
    private JsonNode managementDashboard;
    private JsonNode settlementBasedataDashboard;
    private JsonNode hopsQueuedMessages;
    private JsonNode cmsQueuedMessages;
    private JsonNode journeyRecordReceived;

    private JsonNode unlinkedJourney;

    public JsonNode getActionListGeneration()
    {
        return actionListGeneration;
    }

    public void setActionListGeneration( JsonNode actionListGeneration )
    {
        this.actionListGeneration = actionListGeneration;
    }

    public JsonNode getActionListReceived()
    {
        return actionListReceived;
    }

    public void setActionListReceived( JsonNode actionListReceived )
    {
        this.actionListReceived = actionListReceived;
    }

    public JsonNode getHotListGeneration()
    {
        return hotListGeneration;
    }

    public void setHotListGeneration( JsonNode hotListGeneration )
    {
        this.hotListGeneration = hotListGeneration;
    }

    public JsonNode getHotListReceived()
    {
        return hotListReceived;
    }

    public void setHotListReceived( JsonNode hotListReceived )
    {
        this.hotListReceived = hotListReceived;
    }

    public JsonNode getActionListGenerationDrillDown()
    {
        return actionListGenerationDrillDown;
    }

    public void setActionListGenerationDrillDown( JsonNode actionListGenerationDrillDown )
    {
        this.actionListGenerationDrillDown = actionListGenerationDrillDown;
    }

    public JsonNode getActionListReceivedDrillDown()
    {
        return actionListReceivedDrillDown;
    }

    public void setActionListReceivedDrillDown( JsonNode actionListReceivedDrillDown )
    {
        this.actionListReceivedDrillDown = actionListReceivedDrillDown;
    }

    public JsonNode getHotListReceivedDrillDown()
    {
        return hotListReceivedDrillDown;
    }

    public void setHotListReceivedDrillDown( JsonNode hotListReceivedDrillDown )
    {
        this.hotListReceivedDrillDown = hotListReceivedDrillDown;
    }

    public JsonNode getHotListGenerationDrillDown()
    {
        return hotListGenerationDrillDown;
    }

    public void setHotListGenerationDrillDown( JsonNode hotListGenerationDrillDown )
    {
        this.hotListGenerationDrillDown = hotListGenerationDrillDown;
    }

    public JsonNode getOperationalDashboard()
    {
        return operationalDashboard;
    }

    public void setOperationalDashboard( JsonNode operationalDashboard )
    {
        this.operationalDashboard = operationalDashboard;
    }

    public JsonNode getManagementDashboard()
    {
        return managementDashboard;
    }

    public void setManagementDashboard( JsonNode managementDashboard )
    {
        this.managementDashboard = managementDashboard;
    }

    public JsonNode getHopsQueuedMessages()
    {
        return hopsQueuedMessages;
    }

    public void setHopsQueuedMessages( JsonNode hopsQueuedMessages )
    {
        this.hopsQueuedMessages = hopsQueuedMessages;
    }

    public JsonNode getCmsQueuedMessages()
    {
        return cmsQueuedMessages;
    }

    public void setCmsQueuedMessages( JsonNode cmsQueuedMessages )
    {
        this.cmsQueuedMessages = cmsQueuedMessages;
    }

    public JsonNode getJourneyRecordReceived()
    {
        return journeyRecordReceived;
    }

    public void setJourneyRecordReceived( JsonNode journeyRecordReceived )
    {
        this.journeyRecordReceived = journeyRecordReceived;
    }

    public JsonNode getUnlinkedJourney()
    {
        return unlinkedJourney;
    }

    public void setUnlinkedJourney( JsonNode unlinkedJourney )
    {
        this.unlinkedJourney = unlinkedJourney;
    }

    public JsonNode getSettlementBasedataDashboard()
    {
        return settlementBasedataDashboard;
    }

    public void setSettlementBasedataDashboard( JsonNode settlementBasedataDashboard )
    {
        this.settlementBasedataDashboard = settlementBasedataDashboard;
    }

}
