package net.weareact.api.impl.utils;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import net.weareact.common.exceptionhandling.BadParameterException;
import net.weareact.model.PointData;
import net.weareact.model.ServiceError;

public class HopsCmsUtil
{
    private static final Logger LOGGER          = LoggerFactory.getLogger( HopsCmsUtil.class.getName() );

    private static final String HTTP_HEADER_JWT = "X-JWT-Assertion";
    private static final String POINT_LEGEND    = "pointLegend";
    private static final String IRREGULARITY    = "irregularity";

    private static final int    HUNDREAD        = 100;

    public Response callServiceToFetchHistoryData(
            JsonNode graphConfig,
            String queryString,
            String xJWTAssertion,
            int rollBackNumber ) throws BadParameterException, net.weareact.api.NotFoundException
    {
        LOGGER.info( "Method callHopsStatusServiceToFetchData:: Going to hit hops-status-service API" );

        Response response = null;

        String endPoint = graphConfig.get( "endPoint" ).asText();
        if ( queryString != null && !queryString.isEmpty() )
        {

            // hit the service API to fetch the data
            Client apiClient = ClientBuilder.newClient();
            WebTarget target = apiClient
                    .target( endPoint )
                    .queryParam( "limit", rollBackNumber - 1 )
                    .queryParam( "q", queryString );

            LOGGER.info(
                    "Method callHopsStatusServiceToFetchData:: Calling endpoint - ["
                            + endPoint
                            + "] with queryString ["
                            + queryString
                            + "]" );

            try
            {

                response = target.request().header( HTTP_HEADER_JWT, xJWTAssertion ).get();
            }
            catch ( Exception ex )
            {
                // Service is unavailable!
                LOGGER.error( String.format( "service is unavailable - %s", ex ) );
                throw new net.weareact.api.NotFoundException(
                        String.format( "service  is unavailable - %s", ex.getMessage() ) );
            }

            if ( response.getStatus() != HttpStatus.SC_OK )
            {
                LOGGER.error(
                        "Method callProductStatusServiceToFetchHistoryData:: Bad Request:: API Response is - "
                                + response.toString() );
                ServiceError targetApiServiceError = response.readEntity( ServiceError.class );
                throw new BadParameterException( targetApiServiceError.getUserMessage() );
            }

        }

        return response;
    }

    /**
     * This method reads the value of status in dataPointLegend or pointLegend nodes
     * 
     * @param graphConfig
     * @param legendField
     * @param statusField
     * @return
     */
    public Map<String, String> readValueAndAppendProductNameToLegends(
            JsonNode graphConfig,
            String legendField,
            String statusField,
            String productName )
    {
        JsonNode dpLegend = graphConfig.get( legendField );
        Map<String, Map<String, String>> legends = new ObjectMapper().convertValue( dpLegend, Map.class );
        Map<String, String> statusLegends = legends.get( statusField );

        Map<String, String> newStatusLegends = new HashMap<>();
        statusLegends
                .keySet()
                .forEach( key -> newStatusLegends.put( key, productName + "-" + statusLegends.get( key ) ) );

        return newStatusLegends;
    }

    public void setIrregular( JsonNode graphConfig, String key, PointData averagePointData, PointData currentPointData )
    {
        int averageValue = averagePointData.getPointValue();
        int currentvalue = currentPointData.getPointValue();

        int averageAreaDeviation;
        JsonNode deviationNode = graphConfig.get( "averageAreaDeviation" );
        if ( deviationNode.get( key ) != null )
        {
            averageAreaDeviation = deviationNode.get( key ).asInt();
        }
        else
        {
            averageAreaDeviation = deviationNode.get( "default" ).asInt();
        }

        int averageAreaValue = averageValue * averageAreaDeviation / HUNDREAD;

        if ( currentvalue < ( averageValue - averageAreaValue ) || currentvalue > ( averageValue + averageAreaValue ) )
        {
            currentPointData.setPointLegend(
                    readValueAndAppendProductNameToLegends( graphConfig, POINT_LEGEND, IRREGULARITY, key ) );
        }

    }

}
