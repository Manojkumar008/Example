package net.weareact.api.impl.utils;

import java.time.ZonedDateTime;

public class DateUtils
{
    private static final int TWO = 2;

    public static String converDateToStringwithTimeZero( ZonedDateTime date )
    {
        String timeStr = "00:00:00";
        String dateStr = date.getYear()
                + "-"
                + ( String.valueOf( date.getMonthValue() ).length() == TWO
                        ? date.getMonthValue()
                        : "0" + date.getMonthValue() )
                + "-"
                + ( String.valueOf( date.getDayOfMonth() ).length() == TWO
                        ? date.getDayOfMonth()
                        : "0" + date.getDayOfMonth() )
                + "T"
                + timeStr.trim()
                + "Z";

        return dateStr;
    }

    public static String converDateToStringwithTimeMax( ZonedDateTime date )
    {
        String timeStr = "23:59:59";
        String dateStr = date.getYear()
                + "-"
                + ( String.valueOf( date.getMonthValue() ).length() == TWO
                        ? date.getMonthValue()
                        : ( "0" + date.getMonthValue() ) )
                + "-"
                + ( String.valueOf( date.getDayOfMonth() ).length() == TWO
                        ? date.getDayOfMonth()
                        : ( "0" + date.getDayOfMonth() ) )
                + "T"
                + timeStr.trim()
                + "Z";

        return dateStr;
    }

    public static String converDateToString( ZonedDateTime date )
    {

        String dateStr = date.getYear()
                + "-"
                + ( String.valueOf( date.getMonthValue() ).length() == TWO
                        ? date.getMonthValue()
                        : ( "0" + date.getMonthValue() ) )
                + "-"
                + ( String.valueOf( date.getDayOfMonth() ).length() == TWO
                        ? date.getDayOfMonth()
                        : ( "0" + date.getDayOfMonth() ) )
                + "T"
                + ( String.valueOf( date.getHour() ).length() == TWO ? date.getHour() : ( "0" + date.getHour() ) )
                + ":"
                + ( String.valueOf( date.getMinute() ).length() == TWO ? date.getMinute() : ( "0" + date.getMinute() ) )
                + ":"
                + ( String.valueOf( date.getSecond() ).length() == TWO ? date.getSecond() : ( "0" + date.getSecond() ) )
                + "Z";

        return dateStr;
    }
}
