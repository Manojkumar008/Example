package net.weareact.api.impl;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.JsonNode;
import com.google.common.collect.Multimap;
import com.google.common.collect.Multimaps;

import net.weareact.api.NotFoundException;
import net.weareact.api.impl.utils.DashboardViewsImplQueryUtil;
import net.weareact.api.impl.utils.DateUtils;
import net.weareact.api.impl.utils.HopsCmsUtil;
import net.weareact.cmsstatuses.model.CmsStatus;
import net.weareact.cmsstatuses.model.CmsStatusesResponse;
import net.weareact.cmsstatuses.model.ContractEventQueueContent;
import net.weareact.common.exceptionhandling.BadParameterException;
import net.weareact.model.GraphDataPoint;
import net.weareact.model.PointData;

/**
 * This class is used to create the GraphDataPoint objects from HopsStatus list. CreateGraphDataFromHopsStatusList.
 * <p>
 * Copyright 2016 Applied Card Technologies Ltd
 *
 * @author patilsan
 */
public class CreateGraphDataFromCmsStatusList
{

    private static final Logger LOGGER            = LoggerFactory
                                                          .getLogger(
                                                                  CreateGraphDataFromCmsStatusList.class.getName() );

    private static final String POINT_LEGEND      = "pointLegend";

    private static final String CURRENT_LINE      = "current";

    private static final String AVERAGE_LINE      = "averageLine";

    private static final String DATA_POINT_LEGEND = "dataPointLegend";

    private static final String LOCALE_ALL        = "locale-all";

    private final HopsCmsUtil   hopsCmsUtil       = new HopsCmsUtil();

    public List<GraphDataPoint> create(
            final String xJWTAssertion,
            final JsonNode graphConfig,
            final List<CmsStatus> cmsStatusListAll )
    {
        List<GraphDataPoint> graphDataPointList = new ArrayList<>();

        // This function returns a MultiMap, having Cms Name as key and list of CmsStatus objects as value
        Multimap<String, CmsStatus> cmsStatusMultiMap = Multimaps
                .index( cmsStatusListAll, ( final CmsStatus cms ) -> cms.getName() );

        // for each cms create current line and average line data points
        cmsStatusMultiMap.keySet().forEach( cmsName ->
        {
            // create GraphData for Average Line for corresponding Cms
            GraphDataPoint averageLineGraphDataPoint = null;
            try
            {
                averageLineGraphDataPoint = convertCmsStatusToGraphDataForAverageLine(
                        graphConfig,
                        new ArrayList<>( cmsStatusMultiMap.get( cmsName ) ),
                        cmsName,
                        xJWTAssertion );
            }
            catch ( NotFoundException e )
            {
                LOGGER.error( "Error occcured while create GraphData for Average Line of Cms as : " + e );
            }
            graphDataPointList.add( averageLineGraphDataPoint );
            // create GraphData for Current Line for corresponding Cms
            GraphDataPoint currentLineGraphDataPoint = convertCmsStatusToGraphDataForCurrentLine(
                    graphConfig,
                    cmsStatusMultiMap.get( cmsName ),
                    cmsName );
            graphDataPointList.add( currentLineGraphDataPoint );
            for ( int index = 0; index < averageLineGraphDataPoint.getDataPointValues().size(); index++ )
            {
                hopsCmsUtil.setIrregular(
                        graphConfig,
                        cmsName,
                        averageLineGraphDataPoint.getDataPointValues().get( index ),
                        currentLineGraphDataPoint.getDataPointValues().get( index ) );
            }
        } );
        return graphDataPointList;
    }

    /**
     * This method creates the GraphDataPoint for average line displayed in graph
     *
     * @param graphConfig
     *            {@link JsonNode}
     * @param cmsStatusList
     *            {@link List}
     * @return averageLineGraphData {@link GraphDataPoint}
     * @throws NotFoundException
     * @throws BadParameterException
     */
    public GraphDataPoint convertCmsStatusToGraphDataForAverageLine(
            final JsonNode graphConfig,
            final List<CmsStatus> cmsStatusList,
            final String key,
            final String jwtToken ) throws BadParameterException, NotFoundException
    {
        GraphDataPoint averageLineGraphData = new GraphDataPoint();

        averageLineGraphData.setDataPointLegend(
                hopsCmsUtil
                        .readValueAndAppendProductNameToLegends( graphConfig, DATA_POINT_LEGEND, AVERAGE_LINE, key ) );
        String defaultLocale = graphConfig.get( LOCALE_ALL ).asText();
        List<PointData> pointDataList = new ArrayList<>();

        // find earliest date - list is sorted on dateTime from elastic
        ZonedDateTime earliestDate = cmsStatusList.get( cmsStatusList.size() - 1 ).getDateTime();

        // build query to fetch rollBackNumber records for average calculation
        JsonNode rollBackNode = graphConfig.get( "rollBackNumber" );

        int rollBackNumber = rollBackNode.get( key ) != null
                ? rollBackNode.get( key ).asInt()
                : rollBackNode.get( "default" ).asInt();

        String query = DashboardViewsImplQueryUtil.buildQueryToFetchDataForAvergaeLineCalculation(
                graphConfig,
                key,
                earliestDate,
                "cmsNameParameterName" );

        Response response = hopsCmsUtil.callServiceToFetchHistoryData( graphConfig, query, jwtToken, rollBackNumber );

        List<CmsStatus> cmsStatusesHistoryData = response.readEntity( CmsStatusesResponse.class ).getCmsStatuses();

        List<CmsStatus> cmsCurrentPlusHistoryData = new ArrayList<>();
        cmsCurrentPlusHistoryData.addAll( cmsStatusList );
        cmsCurrentPlusHistoryData.addAll( cmsStatusesHistoryData );

        for ( int index = 0; index < cmsStatusList.size(); index++ )
        {
            CmsStatus cmsStatus = cmsStatusList.get( index );
            int sizeOfListForAverageCalculation = cmsCurrentPlusHistoryData.size();
            int startIndex = index;

            int endIndex = ( startIndex + rollBackNumber ) > sizeOfListForAverageCalculation
                    ? sizeOfListForAverageCalculation
                    : ( startIndex + rollBackNumber );

            List<CmsStatus> cmsStatusSubList = cmsCurrentPlusHistoryData.subList( startIndex, endIndex );
            int total = cmsStatusSubList
                    .stream()
                    .map( CmsStatus::getContractEventsQueueContent )
                    .map( ContractEventQueueContent::getTotalSize )
                    .reduce( 0, ( a, b ) -> a + b );
            Integer average = Math.round( total / cmsStatusSubList.size() );

            PointData data = new PointData();
            data.setPointValue( average );
            data.setPointLegend(
                    hopsCmsUtil.readValueAndAppendProductNameToLegends(
                            graphConfig,
                            POINT_LEGEND,
                            AVERAGE_LINE,
                            cmsStatus.getName() ) );

            Map<String, String> pointKeyMap = new HashMap<>();
            pointKeyMap.put( defaultLocale, DateUtils.converDateToString( cmsStatus.getDateTime() ) );
            data.setPointKey( pointKeyMap );
            pointDataList.add( data );

        }

        // Since the data is in descending order, the point data list must be reversed
        Collections.reverse( pointDataList );
        averageLineGraphData.setDataPointValues( pointDataList );
        return averageLineGraphData;
    }

    /**
     * This method creates the GraphDataPoint for current line displayed in graph
     *
     * @param graphConfig
     *            {@link JsonNode}
     * @param cmsStatusList
     *            {@link List}
     *
     * @return currentLineGraphData {@link GraphDataPoint}
     */
    public GraphDataPoint convertCmsStatusToGraphDataForCurrentLine(
            final JsonNode graphConfig,
            final Collection<CmsStatus> cmsStatusList,
            final String key )
    {

        GraphDataPoint currentLineGraphData = new GraphDataPoint();

        currentLineGraphData.setDataPointLegend(
                hopsCmsUtil
                        .readValueAndAppendProductNameToLegends( graphConfig, DATA_POINT_LEGEND, CURRENT_LINE, key ) );

        String defaultLocale = graphConfig.get( LOCALE_ALL ).asText();
        List<PointData> pointDataList = new ArrayList<>();

        cmsStatusList.forEach( h ->
        {
            PointData data = new PointData();
            data.setPointValue( h.getContractEventsQueueContent().getTotalSize() );
            data.setPointLegend(
                    hopsCmsUtil.readValueAndAppendProductNameToLegends(
                            graphConfig,
                            POINT_LEGEND,
                            CURRENT_LINE,
                            h.getName() ) );
            Map<String, String> pointKeyMap = new HashMap<>();
            pointKeyMap.put( defaultLocale, DateUtils.converDateToString( h.getDateTime() ) );
            data.setPointKey( pointKeyMap );
            pointDataList.add( data );
        } );

        Collections.reverse( pointDataList );
        currentLineGraphData.setDataPointValues( pointDataList );
        return currentLineGraphData;

    }

}
