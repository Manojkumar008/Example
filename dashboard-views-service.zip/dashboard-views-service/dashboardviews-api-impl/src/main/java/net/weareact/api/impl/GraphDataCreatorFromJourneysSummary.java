package net.weareact.api.impl;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import net.weareact.api.impl.utils.PointDataComparator;
import net.weareact.journeys.model.GroupSummary;
import net.weareact.model.GraphDataPoint;
import net.weareact.model.PointData;

/**
 * <p>
 * Copyright 2016 Applied Card Technologies Ltd
 *
 * @author patilsan
 */
public class GraphDataCreatorFromJourneysSummary
{

    private static final String     POINT_KEYS                  = "pointKeys";
    private static final String     TODAY                       = "TODAY";
    private static final String     POINT_LEGEND                = "pointLegend";
    private static final String     RECEIVED_JOURNEYS_LEGEND    = "received";
    private static final String     AVERAGE_JOURNEYS_LEGEND     = "average";
    private static final String     DATA_POINT_LEGEND           = "dataPointLegend";

    private static final String     LOCALE_ALL                  = "locale-all";
    private static final String     PROCESSING_JOURNEYS_LEGEND  = "processing";
    private static final String     DEFAULT_LOCALE              = "en";

    private static final String     LAST_8_DAYS                 = "LAST_8_DAYS";
    private static final String     LAST_8_WEEKS                = "LAST_8_WEEKS";
    private static final String     LAST_8_MONTHS               = "LAST_8_MONTHS";
    private Map<LocalDate, Integer> currentJourneysByTimeFilter = new TreeMap<>();
    private Map<LocalDate, Integer> historyJourneysByTimeFilter = new TreeMap<>();

    public GraphDataPoint createCurrentGraphDataForReceivedJourneys(
            JsonNode graphConfig,
            String timeFilter,
            GroupSummary summary )
    {

        GraphDataPoint graphDataPoint = new GraphDataPoint();
        Map<String, GroupSummary> subGroups = summary.getSubGroups();

        currentJourneysByTimeFilter = groupJourneyRecordsByFilter( subGroups, timeFilter );

        fillWithZeroValuesIfDataNotPresent( currentJourneysByTimeFilter, timeFilter );

        graphDataPoint.setDataPointLegend( readValue( graphConfig, DATA_POINT_LEGEND, RECEIVED_JOURNEYS_LEGEND ) );

        List<PointData> pointDataList = getPointDataList( graphConfig, currentJourneysByTimeFilter, timeFilter );

        graphDataPoint.setDataPointValues( pointDataList );

        return graphDataPoint;

    }

    /**
     * This method fills in zero values if data not present for last_8_days or last_8_months or last_8_weeks filter
     * 
     * @param currentJourneysByTimeFilter2
     * @param timeFilter
     */
    private void fillWithZeroValuesIfDataNotPresent(
            Map<LocalDate, Integer> currentJourneysByTimeFilter2,
            String timeFilter )
    {
        int mapSize = currentJourneysByTimeFilter2.size();
        while ( mapSize < 8 )
        {
            Set<LocalDate> keySet = currentJourneysByTimeFilter2.keySet();
            Set<LocalDate> keySetCopy = new HashSet<>();
            keySetCopy.addAll( keySet );
            keySetCopy.forEach( key ->
            {
                LocalDate missingKey = null;
                boolean keyPresent = true;
                switch ( timeFilter )
                {
                case LAST_8_DAYS:
                    missingKey = key.minusDays( 1 );
                    keyPresent = currentJourneysByTimeFilter2.containsKey( missingKey );
                    break;
                case LAST_8_WEEKS:
                    missingKey = key.minusWeeks( 1 );
                    keyPresent = currentJourneysByTimeFilter2.containsKey( missingKey );
                    break;
                case LAST_8_MONTHS:
                    missingKey = key.minusMonths( 1 );
                    keyPresent = currentJourneysByTimeFilter2.containsKey( missingKey );
                    break;
                default:
                    break;
                }
                if ( !keyPresent )
                {
                    currentJourneysByTimeFilter2.put( missingKey, Integer.valueOf( 0 ) );
                }
            } );
            mapSize = currentJourneysByTimeFilter2.size();
        }
    }

    public GraphDataPoint createAverageGraphDataForReceivedJourneys(
            JsonNode graphConfig,
            String timeFilter,
            GroupSummary averageSummary )
    {
        GraphDataPoint graphDataPoint = new GraphDataPoint();
        graphDataPoint.setDataPointLegend( readValue( graphConfig, DATA_POINT_LEGEND, AVERAGE_JOURNEYS_LEGEND ) );

        Map<String, GroupSummary> averageSubGroups = averageSummary.getSubGroups();

        // 2. Aggregate data by day / week / month as done for current data points into history list
        historyJourneysByTimeFilter = groupJourneyRecordsByFilter( averageSubGroups, timeFilter );

        // 3. To this, add aggregated current data minus current day/week/month data at the beginning of history list
        currentJourneysByTimeFilter.remove( getKey( timeFilter, ZonedDateTime.now() ) );
        historyJourneysByTimeFilter.putAll( currentJourneysByTimeFilter );

        List<PointData> pointDataList = getAveragePointDataList( graphConfig, historyJourneysByTimeFilter, timeFilter );
        graphDataPoint.setDataPointValues( pointDataList );
        return graphDataPoint;
    }

    public List<PointData> getAveragePointDataList(
            JsonNode graphConfig,
            Map<LocalDate, Integer> totalJourneysByTimeFilter,
            String timeFilter )
    {

        int rollBackNumber = graphConfig.get( "rollBackNumber" ).asInt();
        List<PointData> pointDataList = new ArrayList<>();
        String pointKey;

        for ( int i = 0; i < 8; i++ )
        {
            ZonedDateTime dateKey = ZonedDateTime.now();
            PointData data = new PointData();
            data.setPointLegend( readValue( graphConfig, POINT_LEGEND, AVERAGE_JOURNEYS_LEGEND ) );
            Integer totalCount = 0;
            Map<String, String> pointKeyMap = null;
            switch ( timeFilter )
            {
            case LAST_8_DAYS:

                dateKey = dateKey.minusDays( i );
                for ( int j = 1; j <= rollBackNumber; j++ )
                {
                    LocalDate historyDataKey = dateKey.minusDays( j * 7 ).toLocalDate();
                    Optional<Integer> historyValue = Optional
                            .ofNullable( totalJourneysByTimeFilter.get( historyDataKey ) );
                    totalCount += historyValue.orElse( 0 );

                }
                LocalDate key = getKey( timeFilter, ZonedDateTime.now().minusDays( i ) );
                pointKey = getPointKeyFromKeyForDayForLastEightDay( key );
                pointKeyMap = readValue( graphConfig, POINT_KEYS, pointKey );
                break;

            case LAST_8_WEEKS:
                dateKey = dateKey.minusWeeks( i );
                LocalDate averageDatakey = getKey( timeFilter, ZonedDateTime.now().minusWeeks( i ) );

                // TODO: check if we are going past end of history data list
                for ( int j = 1; j <= rollBackNumber; j++ )
                {
                    LocalDate historyDataKey = getKey( timeFilter, dateKey.minusWeeks( j ) );
                    Optional<Integer> historyValue = Optional
                            .ofNullable( totalJourneysByTimeFilter.get( historyDataKey ) );
                    totalCount += historyValue.orElse( 0 );
                }

                pointKey = getPointKeyFromKeyForDayForLastEightWeeks( averageDatakey );
                // Map<String, String> pointKeyMap = readValue( graphConfig, POINT_KEYS, pointKey );
                pointKeyMap = new HashMap<>();
                pointKeyMap.put( "en", pointKey );
                break;

            case LAST_8_MONTHS:

                dateKey = dateKey.minusMonths( i );

                averageDatakey = getKey( timeFilter, ZonedDateTime.now().minusMonths( i ) );

                // TODO: check if we are going past end of history data list
                for ( int j = 1; j <= rollBackNumber; j++ )
                {
                    LocalDate historyDataKey = getKey( timeFilter, dateKey.minusMonths( j ) );
                    Optional<Integer> historyValue = Optional
                            .ofNullable( totalJourneysByTimeFilter.get( historyDataKey ) );
                    totalCount += historyValue.orElse( 0 );

                }

                pointKey = getPointKeyFromKeyForDayForLastEightMonths( averageDatakey );
                pointKeyMap = readValue( graphConfig, POINT_KEYS, pointKey );
                break;
            }

            data.setPointValue( Math.round( totalCount / rollBackNumber ) );
            data.setPointKey( pointKeyMap );
            pointDataList.add( data );

        }
        Collections.reverse( pointDataList );
        return pointDataList;
    }

    private List<PointData> getPointDataList(
            JsonNode graphConfig,
            Map<LocalDate, Integer> totalJourneysByTimeFilter,
            String timeFilter )
    {
        List<PointData> pointDataList = new ArrayList<>();
        totalJourneysByTimeFilter.keySet().forEach( key ->
        {

            PointData pointData = new PointData();
            pointData.setPointValue( totalJourneysByTimeFilter.get( key ) );
            if ( key.equals( ZonedDateTime.now().toLocalDate() ) || key.isAfter( ZonedDateTime.now().toLocalDate() ) )
            {
                pointData.setPointLegend( readValue( graphConfig, POINT_LEGEND, PROCESSING_JOURNEYS_LEGEND ) );
            }
            else
            {
                pointData.setPointLegend( readValue( graphConfig, POINT_LEGEND, RECEIVED_JOURNEYS_LEGEND ) );
            }

            Map<String, String> pointKeyMap = new HashMap<String, String>();

            // Convert the key (LocalDate) to the point key
            String pointKey = "";

            switch ( timeFilter )
            {
            case LAST_8_DAYS:
                pointKey = getPointKeyFromKeyForDayForLastEightDay( key );
                pointKeyMap = readValue( graphConfig, POINT_KEYS, pointKey );
                break;
            case LAST_8_WEEKS:
                pointKey = getPointKeyFromKeyForDayForLastEightWeeks( key );
                String defaultLocale = graphConfig.get( LOCALE_ALL ).asText();
                pointKeyMap.put( defaultLocale, pointKey );
                break;
            case LAST_8_MONTHS:
                pointKey = getPointKeyFromKeyForDayForLastEightMonths( key );
                pointKeyMap = readValue( graphConfig, POINT_KEYS, pointKey );
                break;
            }
            pointData.setPointKey( pointKeyMap );
            pointDataList.add( pointData );
        } );
        return pointDataList;
    }

    private static String getPointKeyFromKeyForDayForLastEightMonths( LocalDate key )
    {

        return key.getMonth().getDisplayName( TextStyle.SHORT, Locale.ENGLISH );
    }

    private static String getPointKeyFromKeyForDayForLastEightWeeks( LocalDate key )
    {
        return key.toString();
    }

    private Map<LocalDate, Integer> groupJourneyRecordsByFilter(
            Map<String, GroupSummary> subGroups,

            String timeFilter )
    {

        Map<LocalDate, Integer> totalJourneysByTimeFilter = new TreeMap<>();
        subGroups.keySet().forEach( createdDate ->
        {
            ZonedDateTime juourneyCreatedDate = ZonedDateTime.parse( createdDate );
            LocalDate key = getKey( timeFilter, juourneyCreatedDate );

            GroupSummary subGroupSummary = subGroups.get( createdDate );
            if ( totalJourneysByTimeFilter.containsKey( key ) )
            {
                Integer journeyCountForDay = totalJourneysByTimeFilter.get( key );
                totalJourneysByTimeFilter.put( key, journeyCountForDay + subGroupSummary.getTotal() );
            }
            else
            {
                totalJourneysByTimeFilter.put( key, subGroupSummary.getTotal() );
            }
        } );

        return totalJourneysByTimeFilter;
    }

    private LocalDate getKey( String timeFilter, ZonedDateTime journeyCreatedDate )
    {
        LocalDate key = null;
        switch ( timeFilter )
        {
        case LAST_8_DAYS:
            key = journeyCreatedDate.toLocalDate();
            break;
        case LAST_8_WEEKS:
            key = journeyCreatedDate.toLocalDate().with( DayOfWeek.SUNDAY );
            break;
        case LAST_8_MONTHS:
            LocalDate localDate = journeyCreatedDate.toLocalDate();
            key = localDate.withDayOfMonth( localDate.lengthOfMonth() );
            break;
        }
        return key;
    }

    /**
     * This method returns the key for LAST_8_DAYS filter. If Journey date is equal todays date, then it returns "TODAY"
     * If Journey date is not equal todays date, then it returns the day of week for the date
     * 
     * @param createdDate
     *            {@link String}
     * @return key {@link String}
     */
    private String getPointKeyFromKeyForDayForLastEightDay( LocalDate createdDate )
    {

        // if journey date equals todays date then return TODAY as key.

        if ( createdDate.equals( ZonedDateTime.now().toLocalDate() ) )
        {
            return TODAY;
        }
        else
        {
            // else return the day ofweek as key
            return createdDate.getDayOfWeek().getDisplayName( TextStyle.SHORT, Locale.ENGLISH );
        }

    }

    /**
     * This method reads the value of status in dataPointLegend or pointLegend nodes
     * 
     * @param graphConfig
     * @param legendField
     * @param statusField
     * @return
     */
    private Map<String, String> readValue( JsonNode graphConfig, String legendField, String statusField )
    {
        JsonNode dpLegend = graphConfig.get( legendField );
        Map<String, Map<String, String>> legends = new ObjectMapper().convertValue( dpLegend, Map.class );
        return legends.get( statusField );
    }

    public GraphDataPoint createAverageGraphDataForDrillDown(
            JsonNode graphConfig,
            String timeFilter,
            Map<String, Integer> totalAverageSummary )
    {

        GraphDataPoint graphDataPoint = new GraphDataPoint();
        graphDataPoint.setDataPointLegend( readValue( graphConfig, DATA_POINT_LEGEND, AVERAGE_JOURNEYS_LEGEND ) );
        List<PointData> pointDataList = getAveragePointDataListForDrillDown(
                graphConfig,
                totalAverageSummary,
                timeFilter );
        graphDataPoint.setDataPointValues( pointDataList );
        return graphDataPoint;

    }

    private List<PointData> getAveragePointDataListForDrillDown(
            JsonNode graphConfig,
            Map<String, Integer> totalAverageSummary,
            String timeFilter )
    {
        int rollBackNumber = graphConfig.get( "rollBackNumber" ).asInt();
        List<PointData> pointDataList = new ArrayList<PointData>();

        totalAverageSummary.forEach( ( scheme, count ) ->
        {
            PointData data = new PointData();
            data.setPointLegend( readValue( graphConfig, POINT_LEGEND, AVERAGE_JOURNEYS_LEGEND ) );
            Map<String, String> pointKeyMap = new HashMap<>();

            pointKeyMap.put( DEFAULT_LOCALE, scheme );

            data.setPointValue( Math.round( count / rollBackNumber ) );
            data.setPointKey( pointKeyMap );
            pointDataList.add( data );
        } );
        return pointDataList;
    }

    public List<GraphDataPoint> setEmptyPointDataInCurrentAndAverageDrilldown(
            JsonNode graphConfig,
            GraphDataPoint currentGraphDataPoint,
            GraphDataPoint averageGraphDataPoint )
    {
        List<PointData> currentList = currentGraphDataPoint.getDataPointValues();
        List<PointData> averageList = averageGraphDataPoint.getDataPointValues();

        List<String> currentMapValues = new ArrayList<>();
        List<String> avgMapValues = new ArrayList<>();

        currentList.forEach( point ->
        {
            currentMapValues.add( point.getPointKey().get( "en" ) );
        } );

        averageList.forEach( point ->
        {
            avgMapValues.add( point.getPointKey().get( "en" ) );
        } );
        // add Empty PointData to Average List<PointData> that occurs in Current List<PointData> Data

        currentMapValues.forEach( value ->
        {
            boolean flag = avgMapValues.contains( value );

            if ( !flag )
            {
                PointData data = new PointData();
                data.setPointLegend( readValue( graphConfig, POINT_LEGEND, AVERAGE_JOURNEYS_LEGEND ) );
                Map<String, String> pointKeyMap = new HashMap<>();

                pointKeyMap.put( DEFAULT_LOCALE, value );
                data.setPointKey( pointKeyMap );
                data.setPointValue( Integer.valueOf( 0 ) );

                averageList.add( data );

            }
        } );

        // add Empty PointData to Current List<PointData> that occurs in Average List<PointData> Data
        avgMapValues.forEach( value ->
        {
            boolean flag = currentMapValues.contains( value );

            if ( !flag )
            {
                PointData data = new PointData();
                data.setPointLegend( readValue( graphConfig, POINT_LEGEND, RECEIVED_JOURNEYS_LEGEND ) );
                Map<String, String> pointKeyMap = new HashMap<>();

                pointKeyMap.put( DEFAULT_LOCALE, value );
                data.setPointKey( pointKeyMap );
                data.setPointValue( Integer.valueOf( 0 ) );

                currentList.add( data );
            }
        } );

        PointDataComparator comaparator = new PointDataComparator();
        Collections.sort( currentList, comaparator );
        Collections.sort( averageList, comaparator );

        List<GraphDataPoint> graphDataPoints = new ArrayList<>();
        currentGraphDataPoint.setDataPointValues( currentList );
        averageGraphDataPoint.setDataPointValues( averageList );

        graphDataPoints.add( currentGraphDataPoint );
        graphDataPoints.add( averageGraphDataPoint );
        return graphDataPoints;
    }

}
