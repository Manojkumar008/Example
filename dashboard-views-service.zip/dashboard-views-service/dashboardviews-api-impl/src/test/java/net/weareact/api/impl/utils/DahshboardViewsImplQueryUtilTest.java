package net.weareact.api.impl.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.Map;

import javax.validation.Validation;

import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.JsonNode;

import io.dropwizard.configuration.ConfigurationFactory;
import io.dropwizard.jackson.Jackson;
import net.weareact.api.impl.config.DashBoardApiConfiguration;

public class DahshboardViewsImplQueryUtilTest
{

    private static final Logger      LOGGER                    = LoggerFactory
                                                                       .getLogger(
                                                                               DahshboardViewsImplQueryUtilTest.class
                                                                                       .getName() );

    // initialized in setup method
    static DashBoardApiConfiguration dashBoardApiConfiguration = null;
    private String                   startDateString           = "";
    private String                   endDateString             = "";
    private Map<String, String>      dateStrMap                = null;

    @BeforeClass
    @SuppressWarnings(
    { "unchecked", "rawtypes" } )
    public static void setUp() throws Exception
    {
        LOGGER.info( "DashboardViewsImplUtilTest >> invoking setUp :::::" );
        ConfigurationFactory<DashBoardApiConfiguration> configurationFactory = new ConfigurationFactory(
                DashBoardApiConfiguration.class,
                Validation.buildDefaultValidatorFactory().getValidator(),
                Jackson.newObjectMapper(),
                "d" );
        InputStream in = DashboardViewsImplUtilTest.class
                .getClassLoader()
                .getResourceAsStream( "dashboard-internal-test.yml" );
        File tempFile = File.createTempFile( "dashboard-internal-test", "tmp" );
        tempFile.deleteOnExit();
        FileOutputStream out = new FileOutputStream( tempFile );
        IOUtils.copy( in, out );

        dashBoardApiConfiguration = configurationFactory.build( tempFile );
        LOGGER.info( "DashboardViewsImplUtilTest >> setUp invoked:::::" );
    }

    @Test
    public void testDefaultQueryForActionListGenerated() throws UnsupportedEncodingException
    {

        JsonNode configNode = dashBoardApiConfiguration.getActionListGeneration();

        String actual = DashboardViewsImplQueryUtil.buildQuery( configNode, null );

        dateStrMap = getDateString();
        startDateString = dateStrMap.get( "START_DATE" );
        endDateString = dateStrMap.get( "END_DATE" );

        Assert.assertEquals(
                "type = ACTIONLIST AND generationStartDateTime>="
                        + startDateString
                        + "T00:00:00Z"
                        + " AND generationStartDateTime<="
                        + endDateString
                        + "T00:00:00Z",
                actual );
        LOGGER.info( "DashboardViewsImplUtilTest >> ACTIONLISTGENERATION >> Default Query Tested:::::" );
    }

    @Test
    public void testTimeQueryParamForActionListGenerated() throws UnsupportedEncodingException
    {
        JsonNode configNode = dashBoardApiConfiguration.getActionListGeneration();

        dateStrMap = getDateString();
        startDateString = dateStrMap.get( "START_DATE" );
        endDateString = dateStrMap.get( "END_DATE" );

        String actual = DashboardViewsImplQueryUtil.buildQuery(
                configNode,
                "startDate>=" + startDateString + " AND endDate<=" + endDateString + " AND time=10:08:02" );

        Assert.assertEquals(
                "type = ACTIONLIST AND generationStartDateTime>="
                        + startDateString
                        + " AND generationStartDateTime<="
                        + endDateString
                        + " AND generationStartDateTime=10:08:02",
                actual );
        LOGGER.info( "DashboardViewsImplUtilTest >> ACTIONLISTGENERATION >> Time Period Query Tested:::::" );
    }

    @Test
    public void testSchemeQueryParamForActionListGenerated() throws UnsupportedEncodingException
    {

        JsonNode configNode = dashBoardApiConfiguration.getActionListGeneration();

        dateStrMap = getDateString();
        startDateString = dateStrMap.get( "START_DATE" );
        endDateString = dateStrMap.get( "END_DATE" );

        String actual = DashboardViewsImplQueryUtil.buildQuery(
                configNode,
                "scheme.link IN(/schemes/000e45cc-b9e0-11e5-9912-ba0be0483c18,/schemes/111b06b4-b9e0-11e5-9912-ba0be0483c18)" );

        Assert.assertEquals(
                "type = ACTIONLIST AND generationStartDateTime>="
                        + startDateString
                        + "T00:00:00Z"
                        + " AND generationStartDateTime<="
                        + endDateString
                        + "T00:00:00Z"
                        + " AND scheme.link IN(/schemes/000e45cc-b9e0-11e5-9912-ba0be0483c18,/schemes/111b06b4-b9e0-11e5-9912-ba0be0483c18)",
                actual );
        LOGGER.info( "DashboardViewsImplUtilTest >> ACTIONLISTGENERATION >> Scheme Query Tested:::::" );
    }

    @Test
    public void testTimeAndSchemeQueryParamForActionListGenerated() throws UnsupportedEncodingException
    {

        JsonNode configNode = dashBoardApiConfiguration.getActionListGeneration();

        dateStrMap = getDateString();
        startDateString = dateStrMap.get( "START_DATE" );
        endDateString = dateStrMap.get( "END_DATE" );

        String actual = DashboardViewsImplQueryUtil.buildQuery(
                configNode,
                "startDate>="
                        + startDateString
                        + " AND endDate<="
                        + endDateString
                        + " AND time=10:08:02"
                        + " AND scheme.link IN(/schemes/000e45cc-b9e0-11e5-9912-ba0be0483c18,/schemes/111b06b4-b9e0-11e5-9912-ba0be0483c18)" );

        Assert.assertEquals(
                "type = ACTIONLIST AND generationStartDateTime>="
                        + startDateString
                        + " AND generationStartDateTime<="
                        + endDateString
                        + " AND generationStartDateTime=10:08:02"
                        + " AND scheme.link IN(/schemes/000e45cc-b9e0-11e5-9912-ba0be0483c18,/schemes/111b06b4-b9e0-11e5-9912-ba0be0483c18)",
                actual );

        LOGGER.info( "DashboardViewsImplUtilTest >> ACTIONLISTGENERATION >> Time and Scheme Query Tested:::::" );
    }

    @Test
    public void testDefaultQueryForActionListReceived() throws UnsupportedEncodingException
    {

        JsonNode configNode = dashBoardApiConfiguration.getActionListReceived();

        String actual = DashboardViewsImplQueryUtil.buildQuery( configNode, null );

        dateStrMap = getDateString();
        startDateString = dateStrMap.get( "START_DATE" );
        endDateString = dateStrMap.get( "END_DATE" );

        Assert.assertEquals(
                "type = ACTIONLIST AND receivedDateTime>="
                        + startDateString
                        + "T00:00:00Z"
                        + " AND receivedDateTime<="
                        + endDateString
                        + "T00:00:00Z",
                actual );
        LOGGER.info( "DashboardViewsImplUtilTest >> ACTIONLISTRECEIVE >> Default Query Tested:::::" );
    }

    @Test
    public void testTimeQueryParamsForActionListReceived() throws UnsupportedEncodingException
    {
        JsonNode configNode = dashBoardApiConfiguration.getActionListReceived();

        dateStrMap = getDateString();
        startDateString = dateStrMap.get( "START_DATE" );
        endDateString = dateStrMap.get( "END_DATE" );

        String actual = DashboardViewsImplQueryUtil.buildQuery(
                configNode,
                "startDate>=" + startDateString + " AND endDate<=" + endDateString + " AND time=10:08:02" );

        Assert.assertEquals(
                "type = ACTIONLIST AND receivedDateTime>="
                        + startDateString
                        + " AND receivedDateTime<="
                        + endDateString
                        + " AND receivedDateTime=10:08:02",
                actual );
        LOGGER.info( "DashboardViewsImplUtilTest >> ACTIONLISTRECEIVE >> Time Period Query Tested:::::" );
    }

    @Test
    public void testSchemeQueryParamForActionListReceived() throws UnsupportedEncodingException
    {

        JsonNode configNode = dashBoardApiConfiguration.getActionListReceived();

        dateStrMap = getDateString();
        startDateString = dateStrMap.get( "START_DATE" );
        endDateString = dateStrMap.get( "END_DATE" );

        String actual = DashboardViewsImplQueryUtil.buildQuery(
                configNode,
                "scheme.link IN(/schemes/000e45cc-b9e0-11e5-9912-ba0be0483c18,/schemes/111b06b4-b9e0-11e5-9912-ba0be0483c18)" );

        Assert.assertEquals(
                "type = ACTIONLIST AND receivedDateTime>="
                        + startDateString
                        + "T00:00:00Z"
                        + " AND receivedDateTime<="
                        + endDateString
                        + "T00:00:00Z"
                        + " AND scheme.link IN(/schemes/000e45cc-b9e0-11e5-9912-ba0be0483c18,/schemes/111b06b4-b9e0-11e5-9912-ba0be0483c18)",
                actual );
        LOGGER.info( "DashboardViewsImplUtilTest >> ACTIONLISTRECEIVE >> Scheme Query Tested:::::" );

    }

    @Test
    public void testTimeAndSchemeQueryParamForAActionListReceived() throws UnsupportedEncodingException
    {

        JsonNode configNode = dashBoardApiConfiguration.getActionListReceived();

        dateStrMap = getDateString();
        startDateString = dateStrMap.get( "START_DATE" );
        endDateString = dateStrMap.get( "END_DATE" );

        String actual = DashboardViewsImplQueryUtil.buildQuery(
                configNode,
                "startDate>="
                        + startDateString
                        + " AND endDate<="
                        + endDateString
                        + " AND time=10:08:02"
                        + " AND scheme.link IN(/schemes/000e45cc-b9e0-11e5-9912-ba0be0483c18,/schemes/111b06b4-b9e0-11e5-9912-ba0be0483c18)" );

        Assert.assertEquals(
                "type = ACTIONLIST AND receivedDateTime>="
                        + startDateString
                        + " AND receivedDateTime<="
                        + endDateString
                        + " AND receivedDateTime=10:08:02"
                        + " AND scheme.link IN(/schemes/000e45cc-b9e0-11e5-9912-ba0be0483c18,/schemes/111b06b4-b9e0-11e5-9912-ba0be0483c18)",
                actual );

        LOGGER.info( "DashboardViewsImplUtilTest >> ACTIONLISTRECEIVE >> Time and Scheme Query Tested:::::" );
    }

    @Test
    public void testTimeQueryParamForHopsQueueMessages() throws UnsupportedEncodingException
    {

        JsonNode configNode = dashBoardApiConfiguration.getActionListReceived();

        dateStrMap = getDateString();
        startDateString = dateStrMap.get( "START_DATE" );
        endDateString = dateStrMap.get( "END_DATE" );

        String actual = DashboardViewsImplQueryUtil.buildQuery(
                configNode,
                "startDate>=" + startDateString + " AND endDate<=" + endDateString + " AND time=10:08:02" );

        Assert.assertEquals(
                "type = ACTIONLIST AND receivedDateTime>="
                        + startDateString
                        + " AND receivedDateTime<="
                        + endDateString
                        + " AND receivedDateTime=10:08:02",

                actual );

        LOGGER.info( "DashboardViewsImplUtilTest >> ACTIONLISTRECEIVE >> Time and Scheme Query Tested:::::" );
    }

    private Map<String, String> getDateString()
    {

        ZonedDateTime startDate = ZonedDateTime.now();
        ZonedDateTime endDate = startDate.plusDays( 1 );

        String startDateString = startDate.getYear()
                + "-"
                + String.format( "%02d", startDate.getMonthValue() )
                + "-"
                + String.format( "%02d", startDate.getDayOfMonth() );

        String endDateString = endDate.getYear()
                + "-"
                + String.format( "%02d", endDate.getMonthValue() )
                + "-"
                + String.format( "%02d", endDate.getDayOfMonth() );

        Map<String, String> dateStrMap = new HashMap<>();
        dateStrMap.put( "START_DATE", startDateString );
        dateStrMap.put( "END_DATE", endDateString );

        return dateStrMap;

    }

}
