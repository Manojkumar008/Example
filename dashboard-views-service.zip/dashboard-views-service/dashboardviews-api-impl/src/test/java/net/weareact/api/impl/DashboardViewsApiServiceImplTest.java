/*
 * ************************************************************************** Copyright 2010 Applied Card Technologies
 * Ltd
 *
 * What : DashboardViewsApiServiceImplTest Who : kuyatega When : Feb 9, 2016
 *
 * Source control $Revision: 91803 $ $Author: markh2 $ $Date: 2012-11-12 14:00:56 +0000 (Mon, 12 Nov 2012) $
 *
 ****************************************************************************/

package net.weareact.api.impl;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import net.weareact.api.impl.config.DashBoardApiConfiguration;
import net.weareact.api.impl.utils.DashboardViewsImplUtil;
import net.weareact.dashboardview.model.DistributionList;
import net.weareact.dashboardview.model.DistributionList.GenerationStatusEnum;
import net.weareact.dashboardview.model.SchemeLink;

public class DashboardViewsApiServiceImplTest
{
    @Test
    public void testFilterDLResponse()
    {
        List<DistributionList> dlList = new ArrayList<>();

        SchemeLink sc = new SchemeLink();
        sc.setLink( "schemes/abc1" );

        DistributionList dl = new DistributionList();
        dl.setGenerationStartDateTime( ZonedDateTime.now().minusDays( 1 ) );
        dl.setGenerationStatus( GenerationStatusEnum.PENDING );
        dl.setUnscheduled( false );
        dl.setScheme( sc );

        DistributionList dl1 = new DistributionList();
        dl1.setGenerationStartDateTime( ZonedDateTime.now().plusDays( 1 ) );
        dl1.setGenerationStatus( GenerationStatusEnum.PENDING );
        dl1.setUnscheduled( false );
        SchemeLink sc1 = new SchemeLink();
        sc1.setLink( "schemes/abc2" );
        dl1.setScheme( sc1 );

        DistributionList dl2 = new DistributionList();
        dl2.setGenerationStartDateTime( ZonedDateTime.now().plusDays( 1 ) );
        dl2.setGenerationStatus( GenerationStatusEnum.GENERATED );
        dl2.setUnscheduled( false );
        SchemeLink sc2 = new SchemeLink();
        sc2.setLink( "schemes/abc3" );
        dl2.setScheme( sc2 );

        DistributionList dl3 = new DistributionList();
        dl3.setGenerationStartDateTime( ZonedDateTime.now().plusDays( 1 ) );
        dl3.setGenerationStatus( GenerationStatusEnum.FAILED_TO_GENERATE );
        dl3.setUnscheduled( false );
        SchemeLink sc3 = new SchemeLink();
        sc3.setLink( "schemes/abc4" );
        dl3.setScheme( sc3 );

        DistributionList dl4 = new DistributionList();
        dl4.setGenerationStartDateTime( ZonedDateTime.now().minusDays( 1 ) );
        dl4.setGenerationStatus( GenerationStatusEnum.GENERATED );
        dl4.setUnscheduled( false );
        SchemeLink sc4 = new SchemeLink();
        sc4.setLink( "schemes/abc5" );
        dl4.setScheme( sc4 );

        DistributionList dl5 = new DistributionList();
        dl5.setGenerationStartDateTime( ZonedDateTime.now().minusDays( 1 ) );
        dl5.setGenerationStatus( GenerationStatusEnum.FAILED_TO_GENERATE );
        dl5.setUnscheduled( false );
        SchemeLink sc5 = new SchemeLink();
        sc5.setLink( "schemes/abc6" );
        dl5.setScheme( sc5 );

        DistributionList dl6 = new DistributionList();
        dl6.setGenerationStartDateTime( ZonedDateTime.now().plusDays( 1 ) );
        dl6.setGenerationStatus( GenerationStatusEnum.PENDING );
        dl6.setUnscheduled( true );
        SchemeLink sc6 = new SchemeLink();
        sc6.setLink( "schemes/abc7" );
        dl6.setScheme( sc6 );

        dlList.add( dl );
        dlList.add( dl1 );
        dlList.add( dl2 );
        dlList.add( dl3 );
        dlList.add( dl4 );
        dlList.add( dl5 );
        dlList.add( dl6 );

        DashboardViewsImplUtil util = new DashboardViewsImplUtil( new DashBoardApiConfiguration() );
        List<DistributionList> filteredList = util.filterDLResponse( dlList );
        Assert.assertEquals( 3, filteredList.size() );
        Assert.assertEquals( GenerationStatusEnum.PENDING, filteredList.get( 0 ).getGenerationStatus() );
        Assert.assertEquals( GenerationStatusEnum.GENERATED, filteredList.get( 1 ).getGenerationStatus() );
        Assert.assertEquals( GenerationStatusEnum.FAILED_TO_GENERATE, filteredList.get( 2 ).getGenerationStatus() );

    }

    @Test
    public void testNullFilterDLResponse()
    {
        List<DistributionList> dlList = new ArrayList<>();
        DashboardViewsImplUtil util = new DashboardViewsImplUtil( new DashBoardApiConfiguration() );
        List<DistributionList> filteredList = util.filterDLResponse( dlList );
        Assert.assertEquals( 0, filteredList.size() );
    }
}
