package net.weareact.api.impl.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Validation;

import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.JsonNode;

import io.dropwizard.configuration.ConfigurationException;
import io.dropwizard.configuration.ConfigurationFactory;
import io.dropwizard.jackson.Jackson;
import net.weareact.api.impl.DistributionListToGraphDataForTopLevelGraph;
import net.weareact.api.impl.config.DashBoardApiConfiguration;
import net.weareact.dashboardview.model.DistributionList;
import net.weareact.dashboardview.model.DistributionList.GenerationStatusEnum;
import net.weareact.dashboardview.model.DistributionList.TypeEnum;
import net.weareact.dashboardview.model.ReceivedDistributionList;
import net.weareact.model.GraphDataPoint;

/**
 * 
 * @author Class to test DLQueryBuilder functionality
 *
 */
public class DashboardViewsImplUtilTest
{
    private static final Logger           LOGGER                    = LoggerFactory
                                                                            .getLogger(
                                                                                    DashboardViewsImplUtilTest.class
                                                                                            .getName() );

    // initialized in setup method
    static private DashboardViewsImplUtil dviUtil                   = null;

    // initialized in setup method
    static DashBoardApiConfiguration      dashBoardApiConfiguration = null;

    @BeforeClass
    @SuppressWarnings(
    { "unchecked", "rawtypes" } )
    public static void setUp() throws Exception
    {
        LOGGER.info( "DashboardViewsImplUtilTest >> invoking setUp :::::" );
        ConfigurationFactory<DashBoardApiConfiguration> configurationFactory = new ConfigurationFactory(
                DashBoardApiConfiguration.class,
                Validation.buildDefaultValidatorFactory().getValidator(),
                Jackson.newObjectMapper(),
                "d" );
        InputStream in = DashboardViewsImplUtilTest.class
                .getClassLoader()
                .getResourceAsStream( "dashboard-internal-test.yml" );
        File tempFile = File.createTempFile( "dashboard-internal-test", "tmp" );
        tempFile.deleteOnExit();
        FileOutputStream out = new FileOutputStream( tempFile );
        IOUtils.copy( in, out );

        dashBoardApiConfiguration = configurationFactory.build( tempFile );

        dviUtil = new DashboardViewsImplUtil( dashBoardApiConfiguration );
        LOGGER.info( "DashboardViewsImplUtilTest >> setUp invoked:::::" );
    }

    @Test
    public void testGraphDataForEmptyDistributionList() throws IOException, ConfigurationException
    {

        JsonNode graphConfig = dashBoardApiConfiguration.getActionListGeneration();

        DistributionListToGraphDataForTopLevelGraph graphData = new DistributionListToGraphDataForTopLevelGraph();

        List<DistributionList> distributionList = new ArrayList<>();

        DistributionList distList = new DistributionList();
        String time = "2016-01-12T01:00:00Z";
        ZonedDateTime zdt = ZonedDateTime.parse( time );

        distList.setGenerationStatus( GenerationStatusEnum.GENERATED );
        distList.setUnscheduled( false );

        distList.setGenerationStartDateTime( zdt );
        distList.setGenerationEndDateTime( ZonedDateTime.now() );

        distList.setSize( 100 );
        distList.setType( TypeEnum.ACTIONLIST );
        distributionList.add( distList );

        List<DistributionList> emptyList = new ArrayList<>();

        List<GraphDataPoint> graphDataPoint = graphData.splitDistributionListByTime( distributionList, graphConfig );

        Assert.assertFalse(
                graphDataPoint.stream().map( GraphDataPoint::getDataPointValues ).allMatch( dp -> dp.isEmpty() ) );

        List<GraphDataPoint> emptygraphDataPoint = graphData.splitDistributionListByTime( emptyList, graphConfig );

        Assert.assertTrue(
                emptygraphDataPoint.stream().map( GraphDataPoint::getDataPointValues ).allMatch( dp -> dp.isEmpty() ) );

        LOGGER.info( "DashboardViewsImplUtilTest >> ACTIONLISTGENERATE >> Empty Dist List Tested:::::" );

    }

    @Test
    public void testEmptyGraphDataForRecDistributionList() throws IOException, ConfigurationException
    {

        JsonNode graphConfig = dashBoardApiConfiguration.getActionListGeneration();

        DistributionListToGraphDataForTopLevelGraph graphData = new DistributionListToGraphDataForTopLevelGraph();

        List<ReceivedDistributionList> recDistributionList = new ArrayList<>();

        ReceivedDistributionList recDistList = new ReceivedDistributionList();
        String time = "2016-01-12T01:00:00Z";
        ZonedDateTime receivedDateTime = ZonedDateTime.parse( time );

        recDistList.setReceivedDateTime( receivedDateTime );

        recDistList.setSize( 100 );
        recDistList.setType( ReceivedDistributionList.TypeEnum.ACTIONLIST );
        recDistributionList.add( recDistList );

        List<ReceivedDistributionList> emptyRecDistList = new ArrayList<>();

        List<GraphDataPoint> graphDataPoint = graphData
                .splitRecDistributionListByTime( recDistributionList, graphConfig );
        List<GraphDataPoint> emptygraphDataPoint = graphData
                .splitRecDistributionListByTime( emptyRecDistList, graphConfig );

        Assert.assertFalse(
                graphDataPoint.stream().map( GraphDataPoint::getDataPointValues ).allMatch( dp -> dp.isEmpty() ) );
        Assert.assertTrue(
                emptygraphDataPoint.stream().map( GraphDataPoint::getDataPointValues ).allMatch( dp -> dp.isEmpty() ) );

        LOGGER.info( "DashboardViewsImplUtilTest >> ACTIONLISTRECEIVE >> Empty Rec Dist List Tested:::::" );

    }

}