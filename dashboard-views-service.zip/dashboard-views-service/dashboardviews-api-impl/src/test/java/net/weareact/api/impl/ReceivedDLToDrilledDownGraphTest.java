package net.weareact.api.impl;

import static org.mockito.Mockito.mock;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Validation;

import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import io.dropwizard.configuration.ConfigurationException;
import io.dropwizard.configuration.ConfigurationFactory;
import io.dropwizard.jackson.Jackson;
import junit.framework.Assert;
import net.weareact.api.impl.config.DashBoardApiConfiguration;
import net.weareact.dashboardview.model.ReceivedDistributionList;
import net.weareact.dashboardview.model.ReceivedDistributionList.TypeEnum;
import net.weareact.dashboardview.model.SchemeLink;
import net.weareact.model.GraphDataPoint;
import net.weareact.model.PointData;

@RunWith( MockitoJUnitRunner.class )
public class ReceivedDLToDrilledDownGraphTest
{

    private List<ReceivedDistributionList>          recvDLList;
    private DashBoardApiConfiguration               apiConfiguration;
    private DistributionListToGraphDataForDrillDown distributionListToGraphDataForDrillDown;

    @Before
    public void setUp() throws IOException, ConfigurationException
    {
        ReceivedDistributionList recDistList1 = new ReceivedDistributionList();
        recDistList1.setId( "-" + Math.random() );
        recDistList1.setReceivedDateTime( ZonedDateTime.parse( "2016-01-22T05:30:30+01:00[Europe/Paris]" ) );
        recDistList1.setSize( 1000 );
        recDistList1.setType( TypeEnum.ACTIONLIST );

        SchemeLink schemeLink1 = new SchemeLink();
        schemeLink1.setAbbreviation( "Brighton" );
        schemeLink1.setLink( "/schemes/000e45cc-b9e0-11e5-9912-ba0be0483c11" );
        recDistList1.setScheme( schemeLink1 );

        ReceivedDistributionList recDistList2 = new ReceivedDistributionList();
        recDistList2.setId( "DistId_" + Math.random() );

        recDistList2.setReceivedDateTime( ZonedDateTime.parse( "2016-01-22T06:30:30+01:00[Europe/Paris]" ) );
        recDistList2.setSize( 15 );
        recDistList2.setType( TypeEnum.ACTIONLIST );

        SchemeLink schemeLink2 = new SchemeLink();
        schemeLink2.setAbbreviation( "dist list abr" );
        schemeLink2.setLink( "/schemes/000e45cc-b9e0-11e5-9912-ba0be0483c11" );
        recDistList2.setScheme( schemeLink2 );

        ReceivedDistributionList recDistList3 = new ReceivedDistributionList();
        recDistList3.setId( "DistId_" + Math.random() );

        recDistList3.setReceivedDateTime( ZonedDateTime.parse( "2016-01-22T11:00:30+01:00[Europe/Paris]" ) );
        recDistList3.setSize( 500 );
        recDistList3.setType( TypeEnum.ACTIONLIST );

        SchemeLink schemeLink3 = new SchemeLink();
        schemeLink3.setAbbreviation( "Delhi" );
        schemeLink3.setLink( "/schemes/000e45cc-b9e0-11e5-9912-ba0be0483c13" );
        recDistList3.setScheme( schemeLink3 );

        ReceivedDistributionList recDistList4 = new ReceivedDistributionList();
        recDistList3.setId( "DistId_" + Math.random() );

        recDistList4.setReceivedDateTime( ZonedDateTime.parse( "2016-01-22T11:00:30+01:00[Europe/Paris]" ) );
        recDistList4.setSize( 5 );
        recDistList4.setType( TypeEnum.ACTIONLIST );

        SchemeLink schemeLink4 = new SchemeLink();
        schemeLink4.setAbbreviation( "London" );
        schemeLink4.setLink( "/schemes/000e45cc-b9e0-11e5-9912-ba0be0483c11" );
        recDistList4.setScheme( schemeLink4 );

        ReceivedDistributionList recDistList5 = new ReceivedDistributionList();
        recDistList5.setId( "-" + Math.random() );

        recDistList5.setReceivedDateTime( ZonedDateTime.parse( "2016-01-22T05:30:30+01:00[Europe/Paris]" ) );

        recDistList5.setSize( 700 );
        recDistList5.setType( TypeEnum.ACTIONLIST );

        SchemeLink schemeLink5 = new SchemeLink();
        schemeLink5.setAbbreviation( "Mumbai" );
        schemeLink5.setLink( "/schemes/000e45cc-b9e0-11e5-9912-ba0be0483c11" );
        recDistList5.setScheme( schemeLink5 );

        ReceivedDistributionList recDistList6 = new ReceivedDistributionList();
        recDistList6.setId( "-" + Math.random() );

        recDistList6.setReceivedDateTime( ZonedDateTime.parse( "2016-01-22T05:30:30+01:00[Europe/Paris]" ) );
        recDistList6.setSize( 2000 );
        recDistList6.setType( TypeEnum.ACTIONLIST );

        SchemeLink schemeLink6 = new SchemeLink();
        schemeLink6.setAbbreviation( "North" );
        schemeLink6.setLink( "/schemes/000e45cc-b9e0-11e5-9912-ba0be0483c11" );
        recDistList6.setScheme( schemeLink6 );

        ReceivedDistributionList recDistList7 = new ReceivedDistributionList();
        recDistList7.setId( "-" + Math.random() );

        recDistList7.setReceivedDateTime( ZonedDateTime.parse( "2016-01-22T05:30:30+01:00[Europe/Paris]" ) );
        recDistList7.setSize( 2000 );
        recDistList7.setType( TypeEnum.ACTIONLIST );

        SchemeLink schemeLink7 = new SchemeLink();
        schemeLink7.setAbbreviation( "Metrobus" );
        schemeLink7.setLink( "/schemes/000e45cc-b9e0-11e5-9912-ba0be0483c11" );
        recDistList7.setScheme( schemeLink7 );

        recvDLList = new ArrayList<>();
        recvDLList.add( recDistList1 );
        recvDLList.add( recDistList2 );
        recvDLList.add( recDistList3 );
        recvDLList.add( recDistList4 );
        recvDLList.add( recDistList5 );
        recvDLList.add( recDistList6 );
        recvDLList.add( recDistList7 );

        ConfigurationFactory<DashBoardApiConfiguration> configurationFactory = new ConfigurationFactory(
                DashBoardApiConfiguration.class,
                Validation.buildDefaultValidatorFactory().getValidator(),
                Jackson.newObjectMapper(),
                "d" );
        InputStream in = this.getClass().getClassLoader().getResourceAsStream( "dashboard-internal-test.yml" );
        File tempFile = File.createTempFile( "dashboard-internal-test", "tmp" );
        tempFile.deleteOnExit();
        FileOutputStream out = new FileOutputStream( tempFile );
        IOUtils.copy( in, out );

        apiConfiguration = configurationFactory.build( tempFile );
        distributionListToGraphDataForDrillDown = new DistributionListToGraphDataForDrillDown();

    }

    @Test
    public void convertReceivedDLtoGraphDataTest()
    {

        mock( DistributionListToGraphDataForDrillDown.class );
        Map<String, String> xyz = new HashMap<>();
        xyz.put( "en", "Delhi" );
        /*
         * when( test.callSchemeService( apiConfiguration.getACTIONLISTRECEIVEDDRILLDOWN(), new SchemeLink(), "" ) )
         * .thenReturn( xyz );
         */

        // verify( apiConfiguration.getACTIONLISTRECEIVEDDRILLDOWN(), new SchemeLink(), "" ).hitSchemeService( xyz );

        List<SchemeLink> missingSchemeLinkList = new ArrayList<>();

        SchemeLink schemeLinkObj = new SchemeLink();
        schemeLinkObj.setAbbreviation( "No_Value" );
        schemeLinkObj.setLink( "schemes/1" );
        missingSchemeLinkList.add( schemeLinkObj );

        List<GraphDataPoint> graphData = distributionListToGraphDataForDrillDown.convertReceivedDLtoGraphData(
                recvDLList,
                apiConfiguration.getActionListReceivedDrillDown(),
                "",
                missingSchemeLinkList );

        Assert.assertNotNull( graphData );
        Assert.assertEquals( graphData.get( 0 ).getDataPointLegend().toString(), "{en=Unscheduled, es=no programada}" );
        List<PointData> pointvals = graphData.get( 0 ).getDataPointValues();
        for ( PointData pointData : pointvals )
        {
            Assert.assertEquals( pointData.getPointLegend().toString(), "{en=Unscheduled, es=no programada}" );
            Assert.assertEquals( pointData.getPointValue().intValue(), 0 );

        }
        Assert.assertEquals( graphData.get( 1 ).getDataPointLegend().toString(), "{en=Success, es=Exito}" );
        List<PointData> pointvalsSuccess = graphData.get( 1 ).getDataPointValues();
        for ( PointData pointData : pointvalsSuccess )
        {
            Assert.assertEquals( pointData.getPointLegend().toString(), "{en=Success, es=Exito}" );

        }
        Assert.assertEquals( graphData.get( 2 ).getDataPointLegend().toString(), "{en=Failed, es=Ha fallado}" );
        List<PointData> pointvalsFailed = graphData.get( 2 ).getDataPointValues();
        for ( PointData pointData : pointvalsFailed )
        {
            Assert.assertEquals( pointData.getPointLegend().toString(), "{en=Failed, es=Ha fallado}" );
            Assert.assertEquals( pointData.getPointValue().intValue(), 0 );

        }

    }

    @Test
    public void convertReceivedDLtoGraphDataTestWithEmptyResponse()
    {
        List<SchemeLink> missingSchemeLinkList = new ArrayList<>();

        SchemeLink schemeLinkObj = new SchemeLink();
        schemeLinkObj.setAbbreviation( "No_Value" );
        schemeLinkObj.setLink( "schemes/1" );
        missingSchemeLinkList.add( schemeLinkObj );

        List<GraphDataPoint> graphData = distributionListToGraphDataForDrillDown.convertReceivedDLtoGraphData(
                new ArrayList(),
                apiConfiguration.getActionListReceivedDrillDown(),
                "",
                missingSchemeLinkList );
        Assert.assertTrue( graphData.isEmpty() );

    }
}
