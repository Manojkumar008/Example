package net.weareact.api.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Validation;

import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Test;

import com.fasterxml.jackson.databind.JsonNode;

import io.dropwizard.configuration.ConfigurationException;
import io.dropwizard.configuration.ConfigurationFactory;
import io.dropwizard.jackson.Jackson;
import net.weareact.api.impl.config.DashBoardApiConfiguration;
import net.weareact.dashboardview.model.DistributionList;
import net.weareact.dashboardview.model.DistributionList.GenerationStatusEnum;
import net.weareact.dashboardview.model.SchemeLink;
import net.weareact.model.GraphDataPoint;
import net.weareact.model.PointData;

public class DistributionListToGraphDataForTopLevelGraphTest
{
    private List<DistributionList>    dlList;
    private DashBoardApiConfiguration apiConfiguration;

    @Test
    public void setUp() throws IOException, ConfigurationException
    {
        List<DistributionList> dlList = new ArrayList<>();

        // Unschedule Past
        DistributionList dl1 = new DistributionList();
        dl1.setGenerationStartDateTime( ZonedDateTime.parse( "2016-01-15T05:30:30+01:00[Europe/Paris]" ) );
        dl1.setGenerationStatus( GenerationStatusEnum.PENDING );
        dl1.setSize( 1 );
        SchemeLink sc1 = new SchemeLink();
        sc1.setLink( "schemes/abc1" );
        dl1.setScheme( sc1 );
        dl1.setUnscheduled( true );

        DistributionList dl2 = new DistributionList();
        dl2.setGenerationStartDateTime( ZonedDateTime.parse( "2016-01-14T05:30:30+01:00[Europe/Paris]" ) );
        dl2.setGenerationStatus( GenerationStatusEnum.GENERATED );
        dl2.setSize( 2 );
        SchemeLink sc2 = new SchemeLink();
        sc2.setLink( "schemes/abc2" );
        dl2.setScheme( sc2 );
        dl2.setUnscheduled( true );

        DistributionList dl3 = new DistributionList();
        dl3.setGenerationStartDateTime( ZonedDateTime.parse( "2016-01-13T05:30:30+01:00[Europe/Paris]" ) );
        dl3.setGenerationStatus( GenerationStatusEnum.FAILED_TO_GENERATE );
        dl3.setSize( 1 );
        SchemeLink sc3 = new SchemeLink();
        sc3.setLink( "schemes/abc3" );
        dl3.setScheme( sc3 );
        dl3.setUnscheduled( true );

        DistributionList dl4 = new DistributionList();
        dl4.setGenerationStartDateTime( ZonedDateTime.parse( "2016-01-22T05:30:30+01:00[Europe/Paris]" ) );
        dl4.setGenerationStatus( GenerationStatusEnum.GENERATED );
        dl4.setSize( 9 );
        SchemeLink sc4 = new SchemeLink();
        sc4.setLink( "schemes/abc4" );
        dl4.setScheme( sc4 );
        dl4.setUnscheduled( true );

        DistributionList dl5 = new DistributionList();
        dl5.setGenerationStartDateTime( ZonedDateTime.parse( "2016-01-22T05:30:30+01:00[Europe/Paris]" ) );
        dl5.setGenerationStatus( GenerationStatusEnum.FAILED_TO_GENERATE );
        dl5.setSize( 1 );
        SchemeLink sc5 = new SchemeLink();
        sc5.setLink( "schemes/abc5" );
        dl5.setScheme( sc5 );
        dl5.setUnscheduled( true );

        // Unschedule Future

        DistributionList dl6 = new DistributionList();
        dl6.setGenerationStartDateTime( ZonedDateTime.parse( "3016-01-03T05:30:30+01:00[Europe/Paris]" ) );
        dl6.setGenerationStatus( GenerationStatusEnum.FAILED_TO_GENERATE );
        dl6.setSize( 1 );
        SchemeLink sc6 = new SchemeLink();
        sc6.setLink( "schemes/abc6" );
        dl6.setScheme( sc6 );
        dl6.setUnscheduled( true );

        DistributionList dl7 = new DistributionList();
        dl7.setGenerationStartDateTime( ZonedDateTime.parse( "3016-01-01T05:30:30+01:00[Europe/Paris]" ) );
        dl7.setGenerationStatus( GenerationStatusEnum.PENDING );
        dl7.setSize( 1 );
        SchemeLink sc7 = new SchemeLink();
        sc7.setLink( "schemes/abc7" );
        dl7.setScheme( sc7 );
        dl7.setUnscheduled( true );

        DistributionList dl8 = new DistributionList();
        dl8.setGenerationStartDateTime( ZonedDateTime.parse( "3016-01-02T05:30:30+01:00[Europe/Paris]" ) );
        dl8.setGenerationStatus( GenerationStatusEnum.GENERATED );
        dl8.setSize( 2 );
        SchemeLink sc8 = new SchemeLink();
        sc8.setLink( "schemes/abc8" );
        dl8.setScheme( sc8 );
        dl8.setUnscheduled( true );

        DistributionList dl9 = new DistributionList();
        dl9.setGenerationStartDateTime( ZonedDateTime.parse( "3016-01-22T05:30:30+01:00[Europe/Paris]" ) );
        dl9.setGenerationStatus( GenerationStatusEnum.GENERATED );
        dl9.setSize( 9 );
        SchemeLink sc9 = new SchemeLink();
        sc9.setLink( "schemes/abc9" );
        dl9.setScheme( sc9 );
        dl9.setUnscheduled( true );

        DistributionList dl10 = new DistributionList();
        dl10.setGenerationStartDateTime( ZonedDateTime.parse( "3016-01-22T05:30:30+01:00[Europe/Paris]" ) );
        dl10.setGenerationStatus( GenerationStatusEnum.FAILED_TO_GENERATE );
        dl10.setSize( 1 );
        SchemeLink sc10 = new SchemeLink();
        sc10.setLink( "schemes/abc10" );
        dl10.setScheme( sc10 );
        dl10.setUnscheduled( true );

        // Non Unschedule Past
        DistributionList dl11 = new DistributionList();
        dl11.setGenerationStartDateTime( ZonedDateTime.parse( "2016-01-15T05:30:30+01:00[Europe/Paris]" ) );
        dl11.setGenerationStatus( GenerationStatusEnum.PENDING );
        dl11.setSize( 1 );
        SchemeLink sc11 = new SchemeLink();
        sc11.setLink( "schemes/abc11" );
        dl11.setScheme( sc11 );
        dl11.setUnscheduled( false );

        DistributionList dl12 = new DistributionList();
        dl12.setGenerationStartDateTime( ZonedDateTime.parse( "2016-01-14T05:30:30+01:00[Europe/Paris]" ) );
        dl12.setGenerationStatus( GenerationStatusEnum.GENERATED );
        dl12.setSize( 2 );
        SchemeLink sc12 = new SchemeLink();
        sc12.setLink( "schemes/abc12" );
        dl12.setScheme( sc12 );
        dl12.setUnscheduled( false );

        DistributionList dl13 = new DistributionList();
        dl13.setGenerationStartDateTime( ZonedDateTime.parse( "2016-01-13T05:30:30+01:00[Europe/Paris]" ) );
        dl13.setGenerationStatus( GenerationStatusEnum.FAILED_TO_GENERATE );
        dl13.setSize( 1 );
        SchemeLink sc13 = new SchemeLink();
        sc13.setLink( "schemes/abc13" );
        dl13.setScheme( sc13 );
        dl13.setUnscheduled( false );

        DistributionList dl14 = new DistributionList();
        dl14.setGenerationStartDateTime( ZonedDateTime.parse( "2016-01-22T05:30:30+01:00[Europe/Paris]" ) );
        dl14.setGenerationStatus( GenerationStatusEnum.GENERATED );
        dl14.setSize( 9 );
        SchemeLink sc14 = new SchemeLink();
        sc14.setLink( "schemes/abc14" );
        dl14.setScheme( sc14 );
        dl14.setUnscheduled( false );

        DistributionList dl15 = new DistributionList();
        dl15.setGenerationStartDateTime( ZonedDateTime.parse( "2016-01-22T05:30:30+01:00[Europe/Paris]" ) );
        dl15.setGenerationStatus( GenerationStatusEnum.FAILED_TO_GENERATE );
        dl15.setSize( 1 );
        SchemeLink sc15 = new SchemeLink();
        sc15.setLink( "schemes/abc15" );
        dl15.setScheme( sc15 );
        dl15.setUnscheduled( false );

        // Non Unschedule Future
        DistributionList dl16 = new DistributionList();
        dl16.setGenerationStartDateTime( ZonedDateTime.parse( "3016-01-03T05:30:30+01:00[Europe/Paris]" ) );
        dl16.setGenerationStatus( GenerationStatusEnum.FAILED_TO_GENERATE );
        dl16.setSize( 1 );
        SchemeLink sc16 = new SchemeLink();
        sc16.setLink( "schemes/abc16" );
        dl16.setScheme( sc16 );
        dl16.setUnscheduled( false );

        DistributionList dl17 = new DistributionList();
        dl17.setGenerationStartDateTime( ZonedDateTime.parse( "3016-01-01T05:30:30+01:00[Europe/Paris]" ) );
        dl17.setGenerationStatus( GenerationStatusEnum.PENDING );
        dl17.setSize( 1 );
        SchemeLink sc17 = new SchemeLink();
        sc17.setLink( "schemes/abc17" );
        dl17.setScheme( sc17 );
        dl17.setUnscheduled( false );

        DistributionList dl18 = new DistributionList();
        dl18.setGenerationStartDateTime( ZonedDateTime.parse( "3016-01-02T05:30:30+01:00[Europe/Paris]" ) );
        dl18.setGenerationStatus( GenerationStatusEnum.GENERATED );
        dl18.setSize( 2 );
        SchemeLink sc18 = new SchemeLink();
        sc18.setLink( "schemes/abc18" );
        dl18.setScheme( sc18 );
        dl18.setUnscheduled( false );

        DistributionList dl19 = new DistributionList();
        dl19.setGenerationStartDateTime( ZonedDateTime.parse( "3016-01-22T05:30:30+01:00[Europe/Paris]" ) );
        dl19.setGenerationStatus( GenerationStatusEnum.GENERATED );
        dl19.setSize( 9 );
        SchemeLink sc19 = new SchemeLink();
        sc19.setLink( "schemes/abc19" );
        dl19.setScheme( sc19 );
        dl19.setUnscheduled( false );

        DistributionList dl20 = new DistributionList();
        dl20.setGenerationStartDateTime( ZonedDateTime.parse( "3016-01-22T05:30:30+01:00[Europe/Paris]" ) );
        dl20.setGenerationStatus( GenerationStatusEnum.FAILED_TO_GENERATE );
        dl20.setSize( 1 );
        SchemeLink sc20 = new SchemeLink();
        sc20.setLink( "schemes/abc20" );
        dl20.setScheme( sc20 );
        dl20.setUnscheduled( false );

        dlList.add( dl1 );
        dlList.add( dl2 );
        dlList.add( dl3 );
        dlList.add( dl4 );
        dlList.add( dl5 );
        dlList.add( dl6 );
        dlList.add( dl7 );
        dlList.add( dl8 );
        dlList.add( dl9 );
        dlList.add( dl10 );

        dlList.add( dl11 );
        dlList.add( dl12 );
        dlList.add( dl13 );
        dlList.add( dl14 );
        dlList.add( dl15 );
        dlList.add( dl16 );
        dlList.add( dl17 );
        dlList.add( dl18 );
        dlList.add( dl19 );
        dlList.add( dl20 );

        ConfigurationFactory<DashBoardApiConfiguration> configurationFactory = new ConfigurationFactory(
                DashBoardApiConfiguration.class,
                Validation.buildDefaultValidatorFactory().getValidator(),
                Jackson.newObjectMapper(),
                "d" );
        InputStream in = this.getClass().getClassLoader().getResourceAsStream( "dashboard-internal-test.yml" );
        File tempFile = File.createTempFile( "dashboard-internal-test", "tmp" );
        tempFile.deleteOnExit();
        FileOutputStream out = new FileOutputStream( tempFile );
        IOUtils.copy( in, out );

        apiConfiguration = configurationFactory.build( tempFile );

        checkTranlatorAlgorithm( dlList, apiConfiguration );
    }

    public void checkTranlatorAlgorithm( List<DistributionList> dlList, DashBoardApiConfiguration apiConfiguration )
    {
        DistributionListToGraphDataForTopLevelGraph drillDown = new DistributionListToGraphDataForTopLevelGraph();
        JsonNode graphConfig = apiConfiguration.getActionListGeneration();
        List<GraphDataPoint> graphData = drillDown.splitDistributionListByTime( dlList, graphConfig );

        Assert.assertEquals( 5, graphData.size() );
        // Assert Success legend
        Assert.assertEquals( 8, graphData.get( 0 ).getDataPointValues().size() );
        Object[] successCount =
        { 0, 2, 0, 0, 0, 0, 2, 0 };
        Assert.assertArrayEquals(
                successCount,
                graphData.get( 0 ).getDataPointValues().stream().map( PointData::getPointValue ).toArray() );

        // Assert Partial legend
        Assert.assertEquals( 8, graphData.get( 1 ).getDataPointValues().size() );
        Object[] partialCountCount =
        { 0, 0, 0, 10, 0, 0, 0, 10 };
        Assert.assertArrayEquals(
                partialCountCount,
                graphData.get( 1 ).getDataPointValues().stream().map( PointData::getPointValue ).toArray() );
        // Assert Failed legend
        Assert.assertEquals( 8, graphData.get( 2 ).getDataPointValues().size() );
        Object[] failedCount =
        { 0, 0, 2, 0, 2, 0, 0, 0 };
        Assert.assertArrayEquals(
                failedCount,
                graphData.get( 2 ).getDataPointValues().stream().map( PointData::getPointValue ).toArray() );

        // unscheduled legend
        Assert.assertEquals( 8, graphData.get( 3 ).getDataPointValues().size() );
        Object[] unscheduledCount =
        { 0, 2, 0, 9, 0, 0, 2, 9 };
        Assert.assertArrayEquals(
                unscheduledCount,
                graphData.get( 3 ).getDataPointValues().stream().map( PointData::getPointValue ).toArray() );

        // Next legend
        Assert.assertEquals( 8, graphData.get( 4 ).getDataPointValues().size() );
        Object[] nextCount =
        { 0, 0, 0, 0, 0, 2, 0, 0 };
        Assert.assertArrayEquals(
                nextCount,
                graphData.get( 4 ).getDataPointValues().stream().map( PointData::getPointValue ).toArray() );
    }
}
