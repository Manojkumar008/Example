package net.weareact.api.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Validation;

import org.apache.commons.io.IOUtils;
import org.junit.Test;

import com.fasterxml.jackson.databind.JsonNode;

import io.dropwizard.configuration.ConfigurationException;
import io.dropwizard.configuration.ConfigurationFactory;
import io.dropwizard.jackson.Jackson;
import net.weareact.api.impl.config.DashBoardApiConfiguration;
import net.weareact.api.impl.utils.DashboardViewsImplUtil;
import net.weareact.dashboardview.model.DistributionList;
import net.weareact.dashboardview.model.DistributionList.GenerationStatusEnum;
import net.weareact.dashboardview.model.DistributionList.TypeEnum;
import net.weareact.dashboardview.model.SchemeLink;

public class DistributionListToGraphDataForDrillDownTest
{
    private List<DistributionList>    dlList;
    private DashBoardApiConfiguration apiConfiguration;

    @Test
    public void setUp() throws IOException, ConfigurationException
    {
        DistributionList distList1 = new DistributionList();
        distList1.setId( "-" + Math.random() );

        distList1.setGenerationStartDateTime( ZonedDateTime.parse( "2016-01-22T05:30:30+01:00[Europe/Paris]" ) );
        distList1.setGenerationEndDateTime( ZonedDateTime.now() );
        distList1.setGenerationStatus( GenerationStatusEnum.GENERATED );
        distList1.setSize( 1000 );
        distList1.setType( TypeEnum.ACTIONLIST );
        distList1.setUnscheduled( false );

        SchemeLink schemeLink1 = new SchemeLink();
        schemeLink1.setAbbreviation( "Brighton" );
        schemeLink1.setLink( "/schemes/000e45cc-b9e0-11e5-9912-ba0be0483c11" );
        distList1.setScheme( schemeLink1 );

        DistributionList distList2 = new DistributionList();
        distList2.setId( "DistId_" + Math.random() );

        distList2.setGenerationStartDateTime( ZonedDateTime.parse( "2016-01-22T06:30:30+01:00[Europe/Paris]" ) );
        distList2.setGenerationEndDateTime( ZonedDateTime.now() );
        distList2.setGenerationStatus( GenerationStatusEnum.PENDING );
        distList2.setSize( 15 );
        distList2.setType( TypeEnum.ACTIONLIST );
        distList2.setUnscheduled( false );

        SchemeLink schemeLink2 = new SchemeLink();
        schemeLink2.setAbbreviation( "dist list abr" );
        schemeLink2.setLink( "scheme_link2" );
        distList2.setScheme( schemeLink2 );

        DistributionList distList3 = new DistributionList();
        distList3.setId( "DistId_" + Math.random() );

        distList3.setGenerationStartDateTime( ZonedDateTime.parse( "2016-01-22T11:00:30+01:00[Europe/Paris]" ) );
        distList3.setGenerationEndDateTime( ZonedDateTime.now() );
        distList3.setGenerationStatus( GenerationStatusEnum.FAILED_TO_GENERATE );
        distList3.setSize( 500 );
        distList3.setUnscheduled( false );
        distList3.setType( TypeEnum.ACTIONLIST );

        SchemeLink schemeLink3 = new SchemeLink();
        schemeLink3.setAbbreviation( "Delhi" );
        schemeLink3.setLink( "/schemes/000e45cc-b9e0-11e5-9912-ba0be0483c13" );
        distList3.setScheme( schemeLink3 );

        DistributionList distList4 = new DistributionList();
        distList3.setId( "DistId_" + Math.random() );

        distList4.setGenerationStartDateTime( ZonedDateTime.parse( "2016-01-22T11:00:30+01:00[Europe/Paris]" ) );
        distList4.setGenerationEndDateTime( ZonedDateTime.now() );
        distList4.setGenerationStatus( GenerationStatusEnum.GENERATED );
        distList4.setSize( 5 );
        distList4.setUnscheduled( true );
        distList4.setType( TypeEnum.ACTIONLIST );

        SchemeLink schemeLink4 = new SchemeLink();
        schemeLink4.setAbbreviation( "London" );
        schemeLink4.setLink( "scheme_link3" );
        distList4.setScheme( schemeLink4 );

        DistributionList distList5 = new DistributionList();
        distList5.setId( "-" + Math.random() );

        distList5.setGenerationStartDateTime( ZonedDateTime.parse( "2016-01-22T05:30:30+01:00[Europe/Paris]" ) );
        distList5.setGenerationEndDateTime( ZonedDateTime.now() );
        distList5.setGenerationStatus( GenerationStatusEnum.GENERATED );
        distList5.setSize( 700 );
        distList5.setType( TypeEnum.ACTIONLIST );
        distList5.setUnscheduled( false );

        SchemeLink schemeLink5 = new SchemeLink();
        schemeLink5.setAbbreviation( "Mumbai" );
        schemeLink5.setLink( "/schemes/000e45cc-b9e0-11e5-9912-ba0be0483c11" );
        distList5.setScheme( schemeLink5 );

        DistributionList distList6 = new DistributionList();
        distList6.setId( "-" + Math.random() );

        distList6.setGenerationStartDateTime( ZonedDateTime.parse( "2016-01-22T05:30:30+01:00[Europe/Paris]" ) );
        distList6.setGenerationEndDateTime( ZonedDateTime.now() );
        distList6.setGenerationStatus( GenerationStatusEnum.FAILED_TO_GENERATE );
        distList6.setSize( 2000 );
        distList6.setType( TypeEnum.ACTIONLIST );
        distList6.setUnscheduled( false );

        SchemeLink schemeLink6 = new SchemeLink();
        schemeLink6.setAbbreviation( "North" );
        schemeLink6.setLink( "/schemes/000e45cc-b9e0-11e5-9912-ba0be0483c11" );
        distList6.setScheme( schemeLink6 );

        DistributionList distList7 = new DistributionList();
        distList7.setId( "-" + Math.random() );

        distList7.setGenerationStartDateTime( ZonedDateTime.parse( "2016-01-22T05:30:30+01:00[Europe/Paris]" ) );
        distList7.setGenerationEndDateTime( ZonedDateTime.now() );
        distList7.setGenerationStatus( GenerationStatusEnum.FAILED_TO_GENERATE );
        distList7.setSize( 2000 );
        distList7.setType( TypeEnum.ACTIONLIST );
        distList7.setUnscheduled( true );

        SchemeLink schemeLink7 = new SchemeLink();
        schemeLink7.setAbbreviation( "Metrobus" );
        schemeLink7.setLink( "/schemes/000e45cc-b9e0-11e5-9912-ba0be0483c11" );
        distList7.setScheme( schemeLink7 );

        dlList = new ArrayList<>();
        dlList.add( distList1 );
        dlList.add( distList2 );
        dlList.add( distList3 );
        dlList.add( distList4 );
        dlList.add( distList5 );
        dlList.add( distList6 );
        dlList.add( distList7 );

        ConfigurationFactory<DashBoardApiConfiguration> configurationFactory = new ConfigurationFactory(
                DashBoardApiConfiguration.class,
                Validation.buildDefaultValidatorFactory().getValidator(),
                Jackson.newObjectMapper(),
                "d" );
        InputStream in = this.getClass().getClassLoader().getResourceAsStream( "dashboard-internal-test.yml" );
        File tempFile = File.createTempFile( "dashboard-internal-test", "tmp" );
        tempFile.deleteOnExit();
        FileOutputStream out = new FileOutputStream( tempFile );
        IOUtils.copy( in, out );

        apiConfiguration = configurationFactory.build( tempFile );

        checkDrillDownAlgorithm( dlList, apiConfiguration );
    }

    public void checkDrillDownAlgorithm(
            final List<DistributionList> dlList,
            final DashBoardApiConfiguration apiConfiguration )
    {
        DistributionListToGraphDataForDrillDown drillDown = new DistributionListToGraphDataForDrillDown();
        JsonNode graphConfig = apiConfiguration.getActionListGenerationDrillDown();
        DashboardViewsImplUtil util = new DashboardViewsImplUtil( apiConfiguration );
        List<DistributionList> filteredList = util.filterDLResponse( dlList );

        List<SchemeLink> missingSchemeLinkList = new ArrayList<>();

        SchemeLink schemeLinkObj = new SchemeLink();
        schemeLinkObj.setAbbreviation( "No_Value" );
        schemeLinkObj.setLink( "schemes/1" );
        missingSchemeLinkList.add( schemeLinkObj );

        drillDown.convertDLtoGraphData( filteredList, graphConfig, null, missingSchemeLinkList );
    }
}
