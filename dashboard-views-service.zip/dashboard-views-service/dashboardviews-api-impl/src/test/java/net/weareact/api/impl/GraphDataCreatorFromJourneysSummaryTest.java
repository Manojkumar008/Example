package net.weareact.api.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.validation.Validation;

import org.apache.commons.io.IOUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.databind.JsonNode;

import io.dropwizard.configuration.ConfigurationFactory;
import io.dropwizard.jackson.Jackson;
import net.weareact.api.impl.config.DashBoardApiConfiguration;
import net.weareact.api.impl.utils.DashboardViewsImplUtilTest;
import net.weareact.api.impl.utils.DateUtils;
import net.weareact.journeys.model.GroupSummary;
import net.weareact.model.GraphDataPoint;
import net.weareact.model.PointData;

public class GraphDataCreatorFromJourneysSummaryTest
{
    private GraphDataCreatorFromJourneysSummary creator                   = new GraphDataCreatorFromJourneysSummary();
    private static DashBoardApiConfiguration    dashBoardApiConfiguration = null;

    JsonNode                                    graphConfig;
    Map<LocalDate, Integer>                     totalJourneysForEightDays;
    Map<LocalDate, Integer>                     totalJourneysForEightWeeks;
    Map<LocalDate, Integer>                     totalJourneysForEightMonths;

    @Before
    public void setUp() throws Exception
    {
        ConfigurationFactory<DashBoardApiConfiguration> configurationFactory = new ConfigurationFactory(
                DashBoardApiConfiguration.class,
                Validation.buildDefaultValidatorFactory().getValidator(),
                Jackson.newObjectMapper(),
                "d" );
        InputStream in = DashboardViewsImplUtilTest.class
                .getClassLoader()
                .getResourceAsStream( "dashboard-internal-test.yml" );
        File tempFile = File.createTempFile( "dashboard-internal-test", "tmp" );
        tempFile.deleteOnExit();
        FileOutputStream out = new FileOutputStream( tempFile );
        IOUtils.copy( in, out );

        dashBoardApiConfiguration = configurationFactory.build( tempFile );
        graphConfig = dashBoardApiConfiguration.getJourneyRecordReceived();
        totalJourneysForEightDays = testDataForGetAveragePointDataListForEightDays();
        totalJourneysForEightWeeks = testDataForGetAveragePointDataListForEightWeeks();
        totalJourneysForEightMonths = testDataForGetAveragePointDataListForEightMonth();

    }

    @After
    public void tearDown() throws Exception
    {
    }

    @Test
    public void testGetAveragePointDataListForEightDays()
    {
        List<PointData> pointDataList = creator
                .getAveragePointDataList( graphConfig, totalJourneysForEightDays, "LAST_8_DAYS" );
        Assert.assertEquals( 8, pointDataList.size() );
        Assert.assertEquals( Integer.valueOf( 3 ), pointDataList.get( 7 ).getPointValue() );
        Assert.assertEquals( "TODAY", pointDataList.get( 7 ).getPointKey().get( "en" ) );
        Assert.assertEquals( Integer.valueOf( 3 ), pointDataList.get( 6 ).getPointValue() );
        Assert.assertEquals( Integer.valueOf( 2 ), pointDataList.get( 5 ).getPointValue() );
        Assert.assertEquals( Integer.valueOf( 3 ), pointDataList.get( 4 ).getPointValue() );
        Assert.assertEquals( Integer.valueOf( 3 ), pointDataList.get( 3 ).getPointValue() );
        Assert.assertEquals( Integer.valueOf( 1 ), pointDataList.get( 2 ).getPointValue() );
        Assert.assertEquals( Integer.valueOf( 3 ), pointDataList.get( 1 ).getPointValue() );
        Assert.assertEquals( Integer.valueOf( 5 ), pointDataList.get( 0 ).getPointValue() );

    }

    @Test
    public void testGetAveragePointDataListForEightWeeks()
    {

        List<PointData> pointDataList = creator
                .getAveragePointDataList( graphConfig, totalJourneysForEightWeeks, "LAST_8_WEEKS" );
        Assert.assertEquals( 8, pointDataList.size() );

        Assert.assertEquals( Integer.valueOf( 3 ), pointDataList.get( 7 ).getPointValue() );
        // Assert.assertEquals( "TODAY", pointDataList.get( 0 ).getPointKey().get( "en" ) );
        Assert.assertEquals( Integer.valueOf( 2 ), pointDataList.get( 6 ).getPointValue() );
        Assert.assertEquals( Integer.valueOf( 2 ), pointDataList.get( 5 ).getPointValue() );
        Assert.assertEquals( Integer.valueOf( 1 ), pointDataList.get( 4 ).getPointValue() );
        Assert.assertEquals( Integer.valueOf( 3 ), pointDataList.get( 3 ).getPointValue() );
        Assert.assertEquals( Integer.valueOf( 5 ), pointDataList.get( 2 ).getPointValue() );
        Assert.assertEquals( Integer.valueOf( 5 ), pointDataList.get( 1 ).getPointValue() );
        Assert.assertEquals( Integer.valueOf( 2 ), pointDataList.get( 0 ).getPointValue() );

    }

    @Test
    public void testGetAveragePointDataListForEightMonths()
    {

        List<PointData> pointDataList = creator
                .getAveragePointDataList( graphConfig, totalJourneysForEightMonths, "LAST_8_MONTHS" );
        Assert.assertEquals( 8, pointDataList.size() );

        Assert.assertEquals( Integer.valueOf( 1 ), pointDataList.get( 7 ).getPointValue() );
        // Assert.assertEquals( "TODAY", pointDataList.get( 0 ).getPointKey().get( "en" ) );
        Assert.assertEquals( Integer.valueOf( 2 ), pointDataList.get( 6 ).getPointValue() );
        Assert.assertEquals( Integer.valueOf( 3 ), pointDataList.get( 5 ).getPointValue() );
        Assert.assertEquals( Integer.valueOf( 4 ), pointDataList.get( 4 ).getPointValue() );
        Assert.assertEquals( Integer.valueOf( 5 ), pointDataList.get( 3 ).getPointValue() );
        Assert.assertEquals( Integer.valueOf( 6 ), pointDataList.get( 2 ).getPointValue() );
        Assert.assertEquals( Integer.valueOf( 7 ), pointDataList.get( 1 ).getPointValue() );
        Assert.assertEquals( Integer.valueOf( 8 ), pointDataList.get( 0 ).getPointValue() );

    }

    @Test
    public void testGraphDataForLastEightDays()
    {
        GroupSummary summary = setupTestDataForDays();
        JsonNode graphConfig = dashBoardApiConfiguration.getJourneyRecordReceived();
        GraphDataPoint graphDataPoint = creator
                .createCurrentGraphDataForReceivedJourneys( graphConfig, "LAST_8_DAYS", summary );

        Assert.assertNotNull( graphDataPoint );
        List<PointData> pointDataList = graphDataPoint.getDataPointValues();
        Assert.assertEquals( 8, pointDataList.size() );
        PointData pointData = pointDataList.get( pointDataList.size() - 1 );

        Assert.assertEquals( Integer.valueOf( 1 ), pointData.getPointValue() );

        PointData pointDataFirst = pointDataList.get( 0 );
        Assert.assertEquals( Integer.valueOf( 0 ), pointDataFirst.getPointValue() );
        Assert.assertEquals( "Processing", pointData.getPointLegend().get( "en" ) );

    }

    private GroupSummary setupTestDataForDays()
    {
        GroupSummary summary = new GroupSummary();
        summary.setTotal( Integer.valueOf( 5 ) );

        Map<String, GroupSummary> subGroupMap = new HashMap<>();

        GroupSummary subGroup = new GroupSummary();
        subGroup.setTotal( Integer.valueOf( 1 ) );

        ZonedDateTime currentDate = ZonedDateTime.now();
        subGroupMap.put( DateUtils.converDateToString( currentDate.withHour( 15 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusDays( 1 ).withHour( 15 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusDays( 2 ).withHour( 15 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusDays( 2 ).withHour( 16 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusDays( 3 ).withHour( 16 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusDays( 4 ).withHour( 15 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusDays( 4 ).withHour( 16 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusDays( 5 ).withHour( 15 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusDays( 5 ).withHour( 16 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusDays( 6 ).withHour( 15 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusDays( 6 ).withHour( 16 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusDays( 6 ).withHour( 17 ) ), subGroup );
        /*
         * subGroupMap .put( DateUtils.converDateToString( currentDate.minusDays( 7 ).withHour( 15 ) ), subGroup );
         * subGroupMap .put( DateUtils.converDateToString( currentDate.minusDays( 7 ).withHour( 16 ) ), subGroup );
         * subGroupMap .put( DateUtils.converDateToString( currentDate.minusDays( 7 ).withHour( 17 ) ), subGroup );
         */

        summary.setSubGroups( subGroupMap );

        return summary;
    }

    @Test
    public void testGraphDataForLastEightWeeks()
    {
        GroupSummary summary = setupTestDataForWeeks();
        JsonNode graphConfig = dashBoardApiConfiguration.getJourneyRecordReceived();
        GraphDataPoint graphDataPoint = creator
                .createCurrentGraphDataForReceivedJourneys( graphConfig, "LAST_8_WEEKS", summary );

        Assert.assertNotNull( graphDataPoint );

        List<PointData> pointDataList = graphDataPoint.getDataPointValues();
        Assert.assertEquals( 8, pointDataList.size() );
        PointData pointData = pointDataList.get( pointDataList.size() - 1 );

        Assert.assertEquals( "Processing", pointData.getPointLegend().get( "en" ) );

    }

    private GroupSummary setupTestDataForWeeks()
    {
        GroupSummary summary = new GroupSummary();
        summary.setTotal( Integer.valueOf( 5 ) );

        Map<String, GroupSummary> subGroupMap = new HashMap<>();

        GroupSummary subGroup = new GroupSummary();
        subGroup.setTotal( Integer.valueOf( 1 ) );

        ZonedDateTime currentDate = ZonedDateTime.now();
        subGroupMap.put( DateUtils.converDateToString( currentDate.withHour( 15 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusDays( 1 ).withHour( 15 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusDays( 2 ).withHour( 9 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusDays( 2 ).withHour( 8 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusDays( 3 ).withHour( 16 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusDays( 4 ).withHour( 15 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusDays( 4 ).withHour( 16 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusDays( 5 ).withHour( 15 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusDays( 5 ).withHour( 16 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusDays( 6 ).withHour( 15 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusDays( 6 ).withHour( 16 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusDays( 6 ).withHour( 17 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusDays( 7 ).withHour( 15 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusDays( 7 ).withHour( 16 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusDays( 7 ).withHour( 17 ) ), subGroup );

        subGroupMap.put( DateUtils.converDateToString( currentDate.minusDays( 9 ).withHour( 17 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusDays( 10 ).withHour( 17 ) ), subGroup );

        subGroupMap.put( DateUtils.converDateToString( currentDate.minusDays( 11 ).withHour( 17 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusDays( 12 ).withHour( 17 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusDays( 13 ).withHour( 17 ) ), subGroup );

        summary.setSubGroups( subGroupMap );

        return summary;
    }

    @Test
    public void testGraphDataForLastEightMonths()
    {
        GroupSummary summary = setupTestDataForZeroValueMonths();
        JsonNode graphConfig = dashBoardApiConfiguration.getJourneyRecordReceived();
        GraphDataPoint graphDataPoint = creator
                .createCurrentGraphDataForReceivedJourneys( graphConfig, "LAST_8_MONTHS", summary );

        Assert.assertNotNull( graphDataPoint );
        List<PointData> pointDataList = graphDataPoint.getDataPointValues();
        Assert.assertEquals( 10, pointDataList.size() );
        PointData pointData = pointDataList.get( pointDataList.size() - 1 );

        Assert.assertEquals( Integer.valueOf( 1 ), pointData.getPointValue() );
        Assert.assertEquals( "Processing", pointData.getPointLegend().get( "en" ) );

    }

    private GroupSummary setupTestDataForMonths()
    {
        GroupSummary summary = new GroupSummary();
        summary.setTotal( Integer.valueOf( 5 ) );

        Map<String, GroupSummary> subGroupMap = new HashMap<>();

        GroupSummary subGroup = new GroupSummary();
        subGroup.setTotal( Integer.valueOf( 1 ) );

        ZonedDateTime currentDate = ZonedDateTime.now();
        subGroupMap.put( DateUtils.converDateToString( currentDate.withHour( 15 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusMonths( 1 ).withHour( 15 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusMonths( 2 ).withHour( 15 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusMonths( 2 ).withHour( 16 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusMonths( 3 ).withHour( 16 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusMonths( 4 ).withHour( 15 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusMonths( 4 ).withHour( 16 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusMonths( 5 ).withHour( 15 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusMonths( 5 ).withHour( 16 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusMonths( 6 ).withHour( 15 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusMonths( 6 ).withHour( 16 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusMonths( 6 ).withHour( 17 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusMonths( 7 ).withHour( 15 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusMonths( 7 ).withHour( 16 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusMonths( 7 ).withHour( 17 ) ), subGroup );

        summary.setSubGroups( subGroupMap );

        return summary;
    }

    private GroupSummary setupTestDataForZeroValueMonths()
    {
        GroupSummary summary = new GroupSummary();
        summary.setTotal( Integer.valueOf( 5 ) );

        Map<String, GroupSummary> subGroupMap = new HashMap<>();

        GroupSummary subGroup = new GroupSummary();
        subGroup.setTotal( Integer.valueOf( 1 ) );

        ZonedDateTime currentDate = ZonedDateTime.now();
        subGroupMap.put( DateUtils.converDateToString( currentDate.withHour( 15 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusMonths( 1 ).withHour( 15 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusMonths( 2 ).withHour( 15 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusMonths( 2 ).withHour( 16 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusMonths( 3 ).withHour( 16 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusMonths( 4 ).withHour( 15 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusMonths( 4 ).withHour( 16 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusMonths( 5 ).withHour( 15 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusMonths( 5 ).withHour( 16 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusMonths( 6 ).withHour( 15 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusMonths( 6 ).withHour( 16 ) ), subGroup );
        subGroupMap.put( DateUtils.converDateToString( currentDate.minusMonths( 6 ).withHour( 17 ) ), subGroup );

        summary.setSubGroups( subGroupMap );

        return summary;
    }

    private Map<LocalDate, Integer> testDataForGetAveragePointDataListForEightDays()
    {
        Map<LocalDate, Integer> totalJourneysMap = new TreeMap();
        LocalDate currentDate = ZonedDateTime.now().toLocalDate();

        totalJourneysMap.put( currentDate.minusDays( 1 ), 1 );
        totalJourneysMap.put( currentDate.minusDays( 2 ), 2 );
        totalJourneysMap.put( currentDate.minusDays( 3 ), 3 );
        totalJourneysMap.put( currentDate.minusDays( 4 ), 1 );
        totalJourneysMap.put( currentDate.minusDays( 5 ), 2 );
        totalJourneysMap.put( currentDate.minusDays( 6 ), 4 );
        totalJourneysMap.put( currentDate.minusDays( 7 ), 1 );
        totalJourneysMap.put( currentDate.minusDays( 8 ), 1 );
        totalJourneysMap.put( currentDate.minusDays( 9 ), 1 );
        totalJourneysMap.put( currentDate.minusDays( 10 ), 2 );
        totalJourneysMap.put( currentDate.minusDays( 11 ), 2 );
        totalJourneysMap.put( currentDate.minusDays( 12 ), 2 );
        totalJourneysMap.put( currentDate.minusDays( 13 ), 5 );
        totalJourneysMap.put( currentDate.minusDays( 14 ), 5 );
        totalJourneysMap.put( currentDate.minusDays( 15 ), 5 );
        totalJourneysMap.put( currentDate.minusDays( 16 ), 4 );
        totalJourneysMap.put( currentDate.minusDays( 17 ), 4 );
        totalJourneysMap.put( currentDate.minusDays( 18 ), 4 );
        totalJourneysMap.put( currentDate.minusDays( 19 ), 1 );
        totalJourneysMap.put( currentDate.minusDays( 20 ), 1 );
        totalJourneysMap.put( currentDate.minusDays( 21 ), 6 );

        return totalJourneysMap;
    }

    private Map<LocalDate, Integer> testDataForGetAveragePointDataListForEightWeeks()
    {
        Map<LocalDate, Integer> totalJourneysMap = new TreeMap();
        LocalDate currentDate = ZonedDateTime.now().toLocalDate().with( DayOfWeek.SUNDAY );

        totalJourneysMap.put( currentDate, 3 );
        totalJourneysMap.put( currentDate.minusWeeks( 1 ), 5 );
        totalJourneysMap.put( currentDate.minusWeeks( 2 ), 2 );
        totalJourneysMap.put( currentDate.minusWeeks( 3 ), 3 );
        totalJourneysMap.put( currentDate.minusWeeks( 4 ), 1 );
        totalJourneysMap.put( currentDate.minusWeeks( 5 ), 2 );
        totalJourneysMap.put( currentDate.minusWeeks( 6 ), 4 );
        totalJourneysMap.put( currentDate.minusWeeks( 7 ), 7 );
        totalJourneysMap.put( currentDate.minusWeeks( 8 ), 4 );
        totalJourneysMap.put( currentDate.minusWeeks( 9 ), 1 );

        return totalJourneysMap;
    }

    private Map<LocalDate, Integer> testDataForGetAveragePointDataListForEightMonth()
    {
        Map<LocalDate, Integer> totalJourneysMap = new TreeMap();
        LocalDate localDate = ZonedDateTime.now().toLocalDate();
        LocalDate currentDate = localDate.withDayOfMonth( localDate.lengthOfMonth() );

        totalJourneysMap.put( currentDate, 3 );

        // totalJourneysMap.put(currentDate.minusMonths( 1 ).withDayOfMonth( currentDate.minusMonths( 1
        // ).getMonth().maxLength() ), 5 );

        for ( int i = 1; i < 10; i++ )
        {

            totalJourneysMap.put(
                    currentDate.minusMonths( i ).withDayOfMonth( currentDate.minusMonths( i ).getMonth().maxLength() ),
                    i );
        }

        return totalJourneysMap;
    }

    /*
     * @Test( expected = BadParameterException.class ) public void testGraphDataBadParameterException() { GroupSummary
     * summary = setupTestDataForMonths(); JsonNode graphConfig = dashBoardApiConfiguration.getJourneyRecordReceived();
     * GraphDataPoint graphDataPoint = creator .createGraphDataForReceivedJourneys( graphConfig, "LAST_8_YEARS", summary
     * ); }
     */

}
