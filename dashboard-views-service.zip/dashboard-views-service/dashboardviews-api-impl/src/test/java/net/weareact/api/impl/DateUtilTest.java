package net.weareact.api.impl;

import java.time.ZoneId;
import java.time.ZonedDateTime;

import org.junit.Test;

import junit.framework.Assert;
import net.weareact.api.impl.utils.DateUtils;

public class DateUtilTest
{
    @Test
    public void converDateToStringTest()
    {
        String date = DateUtils.converDateToString( ZonedDateTime.of( 2016, 2, 3, 15, 25, 0, 0, ZoneId.of( "UTC" ) ) );
        Assert.assertEquals( "2016-02-03T15:25:00Z", date );
    }

    @Test
    public void converDateToStringWithTimeZeroTest()
    {
        String date = DateUtils
                .converDateToStringwithTimeZero( ZonedDateTime.of( 2016, 2, 3, 15, 25, 0, 0, ZoneId.of( "UTC" ) ) );
        Assert.assertEquals( "2016-02-03T00:00:00Z", date );
    }
}
