package net.weareact.api.impl.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Map;

import javax.validation.Validation;

import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.JsonNode;

import io.dropwizard.configuration.ConfigurationFactory;
import io.dropwizard.jackson.Jackson;
import net.weareact.api.impl.config.DashBoardApiConfiguration;

public class JourneyRecordsReceivedUtilTest
{
    private static final Logger       LOGGER                    = LoggerFactory
                                                                        .getLogger(
                                                                                JourneyRecordsReceivedUtilTest.class
                                                                                        .getName() );

    // initialized in setup method
    static DashBoardApiConfiguration  dashBoardApiConfiguration = null;

    static JourneyRecordsReceivedUtil util                      = new JourneyRecordsReceivedUtil();
    private static final String       QUERY_KEY                 = "query";

    JsonNode                          configNode                = dashBoardApiConfiguration.getJourneyRecordReceived();
    String                            query                     = null;

    String                            timeFilter                = configNode.get( "timeFilter" ).asText();
    String                            columnIndex               = configNode.get( "columnIndex" ).asText();
    ZonedDateTime                     today                     = ZonedDateTime.now();

    JourneyRecordsReceivedUtil        fixedDateUtil             = new JourneyRecordsReceivedUtil()
                                                                {

                                                                    @Override
                                                                    protected ZonedDateTime getCurrentDate()
                                                                    {
                                                                        // return a fixed date always
                                                                        return ZonedDateTime.of(
                                                                                2016,
                                                                                06,
                                                                                06,
                                                                                11,
                                                                                10,
                                                                                10,
                                                                                00,
                                                                                ZoneId.of( "Z" ) );
                                                                    }

                                                                };

    @BeforeClass
    @SuppressWarnings(
    { "unchecked", "rawtypes" } )
    public static void setUp() throws Exception
    {
        LOGGER.info( "DashboardViewsImplUtilTest >> invoking setUp :::::" );
        ConfigurationFactory<DashBoardApiConfiguration> configurationFactory = new ConfigurationFactory(
                DashBoardApiConfiguration.class,
                Validation.buildDefaultValidatorFactory().getValidator(),
                Jackson.newObjectMapper(),
                "d" );
        InputStream in = JourneyRecordsReceivedUtilTest.class
                .getClassLoader()
                .getResourceAsStream( "dashboard-internal-test.yml" );
        File tempFile = File.createTempFile( "dashboard-internal-test", "tmp" );
        tempFile.deleteOnExit();
        FileOutputStream out = new FileOutputStream( tempFile );
        IOUtils.copy( in, out );

        dashBoardApiConfiguration = configurationFactory.build( tempFile );

        LOGGER.info( "DashboardViewsImplUtilTest >> setUp invoked:::::" );
    }

    @Test
    public void testBuildQueryForJourneySummary()
    {
        String query = "timeFilter = LAST_8_DAYS AND scheme.link IN(/schemes/1)";

        Map<String, String> queryMap = util.parseQueryString( query, timeFilter, columnIndex );
        Assert.assertEquals( queryMap.get( timeFilter ), "LAST_8_DAYS" );
        Assert.assertEquals( queryMap.get( QUERY_KEY ), "scheme.link IN(/schemes/1)" );
    }

    @Test
    public void testBuildQueryForJourneySummaryCase2()
    {
        String query = "timeFilter = LAST_8_DAYS";

        Map<String, String> queryMap = util.parseQueryString( query, timeFilter, columnIndex );
        Assert.assertEquals( queryMap.get( timeFilter ), "LAST_8_DAYS" );
        Assert.assertEquals( queryMap.get( QUERY_KEY ), "" );
    }

    @Test
    public void testBuildQueryForJourneySummaryCase3()
    {
        String query = "scheme.link IN(/schemes/1)";

        Map<String, String> queryMap = util.parseQueryString( query, timeFilter, columnIndex );
        Assert.assertEquals( queryMap.get( timeFilter ), "LAST_8_DAYS" );
        Assert.assertEquals( queryMap.get( QUERY_KEY ), "scheme.link IN(/schemes/1)" );
    }

    @Test
    public void testBuildQueryForJourneySummaryCase4()
    {
        String query = "";

        Map<String, String> queryMap = util.parseQueryString( query, timeFilter, columnIndex );
        Assert.assertEquals( queryMap.get( timeFilter ), "LAST_8_DAYS" );
        Assert.assertEquals( queryMap.get( QUERY_KEY ), "" );
    }

    @Test
    public void testBuildQueryForJourneySummaryCase5()
    {
        String query = "scheme.link IN(/schemes/1) AND timeFilter = LAST_8_DAYS";

        Map<String, String> queryMap = util.parseQueryString( query, timeFilter, columnIndex );
        Assert.assertEquals( queryMap.get( timeFilter ), "LAST_8_DAYS" );
        Assert.assertEquals( queryMap.get( QUERY_KEY ), "scheme.link IN(/schemes/1)" );
    }

    @Test
    public void testBuildQueryForJourneySummaryCase6()
    {
        String query = null;

        Map<String, String> queryMap = util.parseQueryString( query, timeFilter, columnIndex );
        Assert.assertEquals( queryMap.get( timeFilter ), "LAST_8_DAYS" );
        Assert.assertEquals( queryMap.get( QUERY_KEY ), "" );
    }

    @Test
    public void testBuildQueryTimeColumnAndScheme()
    {
        String query = "timeFilter = LAST_8_DAYS AND columnIndex = 3 AND scheme.link IN(/schemes/1)";

        Map<String, String> queryMap = util.parseQueryString( query, timeFilter, columnIndex );
        Assert.assertEquals( queryMap.get( timeFilter ), "LAST_8_DAYS" );
        Assert.assertEquals( queryMap.get( QUERY_KEY ), "scheme.link IN(/schemes/1)" );
        Assert.assertEquals( "3", queryMap.get( columnIndex ) );

    }

    @Test
    public void testBuildQueryColumnAndScheme()
    {
        String query = "columnIndex = 3 AND scheme.link IN(/schemes/1)";

        Map<String, String> queryMap = util.parseQueryString( query, timeFilter, columnIndex );
        Assert.assertEquals( queryMap.get( timeFilter ), "LAST_8_DAYS" );
        Assert.assertEquals( queryMap.get( QUERY_KEY ), "scheme.link IN(/schemes/1)" );
        Assert.assertEquals( "3", queryMap.get( columnIndex ) );
    }

    @Test
    public void testBuildQueryColumnOnly()
    {
        String query = "columnIndex = 3";

        Map<String, String> queryMap = util.parseQueryString( query, timeFilter, columnIndex );
        Assert.assertEquals( queryMap.get( timeFilter ), "LAST_8_DAYS" );
        Assert.assertEquals( queryMap.get( QUERY_KEY ), "" );
        Assert.assertEquals( "3", queryMap.get( columnIndex ) );
    }

    @Test
    public void testBuildQuerySchemeColumnTime()
    {
        String query = "scheme.link IN(/schemes/1) AND columnIndex = 5 AND timeFilter = LAST_8_WEEKS  ";

        Map<String, String> queryMap = util.parseQueryString( query, timeFilter, columnIndex );
        Assert.assertEquals( queryMap.get( timeFilter ), "LAST_8_WEEKS" );
        Assert.assertEquals( queryMap.get( QUERY_KEY ), "scheme.link IN(/schemes/1)" );
        Assert.assertEquals( "5", queryMap.get( columnIndex ) );

    }

    @Test
    public void testBuildQueryForDrilldown8Days()
    {

        String query = "timeFilter = LAST_8_DAYS AND columnIndex = 3 AND scheme.link IN(schemes/1)";

        Map<String, String> queryMap = fixedDateUtil.parseQueryString( query, timeFilter, columnIndex );
        query = fixedDateUtil.buildQueryForDrilldown( queryMap, configNode, false, 0 );

        String expectedQuery = "created>=2016-06-01T00:00:00Z AND created<=2016-06-01T23:59:59Z AND scheme.link IN(schemes/1)";
        Assert.assertEquals( expectedQuery, query );

        // for Average check and 1st week
        query = fixedDateUtil.buildQueryForDrilldown( queryMap, configNode, true, 1 );
        expectedQuery = "created>=2016-05-25T00:00:00Z AND created<=2016-05-25T23:59:59Z AND scheme.link IN(schemes/1)";
        Assert.assertEquals( expectedQuery, query );

        // for Average check and 2nd week
        query = fixedDateUtil.buildQueryForDrilldown( queryMap, configNode, true, 2 );
        expectedQuery = "created>=2016-05-18T00:00:00Z AND created<=2016-05-18T23:59:59Z AND scheme.link IN(schemes/1)";
        Assert.assertEquals( expectedQuery, query );

    }

    @Test
    public void testBuildQueryForDrilldown8Weeks()
    {
        String query = "timeFilter = LAST_8_WEEKS AND columnIndex = 3 AND scheme.link IN(schemes/1)";
        Map<String, String> queryMap = fixedDateUtil.parseQueryString( query, timeFilter, columnIndex );
        query = fixedDateUtil.buildQueryForDrilldown( queryMap, configNode, false, 0 );

        String expectedQuery = "created>=2016-05-02T00:00:00Z AND created<=2016-05-08T23:59:59Z AND scheme.link IN(schemes/1)";

        Assert.assertEquals( expectedQuery, query );

        query = fixedDateUtil.buildQueryForDrilldown( queryMap, configNode, true, 0 );
        expectedQuery = "created>=2016-04-18T00:00:00Z AND created<=2016-05-01T23:59:59Z AND scheme.link IN(schemes/1)";
        Assert.assertEquals( expectedQuery, query );
    }

    @Test
    public void testBuildQueryForDrilldown8Months()
    {
        String query = "timeFilter = LAST_8_MONTHS AND columnIndex = 5 AND scheme.link IN(schemes/1)";
        Map<String, String> queryMap = fixedDateUtil.parseQueryString( query, timeFilter, columnIndex );
        query = fixedDateUtil.buildQueryForDrilldown( queryMap, configNode, false, 0 );

        String expectedQuery = "created>=2016-03-01T00:00:00Z AND created<=2016-03-31T23:59:59Z AND scheme.link IN(schemes/1)";

        Assert.assertEquals( expectedQuery, query );

        query = fixedDateUtil.buildQueryForDrilldown( queryMap, configNode, true, 0 );

    }
}
