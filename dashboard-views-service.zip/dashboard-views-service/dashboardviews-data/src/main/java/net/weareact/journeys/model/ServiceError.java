package net.weareact.journeys.model;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

@javax.annotation.Generated(
        value = "class io.swagger.codegen.languages.JavaClientCodegen",
        date = "2016-05-25T13:36:23.255Z" )
public class ServiceError
{

    private String developerMessage = null;
    private String userMessage      = null;
    private String errorCode        = null;
    private String moreInfo         = null;

    /**
     * A message to assist developers investigate the cause of an error
     **/
    public ServiceError developerMessage( String developerMessage )
    {
        this.developerMessage = developerMessage;
        return this;
    }

    @ApiModelProperty( example = "null", value = "A message to assist developers investigate the cause of an error" )
    @JsonProperty( "developerMessage" )
    public String getDeveloperMessage()
    {
        return developerMessage;
    }

    public void setDeveloperMessage( String developerMessage )
    {
        this.developerMessage = developerMessage;
    }

    /**
     * A suitable message for displaying to users of the client receiving this error
     **/
    public ServiceError userMessage( String userMessage )
    {
        this.userMessage = userMessage;
        return this;
    }

    @ApiModelProperty(
            example = "null",
            required = true,
            value = "A suitable message for displaying to users of the client receiving this error" )
    @JsonProperty( "userMessage" )
    public String getUserMessage()
    {
        return userMessage;
    }

    public void setUserMessage( String userMessage )
    {
        this.userMessage = userMessage;
    }

    /**
     * The ACT code for this error
     **/
    public ServiceError errorCode( String errorCode )
    {
        this.errorCode = errorCode;
        return this;
    }

    @ApiModelProperty( example = "null", required = true, value = "The ACT code for this error" )
    @JsonProperty( "errorCode" )
    public String getErrorCode()
    {
        return errorCode;
    }

    public void setErrorCode( String errorCode )
    {
        this.errorCode = errorCode;
    }

    /**
     * Additional information that is relevant to this error
     **/
    public ServiceError moreInfo( String moreInfo )
    {
        this.moreInfo = moreInfo;
        return this;
    }

    @ApiModelProperty( example = "null", value = "Additional information that is relevant to this error" )
    @JsonProperty( "moreInfo" )
    public String getMoreInfo()
    {
        return moreInfo;
    }

    public void setMoreInfo( String moreInfo )
    {
        this.moreInfo = moreInfo;
    }

    @Override
    public boolean equals( java.lang.Object o )
    {
        if ( this == o )
        {
            return true;
        }
        if ( o == null || getClass() != o.getClass() )
        {
            return false;
        }
        ServiceError serviceError = ( ServiceError ) o;
        return Objects.equals( this.developerMessage, serviceError.developerMessage )
                && Objects.equals( this.userMessage, serviceError.userMessage )
                && Objects.equals( this.errorCode, serviceError.errorCode )
                && Objects.equals( this.moreInfo, serviceError.moreInfo );
    }

    @Override
    public int hashCode()
    {
        return Objects.hash( developerMessage, userMessage, errorCode, moreInfo );
    }

    @Override
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        sb.append( "class ServiceError {\n" );

        sb.append( "    developerMessage: " ).append( toIndentedString( developerMessage ) ).append( "\n" );
        sb.append( "    userMessage: " ).append( toIndentedString( userMessage ) ).append( "\n" );
        sb.append( "    errorCode: " ).append( toIndentedString( errorCode ) ).append( "\n" );
        sb.append( "    moreInfo: " ).append( toIndentedString( moreInfo ) ).append( "\n" );
        sb.append( "}" );
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces (except the first line).
     */
    private String toIndentedString( java.lang.Object o )
    {
        if ( o == null )
        {
            return "null";
        }
        return o.toString().replace( "\n", "\n    " );
    }
}
