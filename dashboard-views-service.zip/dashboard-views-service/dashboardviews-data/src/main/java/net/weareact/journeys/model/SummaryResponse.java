package net.weareact.journeys.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

@javax.annotation.Generated(
        value = "class io.swagger.codegen.languages.JavaClientCodegen",
        date = "2016-05-25T13:36:23.255Z" )
public class SummaryResponse
{

    private SummaryMeta        meta          = null;
    private GroupSummary       summary       = null;
    private List<Notification> notifications = new ArrayList<Notification>();

    /**
     * Contains meta for results
     **/
    public SummaryResponse meta( SummaryMeta meta )
    {
        this.meta = meta;
        return this;
    }

    @ApiModelProperty( example = "null", required = true, value = "Contains meta for results" )
    @JsonProperty( "meta" )
    public SummaryMeta getMeta()
    {
        return meta;
    }

    public void setMeta( SummaryMeta meta )
    {
        this.meta = meta;
    }

    /**
     * A count of resource items grouped and filtered as per the summary request
     **/
    public SummaryResponse summary( GroupSummary summary )
    {
        this.summary = summary;
        return this;
    }

    @ApiModelProperty(
            example = "null",
            required = true,
            value = "A count of resource items grouped and filtered as per the summary request" )
    @JsonProperty( "summary" )
    public GroupSummary getSummary()
    {
        return summary;
    }

    public void setSummary( GroupSummary summary )
    {
        this.summary = summary;
    }

    /**
     * Contains notifications relating to the resources that have been returned
     **/
    public SummaryResponse notifications( List<Notification> notifications )
    {
        this.notifications = notifications;
        return this;
    }

    @ApiModelProperty(
            example = "null",
            required = true,
            value = "Contains notifications relating to the resources that have been returned" )
    @JsonProperty( "notifications" )
    public List<Notification> getNotifications()
    {
        return notifications;
    }

    public void setNotifications( List<Notification> notifications )
    {
        this.notifications = notifications;
    }

    @Override
    public boolean equals( java.lang.Object o )
    {
        if ( this == o )
        {
            return true;
        }
        if ( o == null || getClass() != o.getClass() )
        {
            return false;
        }
        SummaryResponse summaryResponse = ( SummaryResponse ) o;
        return Objects.equals( this.meta, summaryResponse.meta )
                && Objects.equals( this.summary, summaryResponse.summary )
                && Objects.equals( this.notifications, summaryResponse.notifications );
    }

    @Override
    public int hashCode()
    {
        return Objects.hash( meta, summary, notifications );
    }

    @Override
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        sb.append( "class SummaryResponse {\n" );

        sb.append( "    meta: " ).append( toIndentedString( meta ) ).append( "\n" );
        sb.append( "    summary: " ).append( toIndentedString( summary ) ).append( "\n" );
        sb.append( "    notifications: " ).append( toIndentedString( notifications ) ).append( "\n" );
        sb.append( "}" );
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces (except the first line).
     */
    private String toIndentedString( java.lang.Object o )
    {
        if ( o == null )
        {
            return "null";
        }
        return o.toString().replace( "\n", "\n    " );
    }
}
