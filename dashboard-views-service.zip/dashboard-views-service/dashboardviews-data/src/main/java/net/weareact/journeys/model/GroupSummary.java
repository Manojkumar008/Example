package net.weareact.journeys.model;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

@javax.annotation.Generated(
        value = "class io.swagger.codegen.languages.JavaClientCodegen",
        date = "2016-05-25T13:36:23.255Z" )
public class GroupSummary
{

    private Integer                   total     = null;
    private Map<String, GroupSummary> subGroups = new HashMap<String, GroupSummary>();

    /**
     * The total number of results in this group or sub-group
     **/
    public GroupSummary total( Integer total )
    {

        this.total = total;
        return this;
    }

    @ApiModelProperty(
            example = "null",
            required = true,
            value = "The total number of results in this group or sub-group" )
    @JsonProperty( "total" )
    public Integer getTotal()
    {
        return total;
    }

    public void setTotal( Integer total )
    {
        this.total = total;
    }

    /**
     * The next level of grouped results
     **/
    public GroupSummary subGroups( Map<String, GroupSummary> subGroups )
    {
        this.subGroups = subGroups;
        return this;
    }

    @ApiModelProperty( example = "null", value = "The next level of grouped results" )
    @JsonProperty( "subGroups" )
    public Map<String, GroupSummary> getSubGroups()
    {
        return subGroups;
    }

    public void setSubGroups( Map<String, GroupSummary> subGroups )
    {
        this.subGroups = subGroups;
    }

    @Override
    public boolean equals( java.lang.Object o )
    {
        if ( this == o )
        {
            return true;
        }
        if ( o == null || getClass() != o.getClass() )
        {
            return false;
        }
        GroupSummary groupSummary = ( GroupSummary ) o;
        return Objects.equals( this.total, groupSummary.total )
                && Objects.equals( this.subGroups, groupSummary.subGroups );
    }

    @Override
    public int hashCode()
    {
        return Objects.hash( total, subGroups );
    }

    @Override
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        sb.append( "class GroupSummary {\n" );

        sb.append( "    total: " ).append( toIndentedString( total ) ).append( "\n" );
        sb.append( "    subGroups: " ).append( toIndentedString( subGroups ) ).append( "\n" );
        sb.append( "}" );
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces (except the first line).
     */
    private String toIndentedString( java.lang.Object o )
    {
        if ( o == null )
        {
            return "null";
        }
        return o.toString().replace( "\n", "\n    " );
    }
}
