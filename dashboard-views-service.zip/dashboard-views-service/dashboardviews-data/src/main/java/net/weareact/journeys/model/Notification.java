package net.weareact.journeys.model;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;

import io.swagger.annotations.ApiModelProperty;

@javax.annotation.Generated(
        value = "class io.swagger.codegen.languages.JavaClientCodegen",
        date = "2016-05-25T13:36:23.255Z" )
public class Notification
{

    private String id      = null;
    private String subject = null;
    private Object payload = null;

    public enum TypeEnum
    {
     MESSAGE( "message" );

        private String value;

        TypeEnum( String value )
        {
            this.value = value;
        }

        @Override
        @JsonValue
        public String toString()
        {
            return value;
        }
    }

    private TypeEnum type = null;

    /**
     * The id associated with the notification. This is used to match the notification to events that have been sent via
     * the messaging service
     **/
    public Notification id( String id )
    {
        this.id = id;
        return this;
    }

    @ApiModelProperty(
            example = "null",
            value = "The id associated with the notification. This is used to match the notification to events that have been sent via the messaging service" )
    @JsonProperty( "id" )
    public String getId()
    {
        return id;
    }

    public void setId( String id )
    {
        this.id = id;
    }

    /**
     **/
    public Notification subject( String subject )
    {
        this.subject = subject;
        return this;
    }

    @ApiModelProperty( example = "null", value = "" )
    @JsonProperty( "subject" )
    public String getSubject()
    {
        return subject;
    }

    public void setSubject( String subject )
    {
        this.subject = subject;
    }

    /**
     * The notification content. Note this can contain either a simple message or a JSON object
     **/
    public Notification payload( Object payload )
    {
        this.payload = payload;
        return this;
    }

    @ApiModelProperty(
            example = "null",
            value = "The notification content. Note this can contain either a simple message or a JSON object" )
    @JsonProperty( "payload" )
    public Object getPayload()
    {
        return payload;
    }

    public void setPayload( Object payload )
    {
        this.payload = payload;
    }

    /**
     * The type of the notification
     **/
    public Notification type( TypeEnum type )
    {
        this.type = type;
        return this;
    }

    @ApiModelProperty( example = "null", value = "The type of the notification" )
    @JsonProperty( "type" )
    public TypeEnum getType()
    {
        return type;
    }

    public void setType( TypeEnum type )
    {
        this.type = type;
    }

    @Override
    public boolean equals( java.lang.Object o )
    {
        if ( this == o )
        {
            return true;
        }
        if ( o == null || getClass() != o.getClass() )
        {
            return false;
        }
        Notification notification = ( Notification ) o;
        return Objects.equals( this.id, notification.id )
                && Objects.equals( this.subject, notification.subject )
                && Objects.equals( this.payload, notification.payload )
                && Objects.equals( this.type, notification.type );
    }

    @Override
    public int hashCode()
    {
        return Objects.hash( id, subject, payload, type );
    }

    @Override
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        sb.append( "class Notification {\n" );

        sb.append( "    id: " ).append( toIndentedString( id ) ).append( "\n" );
        sb.append( "    subject: " ).append( toIndentedString( subject ) ).append( "\n" );
        sb.append( "    payload: " ).append( toIndentedString( payload ) ).append( "\n" );
        sb.append( "    type: " ).append( toIndentedString( type ) ).append( "\n" );
        sb.append( "}" );
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces (except the first line).
     */
    private String toIndentedString( java.lang.Object o )
    {
        if ( o == null )
        {
            return "null";
        }
        return o.toString().replace( "\n", "\n    " );
    }
}
