package net.weareact.journeys.model;

import java.util.Date;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

@javax.annotation.Generated(
        value = "class io.swagger.codegen.languages.JavaClientCodegen",
        date = "2016-05-25T13:36:23.255Z" )
public class SummaryMeta
{

    private String query           = null;
    private String grouping        = null;
    private Date   timeOfExecution = null;

    /**
     * The CQL search query used to filter the results
     **/
    public SummaryMeta query( String query )
    {
        this.query = query;
        return this;
    }

    @ApiModelProperty( example = "null", value = "The CQL search query used to filter the results" )
    @JsonProperty( "query" )
    public String getQuery()
    {
        return query;
    }

    public void setQuery( String query )
    {
        this.query = query;
    }

    /**
     * The comma separated fields used to group results by
     **/
    public SummaryMeta grouping( String grouping )
    {
        this.grouping = grouping;
        return this;
    }

    @ApiModelProperty( example = "null", value = "The comma separated fields used to group results by" )
    @JsonProperty( "grouping" )
    public String getGrouping()
    {
        return grouping;
    }

    public void setGrouping( String grouping )
    {
        this.grouping = grouping;
    }

    /**
     * The date and time at which the summary response was provided
     **/
    public SummaryMeta timeOfExecution( Date timeOfExecution )
    {
        this.timeOfExecution = timeOfExecution;
        return this;
    }

    @ApiModelProperty(
            example = "null",
            required = true,
            value = "The date and time at which the summary response was provided" )
    @JsonProperty( "timeOfExecution" )
    public Date getTimeOfExecution()
    {
        return timeOfExecution;
    }

    public void setTimeOfExecution( Date timeOfExecution )
    {
        this.timeOfExecution = timeOfExecution;
    }

    @Override
    public boolean equals( java.lang.Object o )
    {
        if ( this == o )
        {
            return true;
        }
        if ( o == null || getClass() != o.getClass() )
        {
            return false;
        }
        SummaryMeta summaryMeta = ( SummaryMeta ) o;
        return Objects.equals( this.query, summaryMeta.query )
                && Objects.equals( this.grouping, summaryMeta.grouping )
                && Objects.equals( this.timeOfExecution, summaryMeta.timeOfExecution );
    }

    @Override
    public int hashCode()
    {
        return Objects.hash( query, grouping, timeOfExecution );
    }

    @Override
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        sb.append( "class SummaryMeta {\n" );

        sb.append( "    query: " ).append( toIndentedString( query ) ).append( "\n" );
        sb.append( "    grouping: " ).append( toIndentedString( grouping ) ).append( "\n" );
        sb.append( "    timeOfExecution: " ).append( toIndentedString( timeOfExecution ) ).append( "\n" );
        sb.append( "}" );
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces (except the first line).
     */
    private String toIndentedString( java.lang.Object o )
    {
        if ( o == null )
        {
            return "null";
        }
        return o.toString().replace( "\n", "\n    " );
    }
}
