
package net.weareact.stepdefs.journeys;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.time.DayOfWeek;
import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.Map;

import javax.validation.Validation;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.io.IOUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import cucumber.api.java.en.Given;
import io.dropwizard.configuration.ConfigurationFactory;
import io.dropwizard.jackson.Jackson;
import net.weareact.api.impl.config.DashBoardApiConfiguration;
import net.weareact.api.impl.utils.DateUtils;
import net.weareact.journeys.model.GroupSummary;
import net.weareact.journeys.model.SummaryResponse;
import net.weareact.utils.DVSIntegrationUtil;

public class JourneysAverageRecordsForGraph
{
    private static final Integer             PORT                      = 18080;
    private static final String              HOST_NAME                 = "localhost";
    private static final String              API_HOST_NAME             = "localhost";
    private static final String              DASH_BOARD_VIEWS_API_PATH = "v1/dashboard-views";
    private static final String              JWT_ASSERTION_HEADER      = "X-JWT-Assertion";
    JsonNode                                 graphConfig;
    private Response                         apiResponse;
    private static DashBoardApiConfiguration dashBoardApiConfiguration = null;

    DVSIntegrationUtil                       iUtil                     = new DVSIntegrationUtil();

    @Given( "^Average data of Journey Service for last (\\d+) \"(.*?)\"$" )
    public void average_data_of_Journey_Service_for_last( int num, String timeFilter ) throws Throwable
    {
        ConfigurationFactory<DashBoardApiConfiguration> configurationFactory = new ConfigurationFactory(
                DashBoardApiConfiguration.class,
                Validation.buildDefaultValidatorFactory().getValidator(),
                Jackson.newObjectMapper(),
                "d" );
        InputStream in = this.getClass().getClassLoader().getResourceAsStream( "dashboard-internal-test.yml" );
        File tempFile = File.createTempFile( "dashboard-internal-test", "tmp" );
        tempFile.deleteOnExit();
        FileOutputStream out = new FileOutputStream( tempFile );
        IOUtils.copy( in, out );

        dashBoardApiConfiguration = configurationFactory.build( tempFile );

        GroupSummary summary = new GroupSummary();
        String endDate = "";
        String startDate = "";
        JsonNode graphConfig = dashBoardApiConfiguration.getJourneyRecordReceived();
        int rollBackNumber = graphConfig.get( "rollBackNumber" ).asInt();
        ;

        int rollbacknum = 5;
        ZonedDateTime currentDataEndDate;

        ZonedDateTime currentDataStartDate = null;
        ZonedDateTime averageDataEndDate = null;
        ZonedDateTime averageDataStartDate = null;
        ZonedDateTime currentDate = ZonedDateTime.now();
        Map<String, GroupSummary> averageDataMap = new HashMap<>();
        switch ( timeFilter )
        {
        case "days":
            currentDataEndDate = currentDate.withHour( 23 ).withMinute( 59 ).withSecond( 59 );
            currentDataStartDate = currentDataEndDate.minusDays( 8 ).plusSeconds( 1 );
            averageDataEndDate = currentDataStartDate.minusSeconds( 1 );
            averageDataStartDate = currentDataStartDate.minusDays( rollbacknum * 7 );
            // need to do bellow steps before loop, as value of averageDataEndDate keeps on changing
            endDate = DateUtils.converDateToString( averageDataEndDate );
            startDate = DateUtils.converDateToStringwithTimeZero( averageDataStartDate );
            if ( num == 0 )
            {
                summary.setSubGroups( averageDataMap );
                break;
            }
            for ( int i = 0; i < rollbacknum * 7; i++ )
            {
                GroupSummary groupSummary = new GroupSummary();
                groupSummary.setTotal( 1 );
                averageDataMap.put( DateUtils.converDateToStringwithTimeZero( averageDataEndDate ), groupSummary );

                averageDataEndDate = averageDataEndDate.minusDays( 1 );

            }
            summary.setSubGroups( averageDataMap );

            break;
        case "months":

            ZonedDateTime endDateOfMonth;

            endDateOfMonth = ZonedDateTime
                    .now()
                    .plusDays( ZonedDateTime.now().getMonth().maxLength() - currentDate.getDayOfMonth() );
            endDateOfMonth = endDateOfMonth.withHour( 23 ).withMinute( 59 ).withSecond( 59 );

            currentDataStartDate = endDateOfMonth.minusMonths( 8 );
            currentDataStartDate = currentDataStartDate
                    .withDayOfMonth( currentDataStartDate.getMonth().maxLength() )
                    .plusSeconds( 1 );
            endDate = DateUtils.converDateToString( currentDataStartDate.minusSeconds( 1 ) );
            startDate = DateUtils.converDateToStringwithTimeZero( currentDataStartDate.minusMonths( rollBackNumber ) );
            for ( int i = 0; i < rollBackNumber; i++ )
            {
                GroupSummary groupSummary = new GroupSummary();

                groupSummary.setTotal( i );
                int count = groupSummary.getTotal();

                for ( int k = 1; k < currentDataStartDate.getMonth().maxLength(); k++ )
                {
                    averageDataMap.put(
                            DateUtils.converDateToStringwithTimeZero( currentDataStartDate.minusDays( k ) ),

                            groupSummary );

                }

                currentDataStartDate = currentDataStartDate.minusMonths( 1 );

            }
            summary.setSubGroups( averageDataMap );
            break;
        case "weeks":

            ZonedDateTime endateDateOfWeek = ZonedDateTime.now();
            ZonedDateTime startDateOfAvarage;
            ZonedDateTime avarageEndDate;
            ZonedDateTime endateDate;
            ZonedDateTime rollbackDate;

            endateDate = endateDateOfWeek.with( DayOfWeek.SUNDAY ).withHour( 00 ).withMinute( 00 ).withSecond( 00 );

            endateDate = endateDate.minusWeeks( num );

            rollbackDate = endateDate.minusWeeks( rollBackNumber );
            for ( int i = 0; i < rollBackNumber; i++ )
            {

                GroupSummary groupSummary = new GroupSummary();

                groupSummary.setTotal( i );
                int count = groupSummary.getTotal();
                if ( count == i )
                {

                    for ( int j = 0; j < num - 1; j++ )
                    {

                        averageDataMap.put( DateUtils.converDateToString( rollbackDate.plusDays( j ) ), groupSummary );

                    }

                    rollbackDate = rollbackDate.plusDays( num - 1 );
                }

            }
            summary.setSubGroups( averageDataMap );

            currentDataEndDate = endateDateOfWeek
                    .with( DayOfWeek.SUNDAY )
                    .withHour( 23 )
                    .withMinute( 59 )
                    .withSecond( 59 );
            currentDataStartDate = currentDataEndDate
                    .minusWeeks( 8 )
                    .plusDays( 1 )
                    .withHour( 00 )
                    .withMinute( 00 )
                    .withSecond( 00 );

            endDate = DateUtils.converDateToStringwithTimeMax( currentDataStartDate.minusSeconds( 1 ) );
            startDate = DateUtils.converDateToStringwithTimeZero( currentDataStartDate.minusWeeks( rollBackNumber ) );

            break;

        default:
            break;
        }
        SummaryResponse response = new SummaryResponse();
        response.setSummary( summary );

        printSummayInJsonFormat( response );
        String query = "/v1/journeys/summary?q=created>="
                + startDate
                + " AND created<="
                + endDate
                + "&grouping=created";
        Client client = ClientBuilder.newClient();
        Response mockResponse = client
                .target( "http://" + HOST_NAME + ":" + PORT )
                .path( "/mock/responses" )
                .queryParam( "apiPath", query )
                .request()
                .put( Entity.entity( response, MediaType.APPLICATION_JSON ) );
        System.out.println( "Put Request Response" + mockResponse );

    }

    @Given( "^Average data of Journey Service for scheme \"(.*?)\" and last (\\d+) \"(.*?)\"$" )
    public void average_data_of_Journey_Service_for_scheme_and_last( String schemes, int num, String timeFilter )
            throws Throwable
    {
        ConfigurationFactory<DashBoardApiConfiguration> configurationFactory = new ConfigurationFactory(
                DashBoardApiConfiguration.class,
                Validation.buildDefaultValidatorFactory().getValidator(),
                Jackson.newObjectMapper(),
                "d" );
        InputStream in = this.getClass().getClassLoader().getResourceAsStream( "dashboard-internal-test.yml" );
        File tempFile = File.createTempFile( "dashboard-internal-test", "tmp" );
        tempFile.deleteOnExit();
        FileOutputStream out = new FileOutputStream( tempFile );
        IOUtils.copy( in, out );

        dashBoardApiConfiguration = configurationFactory.build( tempFile );

        GroupSummary summary = new GroupSummary();
        String endDate = "";
        String startDate = "";
        JsonNode graphConfig = dashBoardApiConfiguration.getJourneyRecordReceived();
        int rollBackNumber = graphConfig.get( "rollBackNumber" ).asInt();
        ;

        int rollbacknum = 5;
        ZonedDateTime currentDataEndDate;

        ZonedDateTime currentDataStartDate = null;
        ZonedDateTime averageDataEndDate = null;
        ZonedDateTime averageDataStartDate = null;
        ZonedDateTime currentDate = ZonedDateTime.now();
        Map<String, GroupSummary> averageDataMap = new HashMap<>();
        switch ( timeFilter )
        {
        case "days":

            currentDataEndDate = currentDate.withHour( 23 ).withMinute( 59 ).withSecond( 59 );
            currentDataStartDate = currentDataEndDate.minusDays( 8 ).plusSeconds( 1 );

            averageDataEndDate = currentDataStartDate.minusSeconds( 1 );
            averageDataStartDate = currentDataStartDate.minusDays( rollbacknum * 7 );
            // need to do bellow steps before loop, as value of averageDataEndDate keeps on changing
            endDate = DateUtils.converDateToString( averageDataEndDate );
            startDate = DateUtils.converDateToStringwithTimeZero( averageDataStartDate );

            for ( int i = 0; i < rollbacknum * 7; i++ )
            {
                GroupSummary groupSummary = new GroupSummary();
                groupSummary.setTotal( 1 );
                averageDataMap.put( DateUtils.converDateToStringwithTimeZero( averageDataEndDate ), groupSummary );

                averageDataEndDate = averageDataEndDate.minusDays( 1 );

            }
            summary.setSubGroups( averageDataMap );

            break;
        case "months":

            ZonedDateTime endDateOfMonth;

            endDateOfMonth = ZonedDateTime
                    .now()
                    .plusDays( ZonedDateTime.now().getMonth().maxLength() - currentDate.getDayOfMonth() );
            endDateOfMonth = endDateOfMonth.withHour( 23 ).withMinute( 59 ).withSecond( 59 );

            currentDataStartDate = endDateOfMonth.minusMonths( 8 );
            currentDataStartDate = currentDataStartDate
                    .withDayOfMonth( currentDataStartDate.getMonth().maxLength() )
                    .plusSeconds( 1 );
            endDate = DateUtils.converDateToString( currentDataStartDate.minusSeconds( 1 ) );
            startDate = DateUtils.converDateToStringwithTimeZero( currentDataStartDate.minusMonths( rollBackNumber ) );
            for ( int i = 0; i < rollBackNumber; i++ )
            {
                GroupSummary groupSummary = new GroupSummary();

                groupSummary.setTotal( i );
                int count = groupSummary.getTotal();

                for ( int k = 1; k < currentDataStartDate.getMonth().maxLength(); k++ )
                {
                    averageDataMap.put(
                            DateUtils.converDateToStringwithTimeZero( currentDataStartDate.minusDays( k ) ),

                            groupSummary );

                }

                currentDataStartDate = currentDataStartDate.minusMonths( 1 );

            }
            summary.setSubGroups( averageDataMap );
            break;
        case "weeks":

            ZonedDateTime endateDateOfWeek = ZonedDateTime.now();
            ZonedDateTime startDateOfAvarage;
            ZonedDateTime avarageEndDate;
            ZonedDateTime endateDate;
            ZonedDateTime rollbackDate;

            endateDate = endateDateOfWeek.with( DayOfWeek.SUNDAY ).withHour( 00 ).withMinute( 00 ).withSecond( 00 );

            endateDate = endateDate.minusWeeks( num );

            rollbackDate = endateDate.minusWeeks( rollBackNumber );
            for ( int i = 0; i < rollBackNumber; i++ )
            {

                GroupSummary groupSummary = new GroupSummary();

                groupSummary.setTotal( i );
                int count = groupSummary.getTotal();
                if ( count == i )
                {

                    for ( int j = 0; j < num - 1; j++ )
                    {

                        averageDataMap.put( DateUtils.converDateToString( rollbackDate.plusDays( j ) ), groupSummary );

                    }

                    rollbackDate = rollbackDate.plusDays( num - 1 );
                }

            }
            summary.setSubGroups( averageDataMap );

            currentDataEndDate = endateDateOfWeek
                    .with( DayOfWeek.SUNDAY )
                    .withHour( 23 )
                    .withMinute( 59 )
                    .withSecond( 59 );
            currentDataStartDate = currentDataEndDate
                    .minusWeeks( 8 )
                    .plusDays( 1 )
                    .withHour( 00 )
                    .withMinute( 00 )
                    .withSecond( 00 );

            endDate = DateUtils.converDateToStringwithTimeMax( currentDataStartDate.minusSeconds( 1 ) );
            startDate = DateUtils.converDateToStringwithTimeZero( currentDataStartDate.minusWeeks( rollBackNumber ) );

            break;

        default:
            break;
        }
        SummaryResponse response = new SummaryResponse();
        response.setSummary( summary );
        printSummayInJsonFormat( response );
        String query = "/v1/journeys/summary?q=created>="
                + startDate
                + " AND created<="
                + endDate
                + " AND "
                + schemes
                + "&grouping=created";

        Client client = ClientBuilder.newClient();
        Response mockResponse = client
                .target( "http://" + HOST_NAME + ":" + PORT )
                .path( "/mock/responses" )
                .queryParam( "apiPath", query )
                .request()
                .put( Entity.entity( response, MediaType.APPLICATION_JSON ) );
        System.out.println( "Put Request Response" + mockResponse );
    }

    public void printSummayInJsonFormat( SummaryResponse response )
    {
        ObjectMapper mapper = new ObjectMapper();
        try
        {
            System.out.println( "----##################################################################----" );
            System.out.println( mapper.writeValueAsString( response ) );
        }
        catch ( JsonProcessingException e )
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

}