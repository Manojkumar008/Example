/* **************************************************************************
 *             Copyright 2015 Applied Card Technologies Ltd
 *
 * What : CucumberIT
 * Who  : ACT-Fujitsu
 * When : 2016-01-19T03:20:00
 *
 * Source control
 *		$Revision: 1 $
 *		$Author: ACT-Fujitsu $
 *		$Date: 2016-01-19T03:20:00 $
 *
 ***************************************************************************/

package net.weareact;

import org.junit.ClassRule;
import org.junit.runner.RunWith;

import com.google.common.io.Resources;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import io.dropwizard.testing.junit.DropwizardAppRule;
import net.weareact.app.DashboardViewsApplication;
import net.weareact.app.DashboardViewsConfiguration;
import net.weareact.common.util.FileUtils;
import net.weareact.mock.rest.MockRestApplication;
import net.weareact.mock.rest.MockRestConfiguration;

/**
 * @author ACT-Fujitsu
 */
@RunWith( Cucumber.class )
@CucumberOptions(
format =
{ "pretty", "html:target/cucumber/cucumber-html-report", "json:target/cucumber/cucumber-html-report/cucumber.json" },
        features =
        { "src/test/resources/cucumber" }, tags = "~@cucumberIgnore" )
public class CucumberIT
{

    @ClassRule
    public static DropwizardAppRule<MockRestConfiguration>             dropwizardServiceRule = new DropwizardAppRule<>(
            MockRestApplication.class,
            Resources.getResource( "mockrest.yml" ).getPath() );
    @ClassRule
    public static final DropwizardAppRule<DashboardViewsConfiguration> RULE                  = new DropwizardAppRule<>(
            DashboardViewsApplication.class,
            FileUtils.getFullResourceFilePath( CucumberIT.class, "dashboardviews-test.yml" ) );
}
