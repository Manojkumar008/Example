package net.weareact.drilldown.stepdefs;

import java.util.Comparator;
import java.util.List;
import java.util.Map;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.weareact.app.mock.MockDistributionListService;
import net.weareact.dashboardview.model.DistributionList.TypeEnum;
import net.weareact.model.DashboardView;
import net.weareact.model.DashboardViewResponse;
import net.weareact.model.PointData;
import net.weareact.utils.DVSIntegrationUtil;
import net.weareact.utils.DVSIntegrationUtil.PointDataFromFeatureFile;

public class ActionListGenerationDrillDownGraphStepDef
{

    private Client                apiClient                 = ClientBuilder.newClient();
    private WebTarget             target;
    private Response              apiResponse;

    private static final String   API_HOST_NAME             = "localhost";
    private static final String   DASH_BOARD_VIEWS_API_PATH = "v1/dashboard-views";
    private static final String   JWT_ASSERTION_HEADER      = "X-JWT-Assertion";
    private static String         JWT_TOKEN_VALUE           = "eyJ0eXAiOiJKV1QiLCJ4NXQiOiJNbU15WW1GaVltRTNPV1U0TjJObE5tSmpNVEF4TVdFNE9UY3dNR0V6TnpZMVpHWTNOamN3TnciLCJhbGciOiJSUzI1NiJ9.eyJzY2hlbWVzIjpbeyJhYmJyZXZpYXRpb24iOiJBQ1QxIiwibGluayI6InNjaGVtZXMvMSJ9LHsiYWJicmV2aWF0aW9uIjoiQUNUMiIsImxpbmsiOiJzY2hlbWVzLzIifSx7ImFiYnJldmlhdGlvbiI6IkFDVDMiLCJsaW5rIjoic2NoZW1lcy8zIn0seyJhYmJyZXZpYXRpb24iOiJBQ1Q0IiwibGluayI6InNjaGVtZXMvNCJ9XSwic2NvcGVzIjpbXSwib3JnYW5pc2F0aW9uIjp7fSwiZXhwIjoiOTIyMzM3MjAzNjg1NDc3NTgwNyJ9.Y5w7egYWGuBpmzHEoaQpRw7fZOu1BK5MwfoH_rO0njXQx4OsMYZw7tWnB3vNRO2JKjgT__w9VgY49Mq_J1heuvGVVNgZDxzORWpZUeh2MuzmY1ME6IEhe9-2R1J3SWoj8hJrnjB_ypfNI9W4QNUSwUVoyfNx77boH20Y8akUr8M38vTwI7E5qTVZ_JRjnUIpDV-Bi3bADfNyLo9c_r-ywcsNpeoyTivsI_iIHWbuKl5U0JKtCWmYHmfR-oKR9rwW5AGtKr5i6ap5jJWFxIfre-ffp8DPxxy7NsRIzk6r214fEgNVJvq-QgPobgy-iI9sGt21MDFahBd-SaEBn_IbPg";

    private static Integer        apiHttpPort               = 18090;

    private DashboardViewResponse dashboardViewResponse;
    private DashboardView         dashboardView;

    private static final Logger   LOGGER                    = LoggerFactory
                                                                    .getLogger(
                                                                            ActionListGenerationDrillDownGraphStepDef.class
                                                                                    .getName() );

    @Given( "^DistributionList objects for  ActionListGeneration Drill Down Graph as:$" )
    public void distributionlist_objects_for_ActionListGeneration_Drill_Down_Graph_as( DataTable dataTable )
            throws Throwable
    {
        List<Map<String, String>> dataMapList = dataTable.asMaps( String.class, String.class );
        MockDistributionListService dlService = new MockDistributionListService();
        // dlService.createDLMockObjects_drillDown( dataMapList, TypeEnum.ACTIONLIST, "ACTIONLISTGENERATION" );
        dlService.createAndMockDistributionList(
                dataMapList,
                TypeEnum.ACTIONLIST,
                "ACTIONLISTGENERATION",
                "startDate>=2015-01-11T04:40:00Z AND endDate<=3016-01-19T04:40:00Z AND time=09:20:00",
                true,
                false,
                0L,
                0L,
                0L );
        LOGGER.info( "ServeReceivedGraphDataStepDefs >> Mock Objects Created ::::::::::" );

    }

    @Given( "^Dashboard Service is running$" )
    public void dashboard_Service_is_running() throws Throwable
    {
        LOGGER.info( "ActionListGenerationDrillDownGraphStepDef >> Dashboard Service is running ::::::::::" );

    }

    @Given( "^Scheme Service is running$" )
    public void scheme_Service_is_running() throws Throwable
    {
        // Write code here that turns the phrase above into concrete actions

    }

    @When( "^make a call for ActionListGeneration Drill Down Status graph with following properties :$" )
    public void make_a_call_for_ActionListGeneration_Drill_Down_Status_graph_with_following_properties(
            Map<String, String> dataMap ) throws Throwable
    {

        target = apiClient
                .target( "http://" + API_HOST_NAME + ":" + apiHttpPort + "/" + DASH_BOARD_VIEWS_API_PATH + "/" )
                .path( "ACTIONLIST_GENERATION_DRILLDOWN" )
                .queryParam(
                        "q",
                        "startDate>="
                                + dataMap.get( "startdate" )
                                + " AND endDate<="
                                + dataMap.get( "enddate" )
                                + " AND time="
                                + dataMap.get( "time" ) );
        apiResponse = target.request().header( JWT_ASSERTION_HEADER, JWT_TOKEN_VALUE ).get();
        dashboardViewResponse = apiResponse.readEntity( DashboardViewResponse.class );
        this.dashboardView = dashboardViewResponse.getDashboardView();

    }

    @Then( "^api response for drill down graph should be (\\d+)$" )
    public void api_response_for_drill_down_graph_should_be( int statusCode ) throws Throwable
    {
        Assert.assertEquals( statusCode, apiResponse.getStatus() );
    }

    @Then( "^List<GraphData> should be returned with following properties as:$" )
    public void list_GraghData_should_be_returned_with_following_properties_as(
            List<PointDataFromFeatureFile> listPointData ) throws Throwable
    {

        DVSIntegrationUtil dvsUtil = new DVSIntegrationUtil();
        List<PointData> expectedPointDataList = dvsUtil.prepareExpectedPointDataList( listPointData );

        Comparator.comparingInt( PointData::getPointValue );

        Assert.assertTrue(
                dvsUtil.comparePointDataObjects(
                        expectedPointDataList.get( 0 ),
                        dashboardView.getGraphData().get( 0 ).getDataPointValues().get( 0 ) ) );
        Assert.assertTrue(
                dvsUtil.comparePointDataObjects(
                        expectedPointDataList.get( 1 ),
                        dashboardView.getGraphData().get( 0 ).getDataPointValues().get( 1 ) ) );

        Assert.assertTrue(
                dvsUtil.comparePointDataObjects(
                        expectedPointDataList.get( 2 ),
                        dashboardView.getGraphData().get( 1 ).getDataPointValues().get( 0 ) ) );

        Assert.assertTrue(
                dvsUtil.comparePointDataObjects(
                        expectedPointDataList.get( 3 ),
                        dashboardView.getGraphData().get( 1 ).getDataPointValues().get( 1 ) ) );

        Assert.assertTrue(
                dvsUtil.comparePointDataObjects(
                        expectedPointDataList.get( 4 ),
                        dashboardView.getGraphData().get( 2 ).getDataPointValues().get( 7 ) ) );

        Assert.assertTrue(
                dvsUtil.comparePointDataObjects(
                        expectedPointDataList.get( 5 ),
                        dashboardView.getGraphData().get( 2 ).getDataPointValues().get( 8 ) ) );

    }

    // For Scheme filter

    @Given( "^DistributionList objects for  ActionListGeneration Drill Down with scheme filter Graph as:$" )
    public void distributionlist_objects_for_ActionListGeneration_Drill_Down_with_scheme_filter_Graph_as(
            DataTable dataTable ) throws Throwable
    {
        List<Map<String, String>> dataMapList = dataTable.asMaps( String.class, String.class );
        MockDistributionListService dlService = new MockDistributionListService();
        // dlService.createDLMockObjects_drillDown( dataMapList, TypeEnum.ACTIONLIST, "ACTIONLISTGENERATION" );
        dlService.createAndMockDistributionList(
                dataMapList,
                TypeEnum.ACTIONLIST,
                "ACTIONLISTGENERATIONDRILLDOWN",
                "startDate>=2015-01-11T04:40:00Z AND endDate<=3016-01-19T04:40:00Z AND time=09:20:00 AND scheme.link IN(/schemes/000e45cc-b9e0-11e5-9912-ba0be0483c11,/schemes/000e45cc-b9e0-11e5-9912-ba0be0483c12)",
                true,
                false,
                0L,
                0L,
                0L );
        LOGGER.info( "ServeReceivedGraphDataStepDefs >> Mock Objects Created ::::::::::" );
    }

    @When( "^make a call for ActionListGeneration Drill Down Status graph with scheme filter with following properties :$" )
    public void make_a_call_for_ActionListGeneration_Drill_Down_Status_graph_with_scheme_filter_with_following_properties(
            Map<String, String> dataMap ) throws Throwable
    {
        target = apiClient
                .target( "http://" + API_HOST_NAME + ":" + apiHttpPort + "/" + DASH_BOARD_VIEWS_API_PATH + "/" )
                .path( "ACTIONLIST_GENERATION_DRILLDOWN" )
                .queryParam(
                        "q",
                        "startDate>="
                                + dataMap.get( "startdate" )
                                + " AND endDate<="
                                + dataMap.get( "enddate" )
                                + " AND time="
                                + dataMap.get( "time" )
                                + " AND scheme.link IN("
                                + dataMap.get( "scheme1" )
                                + ","
                                + dataMap.get( "scheme2" )
                                + ")" );
        apiResponse = target.request().header( JWT_ASSERTION_HEADER, JWT_TOKEN_VALUE ).get();
        dashboardViewResponse = apiResponse.readEntity( DashboardViewResponse.class );
        this.dashboardView = dashboardViewResponse.getDashboardView();
    }

    @Then( "^List<GraphData> for ActionListGeneration Drill Down Graph with scheme filter should be returned with following properties as:$" )
    public void list_GraghData_for_ActionListGeneration_Drill_Down_Graph_with_scheme_filter_should_be_returned_with_following_properties_as(
            List<PointDataFromFeatureFile> listPointData ) throws Throwable
    {

        DVSIntegrationUtil dvsUtil = new DVSIntegrationUtil();
        List<PointData> expectedPointDataList = dvsUtil.prepareExpectedPointDataList( listPointData );

        Comparator.comparingInt( PointData::getPointValue );

        Assert.assertTrue(
                dvsUtil.comparePointDataObjects(
                        expectedPointDataList.get( 0 ),
                        dashboardView.getGraphData().get( 0 ).getDataPointValues().get( 0 ) ) );
        Assert.assertTrue(
                dvsUtil.comparePointDataObjects(
                        expectedPointDataList.get( 1 ),
                        dashboardView.getGraphData().get( 1 ).getDataPointValues().get( 0 ) ) );

        Assert.assertTrue(
                dvsUtil.comparePointDataObjects(
                        expectedPointDataList.get( 2 ),
                        dashboardView.getGraphData().get( 1 ).getDataPointValues().get( 1 ) ) );

        Assert.assertTrue(
                dvsUtil.comparePointDataObjects(
                        expectedPointDataList.get( 3 ),
                        dashboardView.getGraphData().get( 2 ).getDataPointValues().get( 2 ) ) );

        Assert.assertEquals( "ACTIONLIST_GENERATION_DRILLDOWN", dashboardView.getGraph() );
        Assert.assertEquals( "{en=Time}", dashboardView.getXAxisLabel().toString() );
        Assert.assertEquals( "{en=Number of Messages}", dashboardView.getYAxisLabel().toString() );
        Assert.assertEquals( "BAR", dashboardView.getGraphType().toString() );
        Assert.assertEquals(
                "{en=Unscheduled, es=no programada}",
                dashboardView.getGraphLegend().get( 0 ).getKey().toString() );

    }
}
