package net.weareact.stepdefs;

import static org.junit.Assert.assertEquals;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.weareact.CucumberIT;
import net.weareact.app.DashboardViewsConfiguration;
import net.weareact.app.mock.MockDistributionListService;
import net.weareact.common.dropwizard.DropwizardUtil;
import net.weareact.dashboardview.model.DistributionList.TypeEnum;
import net.weareact.model.DashboardView;
import net.weareact.model.DashboardViewsResponse;
import net.weareact.model.ServiceError;

public class Dashboard_ViewsEndpoint
{

    private static final Logger    LOGGER                    = LoggerFactory
                                                                     .getLogger(
                                                                             Dashboard_ViewsEndpoint.class
                                                                                     .getCanonicalName() );

    private static final String    API_HOST_NAME             = "localhost";
    private static final String    DASH_BOARD_VIEWS_API_PATH = "v1/dashboard-views";
    private static final String    JWT_ASSERTION_HEADER      = "X-JWT-Assertion";
    private static String          JWT_TOKEN_VALUE           = "eyJ0eXAiOiJKV1QiLCJ4NXQiOiJNbU15WW1GaVltRTNPV1U0TjJObE5tSmpNVEF4TVdFNE9UY3dNR0V6TnpZMVpHWTNOamN3TnciLCJhbGciOiJSUzI1NiJ9.eyJzY2hlbWVzIjpbeyJhYmJyZXZpYXRpb24iOiJBQ1QxIiwibGluayI6InNjaGVtZXMvMSJ9LHsiYWJicmV2aWF0aW9uIjoiQUNUMiIsImxpbmsiOiJzY2hlbWVzLzIifSx7ImFiYnJldmlhdGlvbiI6IkFDVDMiLCJsaW5rIjoic2NoZW1lcy8zIn0seyJhYmJyZXZpYXRpb24iOiJBQ1Q0IiwibGluayI6InNjaGVtZXMvNCJ9XSwic2NvcGVzIjpbXSwib3JnYW5pc2F0aW9uIjp7fSwiZXhwIjoiOTIyMzM3MjAzNjg1NDc3NTgwNyJ9.Y5w7egYWGuBpmzHEoaQpRw7fZOu1BK5MwfoH_rO0njXQx4OsMYZw7tWnB3vNRO2JKjgT__w9VgY49Mq_J1heuvGVVNgZDxzORWpZUeh2MuzmY1ME6IEhe9-2R1J3SWoj8hJrnjB_ypfNI9W4QNUSwUVoyfNx77boH20Y8akUr8M38vTwI7E5qTVZ_JRjnUIpDV-Bi3bADfNyLo9c_r-ywcsNpeoyTivsI_iIHWbuKl5U0JKtCWmYHmfR-oKR9rwW5AGtKr5i6ap5jJWFxIfre-ffp8DPxxy7NsRIzk6r214fEgNVJvq-QgPobgy-iI9sGt21MDFahBd-SaEBn_IbPg";

    private static Integer         apiHttpPort;
    private Client                 apiClient                 = ClientBuilder.newClient();
    private WebTarget              target;
    private Response               apiResponse;

    private DashboardViewsResponse dashboardViewsResponse;
    private List<DashboardView>    dashboardViews;
    private ServiceError           serviceError;
    MockDistributionListService    dlService                 = new MockDistributionListService();

    String                         dateStr                   = getCurrentDate();

    public Dashboard_ViewsEndpoint()
    {
        DashboardViewsConfiguration dashboardViewConfiguration = CucumberIT.RULE.getConfiguration();
        apiHttpPort = DropwizardUtil.getApplicationHttpPort( dashboardViewConfiguration );
        LOGGER.info( "Constructor Dashboard_ViewsEndpoint:: apiHttpPort - " + apiHttpPort );
    }

    @Given( "^that the DashboardView service is running$" )
    public void that_the_DashboardView_service_is_running() throws Throwable
    {
        LOGGER.info( "Dashboard service is running" );
    }

    @When( "^I make a bad request to the DashboardView service \"(.*?)\" endpoint with a \"(.*?)\" parameter$" )
    public void i_make_a_bad_request_to_the_DashboardView_service_endpoint_with_a_parameter(
            final String endpoint,
            final String q ) throws Throwable
    {

        // Make a request to the dashboard views service passing this as the q param value
        target = apiClient
                .target( "http://" + API_HOST_NAME + ":" + apiHttpPort + "/" + DASH_BOARD_VIEWS_API_PATH + "/" )
                .queryParam( "q", q );
        apiResponse = target.request().header( JWT_ASSERTION_HEADER, JWT_TOKEN_VALUE ).get();

        // failure scenario - expect a ServiceError
        this.serviceError = apiResponse.readEntity( ServiceError.class );

    }

    @Then( "^I should get a Bad Request response with status (\\d+)$" )
    public void i_should_get_a_Bad_Request_response_with_status( final int status ) throws Throwable
    {
        assertEquals( apiResponse.getStatus(), status );
    }

    @Then( "^the bad response should have the following data:$" )
    public void the_bad_response_should_have_the_following_data( final Map<String, String> dt ) throws Throwable
    {
        // failure scenario
        assertEquals( dt.get( "userMessage" ), serviceError.getUserMessage() );
    }

    @When( "^I make a request to the DashboardView service \"(.*?)\" endpoint with a \"(.*?)\" parameter$" )
    public void i_make_a_request_to_the_DashboardView_service_endpoint_with_a_parameter(
            final String endpoint,
            final String q ) throws Throwable
    {
        // Make a request to the dashboard views service passing this as the q param value
        target = apiClient
                .target( "http://" + API_HOST_NAME + ":" + apiHttpPort + "/" + DASH_BOARD_VIEWS_API_PATH + "/" )
                .queryParam( "q", q );
        apiResponse = target.request().header( JWT_ASSERTION_HEADER, JWT_TOKEN_VALUE ).get();

        // Get the Dashboard View response and store it
        this.dashboardViewsResponse = apiResponse.readEntity( DashboardViewsResponse.class );
        this.dashboardViews = dashboardViewsResponse.getDashboardViews();
    }

    @Then( "^I should get a \"(.*?)\" response with status (\\d+)$" )
    public void i_should_get_a_response_with_status( final String type, final int status ) throws Throwable
    {
        assertEquals( apiResponse.getStatus(), status );
        assertEquals( apiResponse.getStatusInfo().getReasonPhrase(), type );

    }

    @Then( "^the response should have the following data:$" )
    public void the_response_should_have_the_following_data( Map<String, String> dt ) throws Throwable
    {
        // System.out.println( dashboardViews );
        assertEquals( dashboardViews.size(), 2 );
        assertEquals( dashboardViews.get( 0 ).getGraph(), dt.get( "graph1" ) );
        assertEquals( dashboardViews.get( 1 ).getGraph(), dt.get( "graph2" ) );
        assertEquals( new Long( dt.get( "meta.totalCount" ) ), dashboardViewsResponse.getMeta().getTotalCount() );

    }

    @Given( "^that I mock Generated \"(.*?)\" objects for the graph \"(.*?)\" with the following properties:$" )
    public void that_I_mock_Generated_objects_for_the_graph_with_the_following_properties(
            final String type,
            final String graph,
            final List<Map<String, String>> dataMapList ) throws Throwable
    {
        LOGGER.info( "Creating test data for ACTIONLISTGENERATION graph" );
        // Replace time with current date + the time
        List<Map<String, String>> modifiedDataMapList = getModifiedList( dataMapList, "generationStartDateTime" );

        dlService.createAndMockDistributionList(
                modifiedDataMapList,
                TypeEnum.valueOf( type ),
                graph,
                null,
                true,
                false,
                0L,
                0L,
                0L );
    }

    @Given( "^that I mock Received \"(.*?)\" objects for the graph \"(.*?)\" with the following properties :$" )
    public void that_I_mock_Received_objects_for_the_graph_with_the_following_properties(
            final String type,
            final String graph,
            final List<Map<String, String>> dataMapList ) throws Throwable
    {
        LOGGER.info( "Creating test data for ACTIONLISTRECEIVED graph" );
        // Replace time with current date + the time
        List<Map<String, String>> modifiedDataMapList = getModifiedList( dataMapList, "receivedDateTime" );

        dlService.createAndMockReceivedDistributionList(
                modifiedDataMapList,
                net.weareact.dashboardview.model.ReceivedDistributionList.TypeEnum.valueOf( type ),
                graph,
                null,
                null,
                true,
                false,
                0L,
                0L,
                0L );
    }

    private List<Map<String, String>> getModifiedList(
            final List<Map<String, String>> dataMapList,
            final String string )
    {
        List<Map<String, String>> temp = new ArrayList<>();
        for ( Map<String, String> map : dataMapList ) // freaking map is a Collections.UnmodifiableMap
        {
            HashMap<String, String> dataMap = new HashMap<>();
            dataMap.putAll( map );
            String time = dataMap.get( string );
            dataMap.put( string, dateStr + time );
            temp.add( dataMap );
        }
        return temp;
    }

    private String getCurrentDate()
    {
        ZonedDateTime currentDate = ZonedDateTime.now();

        return currentDate.getYear()
                + "-"
                + ( String.valueOf( currentDate.getMonthValue() ).length() == 2
                        ? currentDate.getMonthValue()
                        : "0" + currentDate.getMonthValue() )
                + "-"
                + ( String.valueOf( currentDate.getDayOfMonth() ).length() == 2
                        ? currentDate.getDayOfMonth()
                        : "0" + currentDate.getDayOfMonth() );
    }

    @Given( "^that I also mock Generated \"(.*?)\" objects for the graph \"(.*?)\" at the endpoint \"(.*?)\" with the following properties:$" )
    public void that_I_also_mock_Generated_objects_for_the_graph_at_the_endpoint_with_the_following_properties(
            final String type,
            final String graph,
            final String endpoint,
            final List<Map<String, String>> dataMapList ) throws Throwable
    {
        LOGGER.info( "Creating test data for ACTIONLISTGENERATION graph" );
        // Replace time with current date + the time
        List<Map<String, String>> modifiedDataMapList = getModifiedList( dataMapList, "generationStartDateTime" );

        dlService.createAndMockDistributionList(
                modifiedDataMapList,
                TypeEnum.valueOf( type ),
                graph,
                endpoint,
                true,
                false,
                0L,
                0L,
                0L );
    }

    @Given( "^that I also mock Received \"(.*?)\" objects for the graph \"(.*?)\" at the endpoint \"(.*?)\" with the following properties :$" )
    public void that_I_also_mock_Received_objects_for_the_graph_at_the_endpoint_with_the_following_properties(
            final String type,
            final String graph,
            final String endpoint,
            final List<Map<String, String>> dataMapList ) throws Throwable
    {
        LOGGER.info( "Creating test data for ACTIONLISTRECEIVED graph" );
        // Replace time with current date + the time
        List<Map<String, String>> modifiedDataMapList = getModifiedList( dataMapList, "receivedDateTime" );

        dlService.createAndMockReceivedDistributionList(
                modifiedDataMapList,
                net.weareact.dashboardview.model.ReceivedDistributionList.TypeEnum.valueOf( type ),
                graph,
                endpoint,
                null,
                true,
                false,
                0L,
                0L,
                0L );
    }

    @Given( "^that I also mock Generated \"(.*?)\" objects for the graph \"(.*?)\" passing the query \"(.*?)\" with the following properties:$" )
    public void that_I_also_mock_Generated_objects_for_the_graph_passing_the_query_with_the_following_properties(
            final String type,
            final String graph,
            final String query,
            final List<Map<String, String>> dataMapList ) throws Throwable
    {
        LOGGER.info( "Creating test data for ACTIONLISTGENERATION graph" );
        // Replace time with current date + the time
        List<Map<String, String>> modifiedDataMapList = getModifiedList( dataMapList, "generationStartDateTime" );

        dlService.createAndMockDistributionList(
                modifiedDataMapList,
                TypeEnum.valueOf( type ),
                graph,
                query,
                false,
                false,
                0L,
                0L,
                0L );
    }

    @Given( "^that I also mock Received \"(.*?)\" objects for the graph \"(.*?)\" passing the query \"(.*?)\" with the following properties :$" )
    public void that_I_also_mock_Received_objects_for_the_graph_passing_the_query_with_the_following_properties(
            final String type,
            final String graph,
            final String query,
            final List<Map<String, String>> dataMapList ) throws Throwable
    {
        LOGGER.info( "Creating test data for ACTIONLISTRECEIVED graph" );
        // Replace time with current date + the time
        List<Map<String, String>> modifiedDataMapList = getModifiedList( dataMapList, "receivedDateTime" );

        dlService.createAndMockReceivedDistributionList(
                modifiedDataMapList,
                net.weareact.dashboardview.model.ReceivedDistributionList.TypeEnum.valueOf( type ),
                graph,
                query,
                null,
                false,
                false,
                0L,
                0L,
                0L );
    }

    @When( "^make  get request for dashboardAggregater$" )
    public void make_get_request_for_dashboardAggregater() throws Throwable
    {
        target = apiClient
                .target(
                        "http://"
                                + API_HOST_NAME
                                + ":"
                                + apiHttpPort
                                + "/"
                                + "v1/dashboard-aggregation/AGRREGATER_GRAPH" )
                .queryParam( "q", "sample Query" );
        apiResponse = target.request().header( JWT_ASSERTION_HEADER, JWT_TOKEN_VALUE ).get();
    }

    @Then( "^Response code should be (\\d+)$" )
    public void response_code_should_be( int statusCode ) throws Throwable
    {
        assertEquals( apiResponse.getStatus(), statusCode );
    }

}
