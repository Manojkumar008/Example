package net.weareact.hops.setdefs;

import java.security.KeyStore;
import java.util.List;
import java.util.Map;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.weareact.CucumberIT;
import net.weareact.app.DashboardViewsConfiguration;
import net.weareact.app.mock.MockHopsStatusService;
import net.weareact.common.dropwizard.DropwizardUtil;
import net.weareact.jwt.JKSKeyStoreProvider;
import net.weareact.jwt.JWTBuilder;
import net.weareact.jwt.JWTBuilderRSA;
import net.weareact.model.DashboardView;
import net.weareact.model.DashboardViewResponse;
import net.weareact.model.GraphDataPoint;
import net.weareact.utils.DVSIntegrationUtil;

public class ServeAllDataForHopsQueueMessageGraphStepDefs
{

    private static final Logger LOGGER                    = LoggerFactory
                                                                  .getLogger(
                                                                          ServeAllDataForHopsQueueMessageGraphStepDefs.class
                                                                                  .getName() );

    private static final String API_HOST_NAME             = "localhost";
    private static final String DASH_BOARD_VIEWS_API_PATH = "v1/dashboard-views";
    private static final String JWT_ASSERTION_HEADER      = "X-JWT-Assertion";
    private static final String KEYSTORE_PATH             = "src/test/resources/keystore/actdev.jks";

    private static final String KEYSTORE_PASSWORD         = "actdev";

    private static final String KEYSTORE_ALIAS            = "wso2am.local";

    private static final Object JWT_TOKEN_VALUE           = "eyJ0eXAiOiJKV1QiLCJ4NXQiOiJNbU15WW1GaVltRTNPV1U0TjJObE5tSmpNVEF4TVdFNE9UY3dNR0V6TnpZMVpHWTNOamN3TnciLCJhbGciOiJSUzI1NiJ9.eyJzY2hlbWVzIjpbeyJhYmJyZXZpYXRpb24iOiJBQ1QxIiwibGluayI6InNjaGVtZXMvMSJ9LHsiYWJicmV2aWF0aW9uIjoiQUNUMiIsImxpbmsiOiJzY2hlbWVzLzIifSx7ImFiYnJldmlhdGlvbiI6IkFDVDMiLCJsaW5rIjoic2NoZW1lcy8zIn0seyJhYmJyZXZpYXRpb24iOiJBQ1Q0IiwibGluayI6InNjaGVtZXMvNCJ9XSwic2NvcGVzIjpbXSwib3JnYW5pc2F0aW9uIjp7fSwiZXhwIjoiOTIyMzM3MjAzNjg1NDc3NTgwNyJ9.Y5w7egYWGuBpmzHEoaQpRw7fZOu1BK5MwfoH_rO0njXQx4OsMYZw7tWnB3vNRO2JKjgT__w9VgY49Mq_J1heuvGVVNgZDxzORWpZUeh2MuzmY1ME6IEhe9-2R1J3SWoj8hJrnjB_ypfNI9W4QNUSwUVoyfNx77boH20Y8akUr8M38vTwI7E5qTVZ_JRjnUIpDV-Bi3bADfNyLo9c_r-ywcsNpeoyTivsI_iIHWbuKl5U0JKtCWmYHmfR-oKR9rwW5AGtKr5i6ap5jJWFxIfre-ffp8DPxxy7NsRIzk6r214fEgNVJvq-QgPobgy-iI9sGt21MDFahBd-SaEBn_IbPg";
    private Response            apiResponse;

    @Given( "^dashboardviews-service is up and running$" )
    public void dashboardviews_service_is_up_and_running() throws Throwable
    {
        // Write code here that turns the phrase above into concrete actions
        // throw new PendingException();
    }

    @Given( "^hops-status-service is up and runing with following data$" )
    public void hops_status_service_is_up_and_runing_with_following_data( DataTable arg1 ) throws Throwable
    {
        List<Map<String, String>> dataMapList = arg1.asMaps( String.class, String.class );

        new MockHopsStatusService().mockHopsStatuses( dataMapList, null );

    }

    @Given( "^User has access to following schemes$" )
    public void user_has_access_to_following_schemes( DataTable arg1 ) throws Throwable
    {
        final List<Map<String, String>> data = arg1.asMaps( String.class, String.class );
        final KeyStore keyStore = new JKSKeyStoreProvider().getKeyStore( KEYSTORE_PATH, KEYSTORE_PASSWORD );
        JWTBuilder builder = new JWTBuilderRSA( keyStore, KEYSTORE_PASSWORD, KEYSTORE_ALIAS );
        for ( Map<String, String> row : data )
        {
            builder = builder.addProperty(
                    row.get( "name" ),
                    row.get( "value" ),
                    Boolean.parseBoolean( row.get( "array" ) ),
                    Boolean.parseBoolean( row.get( "json" ) ) );

        }
        String jwtToken = builder.build();
        LOGGER.info( " JWT Token Prepared >> Value is - " + jwtToken );

        /*
         * MockJWT mockJWT = new MockJWT(); mockJWT.setupJwt( jwtToken );
         */
    }

    @When( "^I request data for \"(.*?)\" graph$" )
    public void i_request_data_for_graph( String graphID ) throws Throwable
    {

        apiResponse = callDashBoardService( graphID, null );
        Thread.sleep( 1000 );

    }

    @Then( "^Response contains following data$" )
    public void response_contains_following_data( String arg1 ) throws Throwable
    {
        Assert.assertTrue( apiResponse.getStatus() == 200 );
        DashboardViewResponse response = apiResponse.readEntity( DashboardViewResponse.class );
        DashboardView dashboardView = response.getDashboardView();

        GraphDataPoint graphDataPoint = dashboardView.getGraphData().get( 0 );

        JSONArray jsonArray = new JSONArray( arg1 );

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure( DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false );
        for ( int i = 0; i < jsonArray.length(); i++ )
        {
            GraphDataPoint graphDataPointExpected = mapper
                    .readValue( jsonArray.getJSONObject( i ).toString(), GraphDataPoint.class );

            Assert.assertTrue(
                    new DVSIntegrationUtil()
                            .comparePointDataList( graphDataPointExpected, dashboardView.getGraphData().get( i ) ) );
        }

        /*
         * Assert.assertTrue( new DVSIntegrationUtil().comparePointDataList( graphDataPonitList.get( 0 ), graphDataPoint
         * ) );
         */
        // Assert.assertTrue(
        // new DVSIntegrationUtil().comparePointDataList( graphDataPonitList.get( 1 ), graphDataPoint ) );

    }

    @Given( "^hops-status-service provides following data for average calculation for hops \"(.*?)\"$" )
    public void hops_status_service_provides_following_data_for_average_calculation_for_hops(
            String hopsName,
            DataTable data ) throws Throwable
    {
        List<Map<String, String>> dataMapList = data.asMaps( String.class, String.class );

        new MockHopsStatusService().mockHopsStatusesForAverage( dataMapList, hopsName );

    }

    private Response callDashBoardService( String graphID, String queryParam )
    {
        DashboardViewsConfiguration configuration = CucumberIT.RULE.getConfiguration();

        int apiHttpPort = DropwizardUtil.getApplicationHttpPort( configuration );

        Client apiClient = ClientBuilder.newClient();
        WebTarget target = apiClient.target(
                "http://" + API_HOST_NAME + ":" + apiHttpPort + "/" + DASH_BOARD_VIEWS_API_PATH + "/" + graphID );
        if ( queryParam != null )
        {
            target = target.queryParam( "q", queryParam );
        }
        apiResponse = target.request().header( JWT_ASSERTION_HEADER, JWT_TOKEN_VALUE ).get();
        return apiResponse;
    }

    @When( "^user requests for  \"(.*?)\" graph for schemes \"(.*?)\" and \"(.*?)\"$" )
    public void callHopsStatusesServiceByApplyingSchemeFilter( String graphName, String scheme1, String scheme2 )
            throws Throwable
    {

        apiResponse = callDashBoardService( graphName, "scheme.link IN(" + scheme1 + "," + scheme2 + ")" );
        Thread.sleep( 1000 );
    }

    @When( "^user requests for  \"(.*?)\" graph between time \"(.*?)\" and \"(.*?)\"$" )
    public void callHopsStatusesServiceByAppyingTimeperiodFitler( String graphName, String startDate, String endDate )
            throws InterruptedException
    {
        apiResponse = callDashBoardService( graphName, "startDate>=" + startDate + " AND endDate<=" + endDate );
        Thread.sleep( 1000 );
    }

    @When( "^user requests for  \"(.*?)\" graph with schemes \"(.*?)\" and \"(.*?)\" for timeperiod \"(.*?)\" and \"(.*?)\"$" )
    public void callHopsStatusesServiceByAppyingTimeAndSchemeFitler(
            String graphName,
            String scheme1,
            String scheme2,
            String startDate,
            String endDate ) throws Throwable
    {
        apiResponse = callDashBoardService(
                graphName,
                "startDate>="
                        + startDate
                        + " AND endDate<="
                        + endDate
                        + " AND scheme.link IN("
                        + scheme1
                        + ","
                        + scheme2
                        + ")" );
        Thread.sleep( 1000 );
    }

    @Given( "^hops-status-service is up and runing with data for single hops$" )
    public void seutHOPSDataForSingleHops( DataTable arg1 ) throws Throwable
    {
        List<Map<String, String>> dataMapList = arg1.asMaps( String.class, String.class );

        new MockHopsStatusService().mockHopsStatuses( dataMapList, "scheme.link IN(schemes/1,schemes/2)" );
    }

    @Given( "^hops-status-service is up and runing with data for multiple hops$" )
    public void seutHOPSDataForMultipleHops( DataTable arg1 ) throws Throwable
    {
        List<Map<String, String>> dataMapList = arg1.asMaps( String.class, String.class );

        new MockHopsStatusService().mockHopsStatuses( dataMapList, "scheme.link IN(schemes/5,schemes/1)" );
    }

    @Given( "^hops-status-service is up and runing with data for specific timeperiod$" )
    public void setupHopsDataforTimePeroidFilter( DataTable arg1 ) throws Throwable
    {
        List<Map<String, String>> dataMapList = arg1.asMaps( String.class, String.class );

        new MockHopsStatusService()
                .mockHopsStatuses( dataMapList, "startDate>=2016-01-12T01:00:00Z AND endDate<=2016-01-14T01:00:00Z" );
    }

    @Given( "^hops-status-service is up and runing with data for specific time$" )
    public void seutHOPSDataForSpecificTimeFilter( DataTable arg1 ) throws Throwable
    {
        List<Map<String, String>> dataMapList = arg1.asMaps( String.class, String.class );

        new MockHopsStatusService().mockHopsStatuses(
                dataMapList,
                "startDate>=2016-01-12T01:00:00Z AND endDate<=2016-01-14T01:00:00Z AND time=03:00:00" );
    }

    @Given( "^hops-status-service is up and runing with scheme and timeperiod data$" )
    public void seutHOPSDataForTimePeriodAndSchemeFilter( DataTable arg1 ) throws Throwable
    {
        List<Map<String, String>> dataMapList = arg1.asMaps( String.class, String.class );

        new MockHopsStatusService().mockHopsStatuses(
                dataMapList,
                "startDate>=2016-01-12T01:00:00Z AND endDate<=2016-01-14T01:00:00Z AND scheme.link IN(schemes/1,schemes/4)" );
    }

}
