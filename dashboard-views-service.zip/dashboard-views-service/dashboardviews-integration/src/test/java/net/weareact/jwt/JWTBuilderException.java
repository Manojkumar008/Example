/**
 * Copyright 2015 Applied Card Technologies Ltd
 */
package net.weareact.jwt;

public class JWTBuilderException extends Exception
{
    public JWTBuilderException( final Throwable cause )
    {
        super( cause );
    }
}
