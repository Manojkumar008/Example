package net.weareact.stepdefs;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import net.weareact.app.mock.MockDistributionListService;
import net.weareact.dashboardview.model.DistributionList.TypeEnum;

public class ServeFilteredDataForHotLitGenerationStepDefs
{

    private static final Logger LOGGER    = LoggerFactory
                                                  .getLogger(
                                                          ServeFilteredDataForHotLitGenerationStepDefs.class
                                                                  .getCanonicalName() );

    MockDistributionListService dlService = new MockDistributionListService();

    @Given( "^that I mock Generated \"(.*?)\" objects at the endpoint \"(.*?)\" with the following properties :$" )
    public void that_I_mock_Generated_objects_at_the_endpoint_with_the_following_properties(
            String type,
            String query,
            DataTable table ) throws Throwable
    {
        LOGGER.info( "Creating test data for " + query );
        List<Map<String, String>> dataMapList = table.asMaps( String.class, String.class );

        // dlService.mockAndPutALData( q, dataMapList );

        dlService.createAndMockDistributionList(
                dataMapList,
                TypeEnum.valueOf( type ),
                "HOTLISTGENERATION",
                query,
                true,
                false,
                0L,
                0L,
                0L );

    }

}
