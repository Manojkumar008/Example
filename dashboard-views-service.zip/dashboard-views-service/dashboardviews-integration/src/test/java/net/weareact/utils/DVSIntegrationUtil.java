package net.weareact.utils;

import java.security.KeyStore;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;

import cucumber.api.DataTable;
import net.weareact.jwt.JKSKeyStoreProvider;
import net.weareact.jwt.JWTBuilder;
import net.weareact.jwt.JWTBuilderRSA;
import net.weareact.model.GraphDataPoint;
import net.weareact.model.PointData;

public class DVSIntegrationUtil
{

    private static final String KEYSTORE_PATH     = "src/test/resources/keystore/actdev.jks";

    private static final String KEYSTORE_PASSWORD = "actdev";

    private static final String KEYSTORE_ALIAS    = "wso2am.local";

    private String              JWT_TOKEN_VALUE   = "eyJ0eXAiOiJKV1QiLCJ4NXQiOiJNbU15WW1GaVltRTNPV1U0TjJObE5tSmpNVEF4TVdFNE9UY3dNR0V6TnpZMVpHWTNOamN3TnciLCJhbGciOiJSUzI1NiJ9.eyJzY2hlbWVzIjpbeyJhYmJyZXZpYXRpb24iOiJBQ1QxIiwibGluayI6InNjaGVtZXMvMSJ9LHsiYWJicmV2aWF0aW9uIjoiQUNUMiIsImxpbmsiOiJzY2hlbWVzLzIifSx7ImFiYnJldmlhdGlvbiI6IkFDVDMiLCJsaW5rIjoic2NoZW1lcy8zIn0seyJhYmJyZXZpYXRpb24iOiJBQ1Q0IiwibGluayI6InNjaGVtZXMvNCJ9XSwic2NvcGVzIjpbXSwib3JnYW5pc2F0aW9uIjp7fSwiZXhwIjoiOTIyMzM3MjAzNjg1NDc3NTgwNyJ9.Y5w7egYWGuBpmzHEoaQpRw7fZOu1BK5MwfoH_rO0njXQx4OsMYZw7tWnB3vNRO2JKjgT__w9VgY49Mq_J1heuvGVVNgZDxzORWpZUeh2MuzmY1ME6IEhe9-2R1J3SWoj8hJrnjB_ypfNI9W4QNUSwUVoyfNx77boH20Y8akUr8M38vTwI7E5qTVZ_JRjnUIpDV-Bi3bADfNyLo9c_r-ywcsNpeoyTivsI_iIHWbuKl5U0JKtCWmYHmfR-oKR9rwW5AGtKr5i6ap5jJWFxIfre-ffp8DPxxy7NsRIzk6r214fEgNVJvq-QgPobgy-iI9sGt21MDFahBd-SaEBn_IbPg";

    public List<PointData> prepareExpectedPointDataList( final List<PointDataFromFeatureFile> listPointData )
    {

        List<PointData> expectedPointDataList = new ArrayList<>();

        for ( PointDataFromFeatureFile mappedDomainObj : listPointData )
        {

            Map<String, String> legandMap = convertJSONToMap( mappedDomainObj.pointLegend );
            Map<String, String> keyMap = convertDateTimeStrToMap( mappedDomainObj.pointKey );

            PointData dataObj = new PointData();

            dataObj.setPointKey( keyMap );
            dataObj.setPointValue( mappedDomainObj.pointValue );
            dataObj.setPointLegend( legandMap );

            expectedPointDataList.add( dataObj );

        }
        return expectedPointDataList;
    }

    public Map<String, String> convertJSONToMap( final String jSONString )
    {

        Map<String, String> map = new HashMap<>();
        JSONObject jObject = new JSONObject( jSONString );
        Iterator<?> keys = jObject.keys();

        while ( keys.hasNext() )
        {
            String key = ( String ) keys.next();
            String value = jObject.getString( key );
            map.put( key, value );
        }
        return map;
    }

    public Map<String, String> convertDateTimeStrToMap( String dateTimejSONString )
    {

        dateTimejSONString = dateTimejSONString.replace( "{", "" );
        dateTimejSONString = dateTimejSONString.replace( "}", "" );

        Map<String, String> dateTimeMap = new HashMap<>();

        if ( dateTimejSONString.indexOf( "," ) != -1 )
        {
            String[] commaSplittedStrArray = dateTimejSONString.split( "," );

            for ( String entry : commaSplittedStrArray )
            {

                String[] dateTimeWithLocaleStr = entry.split( ":", 2 );

                dateTimeMap.put( dateTimeWithLocaleStr[ 0 ], dateTimeWithLocaleStr[ 1 ] );

            }
        }
        else
        {
            String[] dateTimeWithLocaleStr = dateTimejSONString.split( ":", 2 );

            dateTimeMap.put( dateTimeWithLocaleStr[ 0 ], dateTimeWithLocaleStr[ 1 ] );
        }

        return dateTimeMap;
    }

    public class PointDataFromFeatureFile
    {
        public String  pointKey;
        public Integer pointValue;
        public String  pointLegend;
    }

    public boolean comparePointDataObjects( final PointData expectedPointData, final PointData actualPointData )
    {

        int valueFlag = expectedPointData.getPointValue().compareTo( actualPointData.getPointValue() );
        boolean keyFlag = expectedPointData.getPointKey().entrySet().equals( actualPointData.getPointKey().entrySet() );
        boolean legendFlag = expectedPointData
                .getPointLegend()
                .entrySet()
                .equals( actualPointData.getPointLegend().entrySet() );

        if ( keyFlag && legendFlag && valueFlag == 0 )
        {
            return true;
        }

        return false;
    }

    public boolean comparePointDataList(
            final GraphDataPoint graphDataPointExpected,
            final GraphDataPoint graphDataPointActual )
    {

        List<PointData> expectedPointDataValues = graphDataPointExpected.getDataPointValues();
        List<PointData> actualPointDataValues = graphDataPointActual.getDataPointValues();

        /*
         * // sort lists by pontValue Collections.sort( expectedPointDataValues, new PointDataComparator() );
         * Collections.sort( actualPointDataValues, new PointDataComparator() );
         */

        Collections.sort( expectedPointDataValues, new PointDataComparatorForHops() );
        Collections.sort( actualPointDataValues, new PointDataComparatorForHops() );

        boolean returnValue = true;

        if ( expectedPointDataValues.size() != actualPointDataValues.size() )
        {
            returnValue = false;
        }
        else
        {
            for ( int i = 0; i < expectedPointDataValues.size(); i++ )
            {

                if ( !comparePointDataObjects( expectedPointDataValues.get( i ), actualPointDataValues.get( i ) ) )
                {
                    returnValue = false;
                    break;
                }
            }
        }

        return returnValue;
    }

    private class PointDataComparatorForHops implements Comparator<PointData>
    {

        @Override
        public int compare( final PointData o1, final PointData o2 )
        {
            Integer expectedPointValue = o1.getPointValue();
            Integer actualPointValue = o2.getPointValue();
            return expectedPointValue.compareTo( actualPointValue );

        }

    }

    private class PointDataComparator implements Comparator<PointData>
    {

        @Override
        public int compare( final PointData o1, final PointData o2 )
        {
            Map<String, String> expectedPointKeyLegend = o1.getPointLegend();
            Map<String, String> actualPointKeyLegend = o2.getPointLegend();

            String expectedLegendValue = expectedPointKeyLegend.get( "en" );
            String actualLegendValue = actualPointKeyLegend.get( "en" );

            return expectedLegendValue.compareTo( actualLegendValue );

        }

    }

    public void prepareJWT( DataTable arg1 ) throws Throwable
    {
        final List<Map<String, String>> data = arg1.asMaps( String.class, String.class );
        final KeyStore keyStore = new JKSKeyStoreProvider().getKeyStore( KEYSTORE_PATH, KEYSTORE_PASSWORD );
        JWTBuilder builder = new JWTBuilderRSA( keyStore, KEYSTORE_PASSWORD, KEYSTORE_ALIAS );
        for ( Map<String, String> row : data )
        {
            builder = builder.addProperty(
                    row.get( "name" ),
                    row.get( "value" ),
                    Boolean.parseBoolean( row.get( "array" ) ),
                    Boolean.parseBoolean( row.get( "json" ) ) );

        }
        JWT_TOKEN_VALUE = builder.build();
    }

    public String getJWT_TOKEN_VALUE()
    {
        return JWT_TOKEN_VALUE;
    }

    public void setJWT_TOKEN_VALUE( String jWT_TOKEN_VALUE )
    {
        JWT_TOKEN_VALUE = jWT_TOKEN_VALUE;
    }

}
