/**
 * Copyright 2015 Applied Card Technologies Ltd
 */
package net.weareact;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;

/**
 * @author tripatat
 */
public class CucumberBeforeAfter
{
    private static final Logger LOGGER = LoggerFactory.getLogger( CucumberBeforeAfter.class.getName() );
    private Scenario            currentScenario;

    /**
     * C'tor.
     */
    public CucumberBeforeAfter()
    {
    }

    /**
     * Run before each test.
     *
     * @param theCurrentScenario
     *            The scenario about to be run.
     * @throws Exception
     *             If something goes wrong
     */
    @Before
    public void setup( final Scenario theCurrentScenario ) throws Exception
    {
        currentScenario = theCurrentScenario;
        LOGGER.info( ">>> Running Scenario: " + theCurrentScenario.getName() );
    }

    /**
     * Tear down after the test run.
     *
     * @param result
     *            The scenario which just completed
     * @throws Exception
     *             If something goes wrong.
     */
    @After
    public void tearDown( final Scenario result ) throws Exception
    {

    }

    /**
     * Returns the currently executing scenario (may be null).
     *
     * @return the currently executing scenario
     */
    protected Scenario getCurrentScenario()
    {
        return currentScenario;
    }
}
