/*
 * ************************************************************************** Copyright 2016 Applied Card Technologies
 * Ltd
 ****************************************************************************/

package net.weareact.stepdefs;

import static org.junit.Assert.assertEquals;

import java.security.KeyStore;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.weareact.CucumberIT;
import net.weareact.app.DashboardViewsConfiguration;
import net.weareact.app.mock.MockDistributionListService;
import net.weareact.common.dropwizard.DropwizardUtil;
import net.weareact.dashboardview.model.ReceivedDistributionList.TypeEnum;
import net.weareact.jwt.JKSKeyStoreProvider;
import net.weareact.jwt.JWTBuilder;
import net.weareact.jwt.JWTBuilderRSA;
import net.weareact.model.DashboardView;
import net.weareact.model.DashboardViewResponse;
import net.weareact.model.PointData;
import net.weareact.utils.DVSIntegrationUtil;
import net.weareact.utils.DVSIntegrationUtil.PointDataFromFeatureFile;

public class ServeHotlistReceivedGraphDataStepDefs
{

    private static final Logger   LOGGER                    = LoggerFactory
                                                                    .getLogger(
                                                                            ServeHotlistReceivedGraphDataStepDefs.class
                                                                                    .getName() );

    private static final String   KEYSTORE_PATH             = "src/test/resources/keystore/actdev.jks";

    private static final String   KEYSTORE_PASSWORD         = "actdev";

    private static final String   KEYSTORE_ALIAS            = "wso2am.local";

    private static final String   API_HOST_NAME             = "localhost";
    private static final String   DASH_BOARD_VIEWS_API_PATH = "v1/dashboard-views";
    private static final String   JWT_ASSERTION_HEADER      = "X-JWT-Assertion";
    private static String         JWT_TOKEN_VALUE           = "";

    private static Integer        apiHttpPort;
    private Client                apiClient                 = ClientBuilder.newClient();
    private WebTarget             target;
    private Response              apiResponse;
    private DashboardViewResponse dashboardViewResponse;
    private DashboardView         dashboardView;
    MockDistributionListService   dlService                 = new MockDistributionListService();

    public ServeHotlistReceivedGraphDataStepDefs()
    {
        DashboardViewsConfiguration dashboardViewConfiguration = CucumberIT.RULE.getConfiguration();
        apiHttpPort = DropwizardUtil.getApplicationHttpPort( dashboardViewConfiguration );
        LOGGER.info( "Constructor ServeHotlistReceivedGraphDataStepDefs:: apiHttpPort - " + apiHttpPort );
    }

    @Given( "^that I mock Received HotList objects with following properties:$" )
    public void that_I_mock_Received_HotList_objects_with_following_properties( DataTable table ) throws Throwable
    {
        LOGGER.info(
                "Serve Hotlist Received Graph Data Step Defs >> Mock Received HotList Objects at Default Endpoint :::::" );
        List<Map<String, String>> dataMapList = table.asMaps( String.class, String.class );

        dlService.createAndMockReceivedDistributionList(
                dataMapList,
                TypeEnum.HOTLIST,
                "HOTLISTRECEIVED",
                null,
                null,
                true,
                false,
                0L,
                0L,
                0L );
    }

    @Given( "^that I mock Received HotList objects at the endpoint \"(.*?)\" with following properties:$" )
    public void that_I_mock_Received_HotList_objects_at_the_endpoint_with_following_properties(
            String q,
            DataTable table ) throws Throwable
    {

        LOGGER.info(
                "Serve Hotlist Received Graph Data Step Defs >> Mock Received HotList Objects at Endpoint >>" + q );
        List<Map<String, String>> dataMapList = table.asMaps( String.class, String.class );

        dlService.createAndMockReceivedDistributionList(
                dataMapList,
                TypeEnum.HOTLIST,
                "HOTLISTRECEIVED",
                q,
                null,
                true,
                false,
                0L,
                0L,
                0L );
    }

    @Given( "^prepare jwt token with following schemes data:$" )
    public void prepare_jwt_token_with_following_schemes_data( DataTable arg1 ) throws Throwable
    {
        final List<Map<String, String>> data = arg1.asMaps( String.class, String.class );
        final KeyStore keyStore = new JKSKeyStoreProvider().getKeyStore( KEYSTORE_PATH, KEYSTORE_PASSWORD );
        JWTBuilder builder = new JWTBuilderRSA( keyStore, KEYSTORE_PASSWORD, KEYSTORE_ALIAS );
        for ( Map<String, String> row : data )
        {
            builder = builder.addProperty(
                    row.get( "name" ),
                    row.get( "value" ),
                    Boolean.parseBoolean( row.get( "array" ) ),
                    Boolean.parseBoolean( row.get( "json" ) ) );

        }
        JWT_TOKEN_VALUE = builder.build();
        LOGGER.info( "Serve Hotlist Received Graph Data Step Defs >> JWT Token Prepared :::::" );
    }

    @Given( "^that the Distribution List mock service is running with above test data stored$" )
    public void that_the_Distribution_List_mock_service_is_running_with_above_test_data_stored() throws Throwable
    {
        LOGGER.info( "Serve Hotlist Received Graph Data Step Defs >> DL Mock Service is running :::::" );
    }

    @Given( "^the Dashboard View service is running$" )
    public void the_Dashboard_View_service_is_running() throws Throwable
    {
        LOGGER.info( "Serve Hotlist Received Graph Data Step Defs >> Dashboard Service is running :::::" );
    }

    @When( "^I make a request to the Dashboard View service for the graph \"(.*?)\":$" )
    public void i_make_a_request_to_the_Dashboard_View_service_for_the_graph( String graphName ) throws Throwable
    {

        LOGGER.info(
                "Serve Hotlist Received Graph Data Step Defs >> Dashboard Service hit using Graph ID as >> "
                        + graphName );
        // Make a request to the dashboard views service passing this as the q param value
        target = apiClient
                .target( "http://" + API_HOST_NAME + ":" + apiHttpPort + "/" + DASH_BOARD_VIEWS_API_PATH + "/" )
                .path( graphName );
        apiResponse = target.request().header( JWT_ASSERTION_HEADER, JWT_TOKEN_VALUE ).get();

        LOGGER.info(
                "Serve Hotlist Received Graph Data Step Defs >> Dashboard Service hit using Graph ID as >> "
                        + graphName
                        + " Response Status is ::::: "
                        + apiResponse.getStatus() );

        // Get the Dashboard View response and store it
        dashboardViewResponse = apiResponse.readEntity( DashboardViewResponse.class );
        this.dashboardView = dashboardViewResponse.getDashboardView();
    }

    @When( "^I make a request to the Dashboard View service for the graph \"(.*?)\" and filter on the following schemes:$" )
    public void i_make_a_request_to_the_Dashboard_View_service_for_the_graph_and_filter_on_the_following_schemes(
            String graphName,
            List<String> dataTable ) throws Throwable
    {
        // data table has scheme filter values. Create a scheme query
        String q = "scheme.link IN(" + StringUtils.join( dataTable, "," ) + ")";

        LOGGER.info(
                "Serve Hotlist Received Graph Data Step Defs >> Dashboard Service hit using Graph ID as >>"
                        + graphName
                        + " and q param as >> "
                        + q );

        // Make a request to the dashboard views service passing this as the q param value
        target = apiClient
                .target( "http://" + API_HOST_NAME + ":" + apiHttpPort + "/" + DASH_BOARD_VIEWS_API_PATH + "/" )
                .path( graphName )
                .queryParam( "q", q );
        apiResponse = target.request().header( JWT_ASSERTION_HEADER, JWT_TOKEN_VALUE ).get();

        LOGGER.info(
                "Serve Hotlist Received Graph Data Step Defs >> Dashboard Service hit using Graph ID as >> "
                        + graphName
                        + " Response Status is ::::: "
                        + apiResponse.getStatus() );

        // Get the Dashboard View response and store it
        dashboardViewResponse = apiResponse.readEntity( DashboardViewResponse.class );
        this.dashboardView = dashboardViewResponse.getDashboardView();
    }

    @When( "^I make a request to the Dashboard View service for the graph \"(.*?)\" and filter by <startdate> and <enddate>$" )
    public void i_make_a_request_to_the_Dashboard_View_service_for_the_graph_and_filter_by_startdate_and_enddate(
            String graphName,
            Map<String, String> dataTable ) throws Throwable
    {
        // The data Table has start and end date times now. Make a time query
        String q = "startDate >=" + dataTable.get( "startdate" ) + " AND endDate <=" + dataTable.get( "enddate" );

        LOGGER.info(
                "Serve Hotlist Received Graph Data Step Defs >> Dashboard Service hit using Graph ID as >>"
                        + graphName
                        + " and q param as >> "
                        + q );

        // Make a request to the dashboard views service passing this as the q param value
        target = apiClient
                .target( "http://" + API_HOST_NAME + ":" + apiHttpPort + "/" + DASH_BOARD_VIEWS_API_PATH + "/" )
                .path( graphName )
                .queryParam( "q", q );

        // GET the Dashboard View response and store it
        apiResponse = target.request().header( JWT_ASSERTION_HEADER, JWT_TOKEN_VALUE ).get();

        LOGGER.info(
                "Serve Hotlist Received Graph Data Step Defs >> Dashboard Service hit using Graph ID as >> "
                        + graphName
                        + " Response Status is ::::: "
                        + apiResponse.getStatus() );

        dashboardViewResponse = apiResponse.readEntity( DashboardViewResponse.class );
        this.dashboardView = dashboardViewResponse.getDashboardView();
    }

    @When( "^I make a request to the Dashboard View service for the graph \"(.*?)\" and filter by the following <scheme> and by <startdate> and <enddate>$" )
    public void i_make_a_request_to_the_Dashboard_View_service_for_the_graph_and_filter_by_the_following_scheme_and_by_startdate_and_enddate(
            String graphName,
            Map<String, String> dataTable ) throws Throwable
    {
        // The data Table has scheme, start and end date times now. Make a full query query
        String q = "scheme.link IN("
                + dataTable.get( "scheme" )
                + ")"
                + " AND startDate >="
                + dataTable.get( "startdate" )
                + " AND endDate <="
                + dataTable.get( "enddate" );
        ;

        LOGGER.info(
                "Serve Hotlist Received Graph Data Step Defs >> Dashboard Service hit using Graph ID as >>"
                        + graphName
                        + " and q param as >> "
                        + q );
        // Make a request to the dashboard views service passing this as the q param value

        target = apiClient
                .target( "http://" + API_HOST_NAME + ":" + apiHttpPort + "/" + DASH_BOARD_VIEWS_API_PATH + "/" )
                .path( graphName )
                .queryParam( "q", q );

        // GET the Dashboard View response and store it
        apiResponse = target.request().header( JWT_ASSERTION_HEADER, JWT_TOKEN_VALUE ).get();

        LOGGER.info(
                "Serve Hotlist Received Graph Data Step Defs >> Dashboard Service hit using Graph ID as >> "
                        + graphName
                        + " Response Status is ::::: "
                        + apiResponse.getStatus() );

        dashboardViewResponse = apiResponse.readEntity( DashboardViewResponse.class );
        this.dashboardView = dashboardViewResponse.getDashboardView();
    }

    @Then( "^I should get successful response with (\\d+) values$" )
    public void i_should_get_successful_response_with_values( int expectedSize ) throws Throwable
    {
        assertEquals( expectedSize, dashboardView.getGraphData().get( 0 ).getDataPointValues().size() );
        LOGGER.info( "Serve Hotlist Received Graph Data Step Defs >> Size Assertion Done :::::" );
    }

    @Then( "^the response should have data with following values:$" )
    public void the_response_should_have_data_with_following_values( List<PointDataFromFeatureFile> listPointData )
            throws Throwable
    {
        List<PointData> expectedPointDataList = new DVSIntegrationUtil().prepareExpectedPointDataList( listPointData );

        List<PointData> actualPointValueList = dashboardView.getGraphData().get( 0 ).getDataPointValues();

        for ( int i = 0; i < expectedPointDataList.size(); i++ )
        {
            PointData expectedOutput = expectedPointDataList.get( i );
            PointData actualOutput = actualPointValueList.get( i );

            assertEquals( expectedOutput.getPointValue(), actualOutput.getPointValue() );

            Assert.assertTrue( Objects.equals( expectedOutput.getPointKey(), actualOutput.getPointKey() ) );
            Assert.assertTrue( Objects.equals( expectedOutput.getPointLegend(), actualOutput.getPointLegend() ) );
        }
        LOGGER.info( "Serve Hotlist Received Graph Data Step Defs >> Data Values Assertion Done :::::" );
    }
}
