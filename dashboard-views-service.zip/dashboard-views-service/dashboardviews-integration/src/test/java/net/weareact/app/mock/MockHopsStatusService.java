package net.weareact.app.mock;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeoutException;

import javax.validation.Validation;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.JsonNode;

import io.dropwizard.configuration.ConfigurationException;
import io.dropwizard.configuration.ConfigurationFactory;
import io.dropwizard.jackson.Jackson;
import net.weareact.api.impl.config.DashBoardApiConfiguration;
import net.weareact.api.impl.utils.DashboardViewsImplQueryUtil;
import net.weareact.common.data.exception.DataStoreException;
import net.weareact.hopsstatus.model.HopsStatus;
import net.weareact.hopsstatus.model.HopsStatusesResponse;
import net.weareact.hopsstatus.model.MessageQueueContent;
import net.weareact.hopsstatus.model.MessageTypeTotal;
import net.weareact.hopsstatus.model.SchemeLink;

public class MockHopsStatusService
{

    private static final Logger       LOGGER    = LoggerFactory.getLogger( MockHopsStatusService.class.getName() );

    private static final Integer      PORT      = 18080;
    private static final String       HOST_NAME = "localhost";
    private static List<HopsStatus>   hopsStatuses;

    private DashBoardApiConfiguration dashBoardApiConfiguration;

    public MockHopsStatusService()
    {
        try
        {
            ConfigurationFactory<DashBoardApiConfiguration> configurationFactory = new ConfigurationFactory<>(
                    DashBoardApiConfiguration.class,
                    Validation.buildDefaultValidatorFactory().getValidator(),
                    Jackson.newObjectMapper(),
                    "d" );
            InputStream in = this.getClass().getClassLoader().getResourceAsStream( "dashboard-internal-test.yml" );
            File tempFile = File.createTempFile( "dashboard-internal-test", "tmp" );
            tempFile.deleteOnExit();
            FileOutputStream out = new FileOutputStream( tempFile );
            IOUtils.copy( in, out );

            this.dashBoardApiConfiguration = configurationFactory.build( tempFile );
        }
        catch ( IOException | ConfigurationException ex )
        {
            LOGGER.error( "MockDistributionListService::Exception in building configuration - " + ex.getMessage() );
        }
    }

    public void mockHopsStatuses( final List<Map<String, String>> dataMapList, final String qu )
    {

        try
        {
            hopsStatuses = createTestData( dataMapList );
            HopsStatusesResponse response = new HopsStatusesResponse();
            response.setHopsStatuses( hopsStatuses );
            /*
             * response.setHopsStatuses( hopsStatuses );
             *
             * Paging meta = new Paging(); meta.setLimit( 100L ); meta.setOffset( 0L ); meta.setTotalCount( 1L );
             * response.setMeta( meta );
             */

            String q = DashboardViewsImplQueryUtil
                    .buildQueryForProductQueuedMessages( dashBoardApiConfiguration.getHopsQueuedMessages(), qu );

            String query = "/v1/hops-statuses?q=" + q;
            Client client = ClientBuilder.newClient();
            Response mockResponse = client
                    .target( "http://" + HOST_NAME + ":" + PORT )
                    .path( "/mock/responses" )
                    .queryParam( "apiPath", query )
                    // .queryParam( "offset", 0 )
                    .request()
                    .put( Entity.entity( response, MediaType.APPLICATION_JSON ) );
            System.out.println( "Put Request Response" + mockResponse );
        }
        catch ( IOException | TimeoutException | DataStoreException e )
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    private static List<HopsStatus> createTestData( final List<Map<String, String>> dataMapList )
            throws IOException,
            TimeoutException,
            DataStoreException
    {
        List<HopsStatus> hopsStatusList = new ArrayList<>();
        try
        {
            // Post HopsStatus objects with given data
            /*
             * HopsStatus contains List<SchemeLink> and MessageQueueContent Object. MessageQueueContent contains
             * List<MessageTypeTotal>
             */
            if ( !dataMapList.isEmpty() )
            {
                int count = 0;
                for ( Map<String, String> dataMapAtEachListIndex : dataMapList )
                {
                    String hopsStatusName = dataMapAtEachListIndex.get( "name" );
                    String hopsDateTimeAsStr = dataMapAtEachListIndex.get( "date_time" );

                    // comma separated scheme_links
                    String schemeLink = dataMapAtEachListIndex.get( "scheme_links" ).trim();
                    List<String> schemeLinkList = Arrays.asList( schemeLink.split( "," ) );

                    // comma separated scheme_abbreviations
                    String schemeAbbreviation = dataMapAtEachListIndex.get( "scheme_abbreviations" ).trim();
                    List<String> schemeAbbreviationList = Arrays.asList( schemeAbbreviation.split( "," ) );

                    String msgTotalQueueSize = dataMapAtEachListIndex.get( "msg_total_queue_size" );

                    // comma separated msg_type_codes
                    String msgTypeCode = dataMapAtEachListIndex.get( "msg_type_codes" );
                    List<String> msgTypeCodeList = Arrays.asList( msgTypeCode.split( "," ) );

                    // comma separated msg_type_names
                    String msgTypeName = dataMapAtEachListIndex.get( "msg_type_names" );
                    List<String> msgTypeNameList = Arrays.asList( msgTypeName.split( "," ) );

                    // comma separated msg_type_totals
                    String msgTypeTotalNumber = dataMapAtEachListIndex.get( "msg_type_totals" );
                    List<String> msgTypeTotalNumberList = Arrays.asList( msgTypeTotalNumber.split( "," ) );

                    // Parse Date Time
                    ZonedDateTime hopsDateTime = ZonedDateTime.parse( hopsDateTimeAsStr );
                    if ( !dataMapAtEachListIndex.isEmpty() )
                    {

                        HopsStatus hopsStatusObj = new HopsStatus();

                        hopsStatusObj.setId( ( count + 1 ) + "_Hops_Status_Id_" + Math.random() );

                        hopsStatusObj.setName( hopsStatusName );
                        hopsStatusObj.setDateTime( hopsDateTime );

                        // Set List Of Schemes
                        List<SchemeLink> tempSchemeList = new ArrayList<>();

                        for ( int i = 0; i < schemeLinkList.size(); i++ )
                        {
                            SchemeLink scheme = new SchemeLink();
                            scheme.setLink( schemeLinkList.get( i ) );
                            scheme.setAbbreviation( schemeAbbreviationList.get( i ) );
                            tempSchemeList.add( scheme );
                        }
                        hopsStatusObj.setSchemes( tempSchemeList );

                        // Build MessageQueueContent Object containing List<MessageTypeTotal>
                        MessageQueueContent msgQueueContent = new MessageQueueContent();
                        msgQueueContent.setTotalSize( Integer.valueOf( msgTotalQueueSize ) );

                        // Set List Of MessageTypeTotal in MessageQueueContent

                        List<MessageTypeTotal> tempMessageTypeTotalList = new ArrayList<>();

                        // msgTypeCodeList
                        for ( int i = 0; i < msgTypeCodeList.size(); i++ )
                        {
                            MessageTypeTotal msgTypeTotalObj = new MessageTypeTotal();

                            msgTypeTotalObj.setMessageCode( msgTypeCodeList.get( i ) );
                            msgTypeTotalObj.setMessageName( msgTypeNameList.get( i ) );
                            msgTypeTotalObj.setTotal( Integer.valueOf( msgTypeTotalNumberList.get( i ) ) );

                            tempMessageTypeTotalList.add( msgTypeTotalObj );
                        }

                        msgQueueContent.setMessageTotals( tempMessageTypeTotalList );

                        hopsStatusObj.setMessageQueueContent( msgQueueContent );
                        hopsStatusList.add( hopsStatusObj );
                        count++;
                    }
                }

            }

        }
        catch ( Exception e )
        {
            LOGGER.error( "Error occured while creating test data for hops status service : " + e.getMessage() );
            e.printStackTrace();
        }

        return hopsStatusList;

    }

    public void mockHopsStatusesForAverage( final List<Map<String, String>> dataMapList, final String hopsName )
    {
        List<HopsStatus> hopsStatusesForAverage;
        try
        {
            hopsStatusesForAverage = createTestData( dataMapList );
            HopsStatusesResponse response = new HopsStatusesResponse();
            response.setHopsStatuses( hopsStatusesForAverage );

            ZonedDateTime earliestDate = hopsStatuses.get( hopsStatuses.size() - 1 ).getDateTime();

            JsonNode graphConfig = dashBoardApiConfiguration.getHopsQueuedMessages();
            // build query to fetch rollBackNumber records for average calculation
            final int rollBackNumber;
            JsonNode rollBackNode = graphConfig.get( "rollBackNumber" );
            if ( rollBackNode.get( hopsName ) != null )
            {
                rollBackNumber = rollBackNode.get( hopsName ).asInt();
            }
            else
            {
                rollBackNumber = rollBackNode.get( "default" ).asInt();
            }

            String q = DashboardViewsImplQueryUtil.buildQueryToFetchDataForAvergaeLineCalculation(
                    graphConfig,
                    hopsName,
                    earliestDate,
                    // rollBackNumber,
                    "hopsNameParameterName" );

            int limit = rollBackNumber - 1;
            String apipath = "/v1/hops-statuses?limit=" + limit + "&q=" + q;
            Client client = ClientBuilder.newClient();
            Response mockResponse = client
                    .target( "http://" + HOST_NAME + ":" + PORT )
                    .path( "/mock/responses" )
                    .queryParam( "apiPath", apipath )
                    // .queryParam( q, values )
                    // .queryParam( "limit", rollBackNumber - 1 )
                    // .queryParam( "offset", 0 )
                    .request()
                    .put( Entity.entity( response, MediaType.APPLICATION_JSON ) );
            System.out.println( "Put Request Response" + mockResponse );
        }
        catch ( IOException | TimeoutException | DataStoreException e )
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

}
