/**
 * Copyright 2015 Applied Card Technologies Ltd
 */
package net.weareact.app;

import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;

import io.dropwizard.setup.Environment;
import net.weareact.auditservice.client.AuditException;
import net.weareact.auditservice.client.AuditService;

/**
 *
 * @author dstorey
 */
public class ITDashboardViewsApplication extends DashboardViewsApplication
{
    /**
     * Instances an AuditService that logs JSON-serialised audit records.
     *
     * @param configuration
     * @return
     */
    @Override
    AuditService getAuditService( final DashboardViewsConfiguration configuration, final Environment environment )
    {
        return auditRecord ->
        {
            try
            {
                LoggerFactory.getLogger( AuditService.class ).info(
                        environment.getObjectMapper().writeValueAsString( auditRecord ) );
            }
            catch ( JsonProcessingException ex )
            {
                throw new AuditException( ex );
            }
        };
    }

}
