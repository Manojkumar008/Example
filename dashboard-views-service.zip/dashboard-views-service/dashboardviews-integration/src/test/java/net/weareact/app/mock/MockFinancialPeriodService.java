package net.weareact.app.mock;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Validation;
import javax.ws.rs.core.Response;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.dropwizard.configuration.ConfigurationException;
import io.dropwizard.configuration.ConfigurationFactory;
import io.dropwizard.jackson.Jackson;
import net.weareact.api.impl.config.DashBoardApiConfiguration;
import net.weareact.financial.model.FinancialPeriod;
import net.weareact.financial.model.FinancialPeriodsResponse;
import net.weareact.financial.model.Notification;
import net.weareact.financial.model.Notification.TypeEnum;
import net.weareact.financial.model.Paging;

public class MockFinancialPeriodService
{
    private static final Logger       LOGGER                     = LoggerFactory
            .getLogger( MockFinancialPeriodService.class.getName() );
    private MockService               financialPeriodMockService = new MockService();
    private DashBoardApiConfiguration dashBoardApiConfiguration;

    public MockFinancialPeriodService()
    {

        try
        {
            ConfigurationFactory<DashBoardApiConfiguration> configurationFactory = new ConfigurationFactory<>(
                    DashBoardApiConfiguration.class,
                    Validation.buildDefaultValidatorFactory().getValidator(),
                    Jackson.newObjectMapper(),
                    "d" );
            InputStream in = this.getClass().getClassLoader().getResourceAsStream( "dashboard-internal-test.yml" );
            File tempFile = File.createTempFile( "dashboard-internal-test", "tmp" );
            tempFile.deleteOnExit();
            FileOutputStream out = new FileOutputStream( tempFile );
            IOUtils.copy( in, out );

            this.dashBoardApiConfiguration = configurationFactory.build( tempFile );
        }
        catch ( IOException | ConfigurationException ex )
        {
            LOGGER.error( "MockDistributionListService::Exception in building configuration - " + ex.getMessage() );
        }

    }

    public void createMockDataForFinancialPeriod(
            List<FinancialPeriod> listOfFinancialPeriod,
            String query,
            String financialPeriodBasePath,
            String applicationContextPath )
    {
        try
        {
            FinancialPeriodsResponse fpResponse = new FinancialPeriodsResponse();
            Paging meta = new Paging();
            meta.setLimit( 0L );
            meta.setOffset( 0L );
            meta.setTotalCount( 0L );
            meta.offset( 1L );
            fpResponse.setMeta( meta );
            fpResponse.setMeta( meta );
            List<Notification> listOfNotification = new ArrayList<>();
            Notification notification = new Notification();
            notification.setId( "Mock_" + Math.random() );
            notification.setSubject( "Group Summary" );
            notification.setPayload( null );
            notification.setType( TypeEnum.message );
            listOfNotification.add( notification );

            fpResponse.setNotifications( listOfNotification );

            fpResponse.setFinancialPeriods( listOfFinancialPeriod );

            Response mockPostResponse = financialPeriodMockService
                    .mockPostFinancialPeriod( fpResponse, query, financialPeriodBasePath, applicationContextPath );
            LOGGER.info( "mockPostResponse: " + mockPostResponse );

        }
        catch (

        Exception e )

        {
            LOGGER.error( "Exception occured while mocking Financial Period objects" + e.getMessage() );
        }

    }

}
