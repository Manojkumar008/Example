/**
 * Copyright 2015 Applied Card Technologies Ltd
 */
package net.weareact.stepdefs;

import static net.weareact.CucumberIT.RULE;
import static org.junit.Assert.assertEquals;

import java.security.KeyStore;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.Response;

import org.json.JSONObject;
import org.junit.Assert;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.weareact.jwt.JKSKeyStoreProvider;
import net.weareact.jwt.JWTBuilder;
import net.weareact.jwt.JWTBuilderRSA;
import net.weareact.model.DashboardView;
import net.weareact.utils.HTTPUtils;

/**
 * @author tripatat
 */
public class DashboardViewsStepDefs
{
    // CHECKSTYLE:OFF - CS does not deal well with Cucumber

    private KeyStore           keyStore;

    private Response           response;

    private boolean            isSchemes;

    /*
     * private JsonNode workingEntity; private JsonNode responseEntity; private Map<String,Object> previousRequest;
     * private String workingCorrelationId;
     */

    private final List<String> createdResourceIds = new ArrayList<>();

    @Before
    public void setUp() throws Throwable
    {
        ObjectMapper mapper = new ObjectMapper();
        final JsonNode json = mapper.readTree( mapper.writeValueAsString( new DashboardView() ) );

        isSchemes = json.has( "schemes" );

        keyStore = new JKSKeyStoreProvider().getKeyStore(
                RULE.getConfiguration().getJwtConfiguration().getKeyStorePath(),
                RULE.getConfiguration().getJwtConfiguration().getKeyStorePassword() );
    }

    @After
    public void tearDown() throws Throwable
    {
        final JWTBuilder builder = new JWTBuilderRSA(
                keyStore,
                RULE.getConfiguration().getJwtConfiguration().getKeyStorePassword(),
                "wso2am.local" );
        builder.addProperty( "scopes", "dashboard-views_delete", true, false );
        builder.addProperty( "exp", "9223372036854775807", false, false );

        final String jwt = builder.build();

        createdResourceIds.stream().forEach(
                resourceId -> HTTPUtils
                        .connect( "DELETE", RULE.getLocalPort(), "/dashboard-views/" + resourceId, jwt ) );
    }

    @When( "^I make an admin \"(.*?)\" request to \"(.*?)\"$" )
    public void i_make_an_admin_request( final String requestMethod, final String url ) throws Throwable
    {
        response = HTTPUtils.connect( requestMethod, RULE.getAdminPort(), url, null );
    }

    @Then( "^the response status should be (\\d+)$" )
    public void the_response_should_be( final int expectedHttpResponseCode ) throws Throwable
    {
        assertEquals( expectedHttpResponseCode, response.getStatus() );
    }

    @Then( "^the service \"(.*?)\" should report \"(.*?)\"$" )
    public void the_service_should_report( String serviceName, String status ) throws Throwable
    {
        JSONObject json = new JSONObject( response.readEntity( String.class ) );

        JSONObject serviceObj = json.getJSONObject( serviceName );

        Assert.assertTrue( serviceObj.getBoolean( status ) );
    }

    /*
     * @When( "^I make a \"(.*?)\" request to \"(.*?)\" using jwt \"(.*?)\"$" ) public void the_client_makes_a_request(
     * final String requestMethod, final String url, final String jwt ) throws Throwable { response = HTTPUtils.connect(
     * requestMethod, RULE.getLocalPort(), url, jwt ); }
     * 
     * @When( "^I make a \"(.*?)\" request to \"(.*?)\" with a jwt with the following properties:$" ) public void
     * i_make_a_request_to_with_a_jwt_using_as_a_secret_and_with_the_following_properties( final String requestMethod,
     * final String url, final DataTable properties ) throws Throwable { final List<Map<String, String>> data =
     * properties.asMaps( String.class, String.class );
     * 
     * final KeyStore keyStore = new JKSKeyStoreProvider().getKeyStore(
     * RULE.getConfiguration().getJwtConfiguration().getKeyStorePath(),
     * RULE.getConfiguration().getJwtConfiguration().getKeyStorePassword() ); JWTBuilder builder = new JWTBuilderRSA(
     * keyStore, RULE.getConfiguration().getJwtConfiguration().getKeyStorePassword(), "act-microservice-it" );
     * 
     * for( Map< String, String > row : data ) { String value = row.get( "value" );
     * 
     * if(value.startsWith( "@now + " )) { String plus = value.replace( "@now + ", "" );
     * 
     * value = String.valueOf((System.currentTimeMillis()/1000) + (Long.valueOf( plus ))); }
     * 
     * builder = builder.addProperty( row.get( "name"), value, Boolean.parseBoolean( row.get( "array" ) ),
     * Boolean.parseBoolean( row.get( "json" ) ) );
     * 
     * 
     * }
     * 
     * String jwt = builder.build();
     * 
     * previousRequest = new HashMap<>(); previousRequest.put( "requestMethod", requestMethod ); previousRequest.put(
     * "url", url ); previousRequest.put( "jwt", jwt ); previousRequest.put( "workingEntity", workingEntity );
     * 
     * response = HTTPUtils.connect( requestMethod, RULE.getLocalPort(), url, workingEntity, MediaType.APPLICATION_JSON,
     * jwt );
     * 
     * if ( response.getStatus() == Status.CREATED.getStatusCode() ) { final String resourceLocation =
     * response.getHeaderString( "Location" );
     * 
     * createdResourceIds.add( resourceLocation.contains( "/" ) ? resourceLocation.substring(
     * resourceLocation.lastIndexOf( "/" ) + 1 ) : resourceLocation ); } }
     * 
     * @When(
     * "^I make a \"(.*?)\" request with a correlation-id of \"(.*?)\" to \"(.*?)\" with a jwt with the following properties:$"
     * ) public void
     * i_make_a_request_to_with_a_correlation_id_of_with_jwt_using_as_a_secret_and_with_the_following_properties( final
     * String requestMethod, final String correlationId, final String url, final DataTable properties ) throws Throwable
     * { final List<Map<String, String>> data = properties.asMaps( String.class, String.class );
     * 
     * final KeyStore keyStore = new JKSKeyStoreProvider().getKeyStore(
     * RULE.getConfiguration().getJwtConfiguration().getKeyStorePath(),
     * RULE.getConfiguration().getJwtConfiguration().getKeyStorePassword() ); JWTBuilder builder = new JWTBuilderRSA(
     * keyStore, RULE.getConfiguration().getJwtConfiguration().getKeyStorePassword(), "act-microservice-it" );
     * 
     * for ( Map<String, String> row : data ) { String value = row.get( "value" );
     * 
     * if ( value.startsWith( "@now + " ) ) { String plus = value.replace( "@now + ", "" );
     * 
     * value = String.valueOf( ( System.currentTimeMillis() / 1000 ) + ( Long.valueOf( plus ) ) ); }
     * 
     * builder = builder.addProperty( row.get( "name" ), value, Boolean.parseBoolean( row.get( "array" ) ),
     * Boolean.parseBoolean( row.get( "json" ) ) );
     * 
     * }
     * 
     * String jwt = builder.build();
     * 
     * previousRequest = new HashMap<>(); previousRequest.put( "requestMethod", requestMethod ); previousRequest.put(
     * "url", url ); previousRequest.put( "jwt", jwt ); previousRequest.put( "workingEntity", workingEntity );
     * 
     * response = HTTPUtils.connect( requestMethod, RULE.getLocalPort(), url, workingEntity, MediaType.APPLICATION_JSON,
     * jwt, Maps.immutableEntry( "correlation-id", correlationId ) );
     * 
     * workingCorrelationId = correlationId;
     * 
     * if ( response.getStatus() == Status.CREATED.getStatusCode() ) { final String resourceLocation =
     * response.getHeaderString( "Location" );
     * 
     * createdResourceIds.add( resourceLocation.contains( "/" ) ? resourceLocation.substring(
     * resourceLocation.lastIndexOf( "/" ) + 1 ) : resourceLocation ); } }
     * 
     * @Then( "^the \"(.*?)\" header exists in the response$" ) public void the_something_header_exists_in_the_response(
     * final String header ) { assertTrue( response.getHeaders().containsKey( header ) ); }
     * 
     * @Then( "^the \"(.*?)\" header should be \"(.*?)\"$" ) public void the_something_header_should_be_something( final
     * String header, final String value ) { assertTrue( response.getHeaders().get( header ).get( 0 ).equals( value ) );
     * }
     * 
     * @Then( "^the \"(.*?)\" header begins with \"(.*?)\"$" ) public void the_something_header_begins_with_something(
     * final String header, final String character ) { assertTrue( ( ( String ) response.getHeaders().get( header ).get(
     * 0 ) ).startsWith( character ) ); }
     * 
     * @Given( "^I have an? \"(.*?)\"$" ) public void i_have_a( final String entityType ) throws Throwable {
     * i_have_a_with_the_following_properties( entityType, null ); }
     * 
     * @Given( "^I have an? \"(.*?)\" with the following properties:$" ) public void
     * i_have_a_with_the_following_properties( final String entityType, final DataTable entityProperties ) throws
     * Throwable { final EntityBuilder entityBuilder = new EntityBuilder();
     * 
     * entityBuilder.setPackageName( "net.weareact" ); entityBuilder.setClassName( entityType ); if ( entityProperties
     * != null ) { entityProperties.asMap( String.class, String.class ).forEach( entityBuilder::addProperty ); }
     * 
     * workingEntity = entityBuilder.build(); }
     * 
     * @Given( "^I have an? \"(.*?)\" with the following schemes:$" ) public void i_have_a_with_the_following_schemes(
     * final String entityType, final DataTable entityProperties ) throws Throwable { final EntityBuilder entityBuilder
     * = new EntityBuilder(); final List<SchemeLink> schemeLinks = new ArrayList<>();
     * 
     * entityBuilder.setPackageName( "net.weareact" ); entityBuilder.setClassName( entityType );
     * 
     * if ( entityProperties != null ) { if(isSchemes == true) { entityProperties.asList( String.class ).forEach( link
     * -> schemeLinks.add( new SchemeLink().link( link ) ) ); entityBuilder.addProperty("schemes",schemeLinks); } else {
     * entityBuilder.addProperty("scheme",new SchemeLink().link( entityProperties.asList( String.class ).get(0) )); } }
     * 
     * workingEntity = entityBuilder.build(); }
     * 
     * @Then( "^I deserialise the response entity$" ) public void i_deserialise_the_response_entity() throws Throwable {
     * responseEntity = response.readEntity( JsonNode.class ); }
     * 
     * @Then( "^the response entity should contain the following data:$" ) public void
     * the_response_entity_should_contain_the_following_data( final DataTable entityProperties ) throws Throwable {
     * entityProperties.asMap( String.class, String.class ).forEach( (fieldPath, expectedValue) -> { try { final Object
     * value = JsonPath.parse( RULE.getEnvironment().getObjectMapper().writeValueAsString( responseEntity ) ).read(
     * fieldPath );
     * 
     * assertEquals( expectedValue, value.toString() ); } catch ( final JsonProcessingException ex ) { throw new
     * RuntimeException( ex ); } } ); }
     * 
     * @Then( "^I wait for (\\d+) seconds$" ) public void i_wait_for_seconds( final int seconds ) throws Throwable {
     * Thread.sleep( seconds * 1000L ); }
     * 
     * @Then( "^I set the working entity to be the response entity \"(.*?)\" property$" ) public void
     * i_set_the_working_entity_to_be_the_response_entity_property( final String fieldPath ) throws Throwable { final
     * Configuration configuration = Configuration.builder() .jsonProvider( new JacksonJsonNodeJsonProvider() )
     * .mappingProvider( new JacksonMappingProvider() ) .build();
     * 
     * workingEntity = JsonPath.using( configuration ).parse( responseEntity ).read( fieldPath ); }
     * 
     * @Then( "^I set the following properties:$" ) public void i_set_the_following_properties( final DataTable
     * properties ) throws Throwable { final Configuration configuration = Configuration.builder() .jsonProvider( new
     * JacksonJsonNodeJsonProvider() ) .mappingProvider( new JacksonMappingProvider() ) .build();
     * 
     * properties.asMap( String.class, String.class ).forEach( (fieldPath, value) -> { workingEntity = JsonPath.using(
     * configuration ) .parse( workingEntity ) .set( fieldPath, value ).json(); } ); }
     * 
     * @When(
     * "^I make a \"(.*?)\" request to \"(.*?)\" using the \"(.*?)\" value of the working entity, with a jwt with the following properties:$"
     * ) public void i_make_a_request_to_using_the_value_of_the_working_entity_with_a_jwt_with_the_following_properties(
     * final String requestMethod, final String url, final String idFieldPath, final DataTable properties ) throws
     * Throwable { final Configuration configuration = Configuration.builder() .jsonProvider( new
     * JacksonJsonNodeJsonProvider() ) .mappingProvider( new JacksonMappingProvider() ) .build();
     * 
     * final String idValue = JsonPath.using( configuration ).parse( workingEntity ).read( idFieldPath, String.class );
     * 
     * i_make_a_request_to_with_a_jwt_using_as_a_secret_and_with_the_following_properties( requestMethod, url + "/" +
     * idValue, properties ); }
     * 
     * @Then("^I repeat the previous request$") public void i_repeat_the_previous_request() { response =
     * HTTPUtils.connect( (String) previousRequest.get( "requestMethod" ), RULE.getLocalPort(), (String)
     * previousRequest.get("url"), previousRequest.get( "workingEntity" ), MediaType.APPLICATION_JSON, (String)
     * previousRequest.get("jwt") );
     * 
     * if ( response.getStatus() == Status.CREATED.getStatusCode() ) { final String resourceLocation =
     * response.getHeaderString( "Location" );
     * 
     * createdResourceIds.add( resourceLocation.contains( "/" ) ? resourceLocation.substring(
     * resourceLocation.lastIndexOf( "/" ) + 1 ) : resourceLocation ); } }
     */

}
