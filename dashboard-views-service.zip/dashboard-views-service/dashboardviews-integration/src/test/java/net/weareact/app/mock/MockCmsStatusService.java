package net.weareact.app.mock;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeoutException;

import javax.validation.Validation;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.JsonNode;

import io.dropwizard.configuration.ConfigurationException;
import io.dropwizard.configuration.ConfigurationFactory;
import io.dropwizard.jackson.Jackson;
import net.weareact.api.impl.config.DashBoardApiConfiguration;
import net.weareact.api.impl.utils.DashboardViewsImplQueryUtil;
import net.weareact.cmsstatuses.model.CmsStatus;
import net.weareact.cmsstatuses.model.CmsStatusesResponse;
import net.weareact.cmsstatuses.model.ContractEventQueueContent;
import net.weareact.cmsstatuses.model.ContractEventTypeTotal;
import net.weareact.cmsstatuses.model.SchemeLink;
import net.weareact.common.data.exception.DataStoreException;

public class MockCmsStatusService
{

    private static final Logger       LOGGER    = LoggerFactory.getLogger( MockCmsStatusService.class.getName() );

    private static final Integer      PORT      = 18080;
    private static final String       HOST_NAME = "localhost";

    private DashBoardApiConfiguration dashBoardApiConfiguration;
    private static List<CmsStatus>    cmsStatuses;

    public MockCmsStatusService()
    {
        try
        {
            ConfigurationFactory<DashBoardApiConfiguration> configurationFactory = new ConfigurationFactory<>(
                    DashBoardApiConfiguration.class,
                    Validation.buildDefaultValidatorFactory().getValidator(),
                    Jackson.newObjectMapper(),
                    "d" );
            InputStream in = this.getClass().getClassLoader().getResourceAsStream( "dashboard-internal-test.yml" );
            File tempFile = File.createTempFile( "dashboard-internal-test", "tmp" );
            tempFile.deleteOnExit();
            FileOutputStream out = new FileOutputStream( tempFile );
            IOUtils.copy( in, out );

            this.dashBoardApiConfiguration = configurationFactory.build( tempFile );
        }
        catch ( IOException | ConfigurationException ex )
        {
            LOGGER.error( "MockDistributionListService::Exception in building configuration - " + ex.getMessage() );
        }
    }

    public void mockCmsStatuses( final List<Map<String, String>> dataMapList, final String queryParams )
    {

        try
        {
            cmsStatuses = createTestData( dataMapList );
            CmsStatusesResponse response = new CmsStatusesResponse();
            response.setCmsStatuses( cmsStatuses );
            /*
             * response.setcmsStatuses( cmsStatuses );
             *
             * Paging meta = new Paging(); meta.setLimit( 100L ); meta.setOffset( 0L ); meta.setTotalCount( 1L );
             * response.setMeta( meta );
             */

            String q = DashboardViewsImplQueryUtil.buildQueryForProductQueuedMessages(
                    dashBoardApiConfiguration.getCmsQueuedMessages(),
                    queryParams );

            String query = "/v1/cms-statuses?q=" + q;
            Client client = ClientBuilder.newClient();
            Response mockResponse = client
                    .target( "http://" + HOST_NAME + ":" + PORT )
                    .path( "/mock/responses" )
                    .queryParam( "apiPath", query )
                    .request()
                    .put( Entity.entity( response, MediaType.APPLICATION_JSON ) );
            System.out.println( "Put Request Response" + mockResponse );
        }
        catch ( IOException | TimeoutException | DataStoreException e )
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    public void mockCmsStatusesForAverage( final List<Map<String, String>> dataMapList, final String cmsName )
    {
        List<CmsStatus> cmsStatusesForAverage;
        try
        {
            cmsStatusesForAverage = createTestData( dataMapList );
            CmsStatusesResponse response = new CmsStatusesResponse();
            response.setCmsStatuses( cmsStatusesForAverage );

            ZonedDateTime earliestDate = cmsStatuses.get( cmsStatuses.size() - 1 ).getDateTime();

            JsonNode graphConfig = dashBoardApiConfiguration.getCmsQueuedMessages();
            // build query to fetch rollBackNumber records for average calculation
            final int rollBackNumber;
            JsonNode rollBackNode = graphConfig.get( "rollBackNumber" );
            if ( rollBackNode.get( cmsName ) != null )
            {
                rollBackNumber = rollBackNode.get( cmsName ).asInt();
            }
            else
            {
                rollBackNumber = rollBackNode.get( "default" ).asInt();
            }

            String q = DashboardViewsImplQueryUtil.buildQueryToFetchDataForAvergaeLineCalculation(
                    graphConfig,
                    cmsName,
                    earliestDate,
                    // rollBackNumber,
                    "cmsNameParameterName" );

            int limit = rollBackNumber - 1;
            String query = "/v1/cms-statuses?limit=" + limit + "&q=" + q;
            Client client = ClientBuilder.newClient();
            Response mockResponse = client
                    .target( "http://" + HOST_NAME + ":" + PORT )
                    .path( "/mock/responses" )
                    .queryParam( "apiPath", query )
                    // .queryParam( "offset", 0 )
                    .request()
                    .put( Entity.entity( response, MediaType.APPLICATION_JSON ) );
            System.out.println( "Put Request Response" + mockResponse );
        }
        catch ( IOException | TimeoutException | DataStoreException e )
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    private static List<CmsStatus> createTestData( final List<Map<String, String>> dataMapList )
            throws IOException,
            TimeoutException,
            DataStoreException
    {
        List<CmsStatus> cmsStatusList = new ArrayList<>();
        try
        {
            // Post cmsStatus objects with given data
            /*
             * cmsStatus contains List<SchemeLink> and MessageQueueContent Object. MessageQueueContent contains
             * List<MessageTypeTotal>
             */
            if ( !dataMapList.isEmpty() )
            {
                int count = 0;
                for ( Map<String, String> dataMapAtEachListIndex : dataMapList )
                {
                    String cmsStatusName = dataMapAtEachListIndex.get( "name" );
                    String cmsDateTimeAsStr = dataMapAtEachListIndex.get( "date_time" );

                    // comma separated scheme_links
                    String schemeLink = dataMapAtEachListIndex.get( "scheme_links" ).trim();
                    List<String> schemeLinkList = Arrays.asList( schemeLink.split( "," ) );

                    // comma separated scheme_abbreviations
                    String schemeAbbreviation = dataMapAtEachListIndex.get( "scheme_abbreviations" ).trim();
                    List<String> schemeAbbreviationList = Arrays.asList( schemeAbbreviation.split( "," ) );

                    String msgTotalQueueSize = dataMapAtEachListIndex.get( "msg_total_queue_size" );

                    // comma separated msg_type_codes
                    String msgTypeCode = dataMapAtEachListIndex.get( "msg_type_codes" );
                    List<String> msgTypeCodeList = Arrays.asList( msgTypeCode.split( "," ) );

                    // comma separated msg_type_names
                    String msgTypeName = dataMapAtEachListIndex.get( "msg_type_names" );
                    List<String> msgTypeNameList = Arrays.asList( msgTypeName.split( "," ) );

                    // comma separated msg_type_totals
                    String msgTypeTotalNumber = dataMapAtEachListIndex.get( "msg_type_totals" );
                    List<String> msgTypeTotalNumberList = Arrays.asList( msgTypeTotalNumber.split( "," ) );

                    // Parse Date Time
                    ZonedDateTime cmsDateTime = ZonedDateTime.parse( cmsDateTimeAsStr );
                    if ( !dataMapAtEachListIndex.isEmpty() )
                    {

                        CmsStatus cmsStatusObj = new CmsStatus();

                        cmsStatusObj.setId( ( count + 1 ) + "_cms_Status_Id_" + Math.random() );

                        cmsStatusObj.setName( cmsStatusName );
                        cmsStatusObj.setDateTime( cmsDateTime );

                        // Set List Of Schemes
                        List<SchemeLink> tempSchemeList = new ArrayList<>();

                        for ( int i = 0; i < schemeLinkList.size(); i++ )
                        {
                            SchemeLink scheme = new SchemeLink();
                            scheme.setLink( schemeLinkList.get( i ) );
                            scheme.setAbbreviation( schemeAbbreviationList.get( i ) );
                            tempSchemeList.add( scheme );
                        }
                        cmsStatusObj.setSchemes( tempSchemeList );

                        // Build MessageQueueContent Object containing List<MessageTypeTotal>
                        ContractEventQueueContent msgQueueContent = new ContractEventQueueContent();
                        msgQueueContent.setTotalSize( Integer.valueOf( msgTotalQueueSize ) );

                        // Set List Of MessageTypeTotal in MessageQueueContent

                        List<ContractEventTypeTotal> tempMessageTypeTotalList = new ArrayList<>();

                        // msgTypeCodeList
                        for ( int i = 0; i < msgTypeCodeList.size(); i++ )
                        {
                            ContractEventTypeTotal msgTypeTotalObj = new ContractEventTypeTotal();

                            msgTypeTotalObj.setMessageCode( msgTypeCodeList.get( i ) );
                            msgTypeTotalObj.setMessageName( msgTypeNameList.get( i ) );
                            msgTypeTotalObj.setTotal( Integer.valueOf( msgTypeTotalNumberList.get( i ) ) );

                            tempMessageTypeTotalList.add( msgTypeTotalObj );
                        }

                        msgQueueContent.setContractEventTypeTotals( tempMessageTypeTotalList );

                        cmsStatusObj.setContractEventsQueueContent( msgQueueContent );
                        cmsStatusList.add( cmsStatusObj );
                        count++;
                    }
                }

            }

        }
        catch ( Exception e )
        {
            LOGGER.error( "Error occured while creating test data for cms status service : " + e.getMessage() );
            e.printStackTrace();
        }

        return cmsStatusList;

    }

}
