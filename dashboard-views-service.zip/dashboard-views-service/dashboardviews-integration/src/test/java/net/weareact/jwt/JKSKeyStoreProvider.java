/**
 * Copyright 2015 Applied Card Technologies Ltd
 */
package net.weareact.jwt;

import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;

/**
 *
 * @author dstorey
 */
public class JKSKeyStoreProvider implements KeyStoreProvider
{
    @Override
    public KeyStore getKeyStore( final String keyStorePath, final String password ) throws KeyStoreException
    {
        try
        {
            KeyStore keyStore = KeyStore.getInstance( "JKS" );
            keyStore.load( new FileInputStream( keyStorePath ), password.toCharArray() );
            return keyStore;
        }
        catch ( IOException | NoSuchAlgorithmException | CertificateException ex )
        {
            throw new KeyStoreException( ex );
        }
    }

}
