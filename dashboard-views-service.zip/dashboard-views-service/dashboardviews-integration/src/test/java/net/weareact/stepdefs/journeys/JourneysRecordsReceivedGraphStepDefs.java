package net.weareact.stepdefs.journeys;

import java.time.DayOfWeek;
import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.junit.Assert;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.weareact.CucumberIT;
import net.weareact.api.impl.utils.DateUtils;
import net.weareact.app.DashboardViewsConfiguration;
import net.weareact.common.dropwizard.DropwizardUtil;
import net.weareact.journeys.model.GroupSummary;
import net.weareact.journeys.model.SummaryResponse;
import net.weareact.model.DashboardView;
import net.weareact.model.DashboardViewResponse;
import net.weareact.model.GraphDataPoint;
import net.weareact.model.PointData;
import net.weareact.utils.DVSIntegrationUtil;

public class JourneysRecordsReceivedGraphStepDefs
{
    private static final Integer PORT                      = 18080;
    private static final String  HOST_NAME                 = "localhost";
    private static final String  API_HOST_NAME             = "localhost";
    private static final String  DASH_BOARD_VIEWS_API_PATH = "v1/dashboard-views";
    private static final String  JWT_ASSERTION_HEADER      = "X-JWT-Assertion";
    private Response             apiResponseForJwtToken;
    private Response             apiResponse;

    DVSIntegrationUtil           iUtil                     = new DVSIntegrationUtil();
    DashboardViewResponse        dashboardViewResponse;

    @Given( "^Journey Service has data for scheme \"(.*?)\" and  last (\\d+) \"(.*?)\"$" )
    public void journey_Service_has_data_for_scheme_and_last( String schemes, int num, String timeFilter )
            throws Throwable
    {
        GroupSummary summary = new GroupSummary();
        String endDate = "";
        String startDate = "";
        ZonedDateTime currentDataEndDate;
        switch ( timeFilter )
        {
        case "days":

            Map<String, GroupSummary> map = new HashMap<>();
            ZonedDateTime today = ZonedDateTime.now();
            for ( int i = 0; i < num; i++ )
            {
                GroupSummary groupSummary = new GroupSummary();
                groupSummary.setTotal( i );
                map.put( DateUtils.converDateToStringwithTimeZero( today.minusDays( i ) ), groupSummary );
            }
            summary.setSubGroups( map );
            startDate = DateUtils.converDateToString(
                    ZonedDateTime.now().minusDays( num - 1 ).withHour( 00 ).withMinute( 00 ).withSecond( 00 ) );
            endDate = DateUtils
                    .converDateToString( ZonedDateTime.now().withHour( 23 ).withMinute( 59 ).withSecond( 59 ) );

            break;
        case "months":
            Map<String, GroupSummary> monthsMap = new HashMap<>();
            ZonedDateTime currentDate = ZonedDateTime.now();
            ZonedDateTime endDateOfMonth;
            ZonedDateTime currentDataStartDate;

            for ( int i = 0; i < num; i++ )
            {
                GroupSummary groupSummary = new GroupSummary();

                groupSummary.setTotal( i );
                int count = groupSummary.getTotal();
                endDateOfMonth = currentDate
                        .plusDays( currentDate.getMonth().maxLength() - currentDate.getDayOfMonth() );
                endDateOfMonth = endDateOfMonth.withHour( 23 ).withMinute( 59 ).withSecond( 59 );

                for ( int j = 0; j < num; j++ )
                {
                    for ( int k = 1; k < endDateOfMonth.getMonth().maxLength(); k++ )
                    {
                        monthsMap.put(
                                DateUtils.converDateToStringwithTimeZero( endDateOfMonth.minusDays( k ) ),

                                groupSummary );

                    }

                }

                currentDate = currentDate.minusMonths( 1 );

            }
            summary.setSubGroups( monthsMap );

            endDateOfMonth = ZonedDateTime
                    .now()
                    .plusDays( ZonedDateTime.now().getMonth().maxLength() - currentDate.getDayOfMonth() );
            endDateOfMonth = endDateOfMonth.withHour( 23 ).withMinute( 59 ).withSecond( 59 );

            currentDataStartDate = endDateOfMonth.minusMonths( 8 );
            currentDataStartDate = currentDataStartDate
                    .withDayOfMonth( currentDataStartDate.getMonth().maxLength() )
                    .plusSeconds( 1 );
            endDate = DateUtils.converDateToString( endDateOfMonth );

            startDate = DateUtils.converDateToStringwithTimeZero( currentDataStartDate );

            break;
        case "weeks":
            Map<String, GroupSummary> currentDateMap = new HashMap<>();
            ZonedDateTime endateDate = ZonedDateTime.now();
            for ( int i = 0; i < num; i++ )
            {
                GroupSummary groupSummary = new GroupSummary();

                groupSummary.setTotal( i );
                int count = groupSummary.getTotal();

                endateDate = endateDate.with( DayOfWeek.SUNDAY ).withHour( 23 ).withMinute( 59 ).withSecond( 59 );

                if ( count == i )
                {
                    for ( int j = 0; j < num - 1; j++ )
                    {
                        currentDateMap.put(
                                DateUtils.converDateToStringwithTimeZero( endateDate.minusDays( j ) ),
                                groupSummary );

                    }

                }

                endateDate = endateDate.minusWeeks( 1 );

            }

            summary.setSubGroups( currentDateMap );

            startDate = DateUtils.converDateToStringwithTimeZero(
                    ZonedDateTime
                            .now()
                            .with( DayOfWeek.SUNDAY )
                            .plusDays( 1 )
                            .withHour( 00 )
                            .withMinute( 00 )
                            .withSecond( 00 )
                            .minusWeeks( num ) );
            endDate = DateUtils.converDateToString(
                    ZonedDateTime.now().withHour( 23 ).withMinute( 59 ).withSecond( 59 ).with( DayOfWeek.SUNDAY ) );

            break;

        default:
            break;
        }
        SummaryResponse response = new SummaryResponse();
        response.setSummary( summary );

        printSummayInJsonFormat( response );
        String query = "/v1/journeys/summary?q=created>="
                + startDate
                + " AND created<="
                + endDate
                + " AND "
                + schemes
                + "&grouping=created";

        Client client = ClientBuilder.newClient();
        Response mockResponse = client
                .target( "http://" + HOST_NAME + ":" + PORT )
                .path( "/mock/responses" )
                .queryParam( "apiPath", query )
                .request()
                .put( Entity.entity( response, MediaType.APPLICATION_JSON ) );
    }

    @Given( "^Journey Service has data for last (\\d+) \"(.*?)\"$" )
    public void journey_Service_has_data_for_last( int num, String timeFilter ) throws Throwable
    {
        GroupSummary summary = new GroupSummary();
        String endDate = "";
        String startDate = "";
        ZonedDateTime currentDataEndDate;
        switch ( timeFilter )
        {
        case "days":

            Map<String, GroupSummary> map = new HashMap<>();
            ZonedDateTime today = ZonedDateTime.now();
            for ( int i = 0; i < num; i++ )
            {
                GroupSummary groupSummary = new GroupSummary();
                groupSummary.setTotal( i );
                map.put( DateUtils.converDateToStringwithTimeZero( today.minusDays( i ) ), groupSummary );
            }
            summary.setSubGroups( map );
            if ( num < 8 )
            {
                num = 8;
            }
            startDate = DateUtils.converDateToStringwithTimeZero( ZonedDateTime.now().minusDays( num - 1 ) );
            endDate = DateUtils
                    .converDateToString( ZonedDateTime.now().withHour( 23 ).withMinute( 59 ).withSecond( 59 ) );

            break;
        case "months":
            Map<String, GroupSummary> monthsMap = new HashMap<>();
            ZonedDateTime currentDate = ZonedDateTime.now();
            ZonedDateTime endDateOfMonth;
            ZonedDateTime currentDataStartDate;

            for ( int i = 0; i < num; i++ )
            {
                GroupSummary groupSummary = new GroupSummary();

                groupSummary.setTotal( i );
                int count = groupSummary.getTotal();
                endDateOfMonth = currentDate
                        .plusDays( currentDate.getMonth().maxLength() - currentDate.getDayOfMonth() );
                endDateOfMonth = endDateOfMonth.withHour( 23 ).withMinute( 59 ).withSecond( 59 );

                for ( int j = 0; j < num; j++ )
                {
                    for ( int k = 1; k < endDateOfMonth.getMonth().maxLength(); k++ )
                    {
                        monthsMap.put(
                                DateUtils.converDateToStringwithTimeZero( endDateOfMonth.minusDays( k ) ),

                                groupSummary );

                    }

                }

                currentDate = currentDate.minusMonths( 1 );

            }
            summary.setSubGroups( monthsMap );

            endDateOfMonth = ZonedDateTime
                    .now()
                    .plusDays( ZonedDateTime.now().getMonth().maxLength() - currentDate.getDayOfMonth() );
            endDateOfMonth = endDateOfMonth.withHour( 23 ).withMinute( 59 ).withSecond( 59 );

            currentDataStartDate = endDateOfMonth.minusMonths( 8 );
            currentDataStartDate = currentDataStartDate
                    .withDayOfMonth( currentDataStartDate.getMonth().maxLength() )
                    .plusSeconds( 1 );
            endDate = DateUtils.converDateToString( endDateOfMonth );

            startDate = DateUtils.converDateToStringwithTimeZero( currentDataStartDate );

            break;
        case "weeks":
            Map<String, GroupSummary> currentDateMap = new HashMap<>();
            ZonedDateTime endateDate = ZonedDateTime.now();
            for ( int i = 0; i < num; i++ )
            {
                GroupSummary groupSummary = new GroupSummary();

                groupSummary.setTotal( i );
                int count = groupSummary.getTotal();

                endateDate = endateDate.with( DayOfWeek.SUNDAY ).withHour( 23 ).withMinute( 59 ).withSecond( 59 );

                if ( count == i )
                {
                    for ( int j = 0; j < num - 1; j++ )
                    {
                        currentDateMap.put(
                                DateUtils.converDateToStringwithTimeZero( endateDate.minusDays( j ) ),
                                groupSummary );

                    }

                }

                endateDate = endateDate.minusWeeks( 1 );

            }

            summary.setSubGroups( currentDateMap );

            startDate = DateUtils.converDateToStringwithTimeZero(
                    ZonedDateTime
                            .now()
                            .with( DayOfWeek.SUNDAY )
                            .plusDays( 1 )
                            .withHour( 00 )
                            .withMinute( 00 )
                            .withSecond( 00 )
                            .minusWeeks( num ) );
            endDate = DateUtils.converDateToString(
                    ZonedDateTime.now().withHour( 23 ).withMinute( 59 ).withSecond( 59 ).with( DayOfWeek.SUNDAY ) );

            break;

        default:
            break;
        }
        SummaryResponse response = new SummaryResponse();
        response.setSummary( summary );

        printSummayInJsonFormat( response );
        String query = "/v1/journeys/summary?q=created>="
                + startDate
                + " AND created<="
                + endDate
                + "&grouping=created";
        Client client = ClientBuilder.newClient();
        Response mockResponse = client
                .target( "http://" + HOST_NAME + ":" + PORT )
                .path( "/mock/responses" )
                .queryParam( "apiPath", query )
                .request()
                .put( Entity.entity( response, MediaType.APPLICATION_JSON ) );

    }

    @When( "^DashboardViews service is called to get data for graph \"(.*?)\"  with filter as \"(.*?)\" and scheme filter as \"(.*?)\"$" )
    public void dashboardviews_service_is_called_to_get_data_for_graph_with_filter_as_and_scheme_filter_as(
            String graphID,
            String timeFilter,
            String schemes ) throws Throwable
    {
        DashboardViewsConfiguration configuration = CucumberIT.RULE.getConfiguration();

        int apiHttpPort = DropwizardUtil.getApplicationHttpPort( configuration );

        Client apiClient = ClientBuilder.newClient();
        WebTarget target = apiClient.target(
                "http://" + API_HOST_NAME + ":" + apiHttpPort + "/" + DASH_BOARD_VIEWS_API_PATH + "/" + graphID );

        // for just validating scenario for the position of scheme filter in query does not affect.
        if ( timeFilter.equals( "LAST_8_MONTHS" ) )
        {
            target = target.queryParam( "q", schemes + " AND " + "timeFilter = " + timeFilter );
        }
        else
        {

            target = target.queryParam( "q", "timeFilter = " + timeFilter + " AND " + schemes );

        }

        apiResponse = target.request().header( JWT_ASSERTION_HEADER, iUtil.getJWT_TOKEN_VALUE() ).get();
        Thread.sleep( 1000 );
    }

    @When( "^DashboardViews service is called to get data for invalid JwtToken \"(.*?)\" graph with filter \"(.*?)\" and \"(.*?)\"$" )
    public void dashboardviews_service_is_called_to_get_data_for_invalid_JwtToken_graph_with_filter_and(
            String graphID,
            String timeFilter,
            String invalidJwtToken ) throws Throwable
    {
        DashboardViewsConfiguration configuration = CucumberIT.RULE.getConfiguration();

        int apiHttpPort = DropwizardUtil.getApplicationHttpPort( configuration );

        Client apiClient = ClientBuilder.newClient();
        WebTarget target = apiClient.target(
                "http://" + API_HOST_NAME + ":" + apiHttpPort + "/" + DASH_BOARD_VIEWS_API_PATH + "/" + graphID );

        if ( timeFilter != null )
        {
            target = target.queryParam( "q", "timeFilter = " + timeFilter );
        }

        apiResponseForJwtToken = target.request().header( JWT_ASSERTION_HEADER, invalidJwtToken ).get();
        System.out.println( "Filter for graphID**********************************************" + apiResponse );
        Thread.sleep( 1000 );
    }

    @When( "^DashboardViews service is called to get data for \"(.*?)\" graph with filter \"(.*?)\"$" )
    public void dashboardviews_service_is_called_to_get_data_for_graph_with_filter( String graphID, String timeFilter )
            throws Throwable
    {
        DashboardViewsConfiguration configuration = CucumberIT.RULE.getConfiguration();

        int apiHttpPort = DropwizardUtil.getApplicationHttpPort( configuration );

        Client apiClient = ClientBuilder.newClient();
        WebTarget target = apiClient.target(
                "http://" + API_HOST_NAME + ":" + apiHttpPort + "/" + DASH_BOARD_VIEWS_API_PATH + "/" + graphID );

        if ( timeFilter != null )
        {
            target = target.queryParam( "q", "timeFilter = " + timeFilter );
        }

        apiResponse = target.request().header( JWT_ASSERTION_HEADER, iUtil.getJWT_TOKEN_VALUE() ).get();
        Thread.sleep( 1000 );

    }

    @Then( "^Response should be (\\d+)$" )
    public void response_should_be( int arg1 ) throws Throwable
    {
        dashboardViewResponse = apiResponse.readEntity( DashboardViewResponse.class );
        Assert.assertEquals( arg1, apiResponse.getStatus() );
    }

    @Given( "^user has access to following schemes data:$" )
    public void user_has_access_to_following_schemes_data( DataTable arg1 ) throws Throwable
    {
        iUtil.prepareJWT( arg1 );
    }

    @Then( "^Response should have following data for \"(.*?)\" data$" )
    public void response_should_have_following_data_for_data( String string, Map<String, Integer> map ) throws Throwable
    {

        DashboardView view = dashboardViewResponse.getDashboardView();
        GraphDataPoint currentGraphData = null;
        if ( string.equals( "current" ) )
        {
            currentGraphData = view.getGraphData().get( 0 );
        }
        else
        {
            currentGraphData = view.getGraphData().get( 1 );

        }

        System.out.println( "dashboardViewResponse" + dashboardViewResponse );
        Assert.assertEquals( 8, currentGraphData.getDataPointValues().size() );
        int counter = 0;
        for ( String key : map.keySet() )
        {

            Assert.assertEquals( map.get( key ), currentGraphData.getDataPointValues().get( counter ).getPointValue() );
            counter++;
        }
    }

    @Then( "^Response of journey summary for eight weeks should have following data:$" )
    public void response_of_journey_summary_should_have_following_data( DataTable table ) throws Throwable
    {
        List<Map<String, String>> dataMapList = table.asMaps( String.class, String.class );

        DashboardView view = dashboardViewResponse.getDashboardView();
        GraphDataPoint currentGraphData = view.getGraphData().get( 0 );
        GraphDataPoint AvgGraphData = view.getGraphData().get( 1 );
        List<PointData> pointDataList = currentGraphData.getDataPointValues();
        List<PointData> avgPointValue = AvgGraphData.getDataPointValues();
        Integer pointValue = pointDataList.get( 7 ).getPointValue();

        int counter = 0, avgCounter = 0;

        Assert.assertEquals( 8, currentGraphData.getDataPointValues().size() );

        for ( PointData pointData : pointDataList )
        {
            String value = dataMapList.get( counter ).get( "currentValue" );
            Integer calValue = Integer.parseInt( value ) * 7;

            Assert.assertEquals( calValue, pointData.getPointValue() );
            counter++;
        }

        for ( PointData pointData : avgPointValue )
        {
            String value = dataMapList.get( avgCounter ).get( "AvrageValue" );
            Integer calValue = Integer.parseInt( value );

            Assert.assertEquals( calValue, pointData.getPointValue() );
            avgCounter++;
        }

    }

    @Then( "^Response of journey summary for eight month should have following data:$" )
    public void response_of_journey_summary_for_eight_month_should_have_following_data( DataTable table )
            throws Throwable
    {
        List<Map<String, String>> dataMapList = table.asMaps( String.class, String.class );

        DashboardView view = dashboardViewResponse.getDashboardView();
        GraphDataPoint currentGraphData = view.getGraphData().get( 0 );
        GraphDataPoint AvgGraphData = view.getGraphData().get( 1 );
        List<PointData> pointDataList = currentGraphData.getDataPointValues();
        List<PointData> avgPointValue = AvgGraphData.getDataPointValues();
        Integer pointValue = pointDataList.get( 7 ).getPointValue();

        int counter = 0, avgCounter = 0;

        Assert.assertEquals( 8, currentGraphData.getDataPointValues().size() );

        for ( PointData pointData : pointDataList )
        {
            String value = dataMapList.get( counter ).get( "currentValue" );
            Integer calValue = Integer.parseInt( value );

            Assert.assertEquals( calValue, pointData.getPointValue() );
            counter++;
        }

        for ( PointData pointData : avgPointValue )
        {
            String value = dataMapList.get( avgCounter ).get( "AvrageValue" );
            Integer calValue = Integer.parseInt( value );

            Assert.assertEquals( calValue, pointData.getPointValue() );
            avgCounter++;
        }
    }

    @Then( "^Response for \"(.*?)\" should be (\\d+)$" )
    public void response_for_should_be( String invalidPrameter, int responseCode ) throws Throwable
    {
        switch ( invalidPrameter )
        {
        case "invalid_graphid":
            Assert.assertEquals( responseCode, apiResponse.getStatus() );
            break;
        case "invalid_timeFilter":
            Assert.assertEquals( responseCode, apiResponse.getStatus() );
            break;
        case "invalid_jwt_token":
            Assert.assertEquals( responseCode, apiResponseForJwtToken.getStatus() );
            break;
        }

    }

    public void printSummayInJsonFormat( SummaryResponse response )
    {
        ObjectMapper mapper = new ObjectMapper();
        try
        {
            System.out.println( "----@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@----" );
            System.out.println( mapper.writeValueAsString( response ) );
        }
        catch ( JsonProcessingException e )
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

}
