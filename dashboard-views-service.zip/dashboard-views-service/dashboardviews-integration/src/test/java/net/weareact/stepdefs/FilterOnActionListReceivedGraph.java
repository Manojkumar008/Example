/* **************************************************************************
 *             Copyright 2010 Applied Card Technologies Ltd
 *
 * What : FilterOnActionListReceivedGraph
 * Who  : kuyatega
 * When : Feb 4, 2016
 *
 * Source control
 *		$Revision: 91803 $
 *		$Author: markh2 $
 *		$Date: 2012-11-12 14:00:56 +0000 (Mon, 12 Nov 2012) $
 *
 ****************************************************************************/

package net.weareact.stepdefs;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.Map;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.weareact.CucumberIT;
import net.weareact.api.impl.DistributionListToGraphDataForTopLevelGraph;
import net.weareact.app.DashboardViewsConfiguration;
import net.weareact.app.mock.MockDistributionListService;
import net.weareact.common.dropwizard.DropwizardUtil;
import net.weareact.dashboardview.model.ReceivedDistributionList.TypeEnum;
import net.weareact.model.DashboardView;
import net.weareact.model.DashboardViewResponse;
import net.weareact.model.PointData;

public class FilterOnActionListReceivedGraph
{

    private static final Logger   LOGGER                    = LoggerFactory
                                                                    .getLogger(
                                                                            FilterOnActionListReceivedGraph.class
                                                                                    .getName() );

    private static final String   API_HOST_NAME             = "localhost";
    private static final String   DASH_BOARD_VIEWS_API_PATH = "v1/dashboard-views";
    private static final String   JWT_ASSERTION_HEADER      = "X-JWT-Assertion";
    private static String         JWT_TOKEN_VALUE           = "eyJ0eXAiOiJKV1QiLCJ4NXQiOiJNbU15WW1GaVltRTNPV1U0TjJObE5tSmpNVEF4TVdFNE9UY3dNR0V6TnpZMVpHWTNOamN3TnciLCJhbGciOiJSUzI1NiJ9.eyJzY2hlbWVzIjpbeyJhYmJyZXZpYXRpb24iOiJBQ1QxIiwibGluayI6InNjaGVtZXMvMSJ9LHsiYWJicmV2aWF0aW9uIjoiQUNUMiIsImxpbmsiOiJzY2hlbWVzLzIifSx7ImFiYnJldmlhdGlvbiI6IkFDVDMiLCJsaW5rIjoic2NoZW1lcy8zIn0seyJhYmJyZXZpYXRpb24iOiJBQ1Q0IiwibGluayI6InNjaGVtZXMvNCJ9XSwic2NvcGVzIjpbXSwib3JnYW5pc2F0aW9uIjp7fSwiZXhwIjoiOTIyMzM3MjAzNjg1NDc3NTgwNyJ9.Y5w7egYWGuBpmzHEoaQpRw7fZOu1BK5MwfoH_rO0njXQx4OsMYZw7tWnB3vNRO2JKjgT__w9VgY49Mq_J1heuvGVVNgZDxzORWpZUeh2MuzmY1ME6IEhe9-2R1J3SWoj8hJrnjB_ypfNI9W4QNUSwUVoyfNx77boH20Y8akUr8M38vTwI7E5qTVZ_JRjnUIpDV-Bi3bADfNyLo9c_r-ywcsNpeoyTivsI_iIHWbuKl5U0JKtCWmYHmfR-oKR9rwW5AGtKr5i6ap5jJWFxIfre-ffp8DPxxy7NsRIzk6r214fEgNVJvq-QgPobgy-iI9sGt21MDFahBd-SaEBn_IbPg";

    private static Integer        apiHttpPort;
    private Client                apiClient                 = ClientBuilder.newClient();
    private WebTarget             target;
    private Response              apiResponse;
    private DashboardViewResponse dashboardViewResponse;
    private DashboardView         dashboardView;

    public FilterOnActionListReceivedGraph()
    {
        DashboardViewsConfiguration dashboardViewConfiguration = CucumberIT.RULE.getConfiguration();
        apiHttpPort = DropwizardUtil.getApplicationHttpPort( dashboardViewConfiguration );
        LOGGER.info( "Constructor FilterOnActionListReceivedGraph:: apiHttpPort - " + apiHttpPort );
    }

    @Given( "^Create Received Distribution List Objects of ActionList Type with following properties :$" )
    public void create_Received_Distribution_List_Objects_of_ActionList_Type_with_following_properties(
            DataTable table ) throws Throwable
    {
        LOGGER.info( "FilterOnActionListReceivedGraph >> Test data creating.::::::::::" );

        List<Map<String, String>> dataMapList = table.asMaps( String.class, String.class );
        MockDistributionListService dlService = new MockDistributionListService();
        // dlService.createRecDLMockObjects( dataMapList, true );

    }

    @Given( "^that I mock Received \"(.*?)\" objects at the endpoint \"(.*?)\" for \"(.*?)\" graph$" )
    public void that_I_mock_Received_objects_at_the_endpoint_for_graph(
            String type,
            String query,
            String graphName,
            DataTable data ) throws Throwable
    {
        // Write code here that turns the phrase above into concrete actions
        // For automatic transformation, change DataTable to one of
        // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
        // E,K,V must be a scalar (String, Integer, Date, enum etc)

        List<Map<String, String>> dataMapList = data.asMaps( String.class, String.class );
        MockDistributionListService dlService = new MockDistributionListService();
        dlService.createAndMockReceivedDistributionList(
                dataMapList,
                TypeEnum.valueOf( type ),
                graphName,
                query,
                null,
                true,
                false,
                0L,
                0L,
                0L );
    }

    @Given( "^Distribution List API is running$" )
    public void distribution_List_API_is_running() throws Throwable
    {
        LOGGER.info( "FilterOnActionListReceivedGraph >> DL Application is running...::::::::::" );
    }

    @Given( "^Database has above created ReceivedDistributionList Objects stored$" )
    public void database_has_above_created_ReceivedDistributionList_Objects_stored() throws Throwable
    {
        LOGGER.info( "FilterOnActionListReceivedGraph >> Test data created.::::::::::" );
    }

    @When( "^retrieve ReceivedDistributionList objects for graph \"(.*?)\" from api passing following schemes:$" )
    public void retrieve_ReceivedDistributionList_objects_for_graph_from_api_passing_following_schemes(
            String graphName,
            DataTable arg2 ) throws Throwable
    {
        DistributionListToGraphDataForTopLevelGraph retriveGraghData = new DistributionListToGraphDataForTopLevelGraph();

        target = apiClient
                .target( "http://" + API_HOST_NAME + ":" + apiHttpPort + "/" + DASH_BOARD_VIEWS_API_PATH + "/" )
                .path( graphName )
                .queryParam(
                        "q",
                        "scheme.link IN(/schemes/000e45cc-b9e0-11e5-9912-ba0be0483c18,/schemes/111b06b4-b9e0-11e5-9912-ba0be0483c18)" );
        apiResponse = target.request().header( JWT_ASSERTION_HEADER, JWT_TOKEN_VALUE ).get();

        dashboardViewResponse = apiResponse.readEntity( DashboardViewResponse.class );
        dashboardView = dashboardViewResponse.getDashboardView();

    }

    @Then( "^response should be have (\\d+) status response$" )
    public void response_should_be_have_status_response( int statusCode ) throws Throwable
    {

        assertEquals( statusCode, apiResponse.getStatus() );
    }

    @Then( "^response should have following array of PointData having following values as ::$" )
    public void response_should_have_following_array_of_PointData_having_following_values_as(
            List<PointData> listPointData ) throws Throwable
    {

        assertEquals(
                listPointData.get( 0 ).getPointValue(),
                dashboardView.getGraphData().get( 0 ).getDataPointValues().get( 0 ).getPointValue() );
        assertEquals(
                listPointData.get( 1 ).getPointValue(),
                dashboardView.getGraphData().get( 0 ).getDataPointValues().get( 1 ).getPointValue() );
    }

    @Given( "^Received Distribution List API is running$" )
    public void received_Distribution_List_API_is_running() throws Throwable
    {
        LOGGER.info( "FilterOnActionListReceivedGraph >> DL Application is running...::::::::::" );

    }

    @When( "^retrieve ReceivedDistributionList objects for graph \"(.*?)\" from api passing <startdate> and <enddate>$" )
    public void retrieve_ReceivedDistributionList_objects_for_graph_from_api_passing_startdate_and_enddate(
            String graphName,
            Map<String, String> dataMap ) throws Throwable
    {
        target = apiClient
                .target( "http://" + API_HOST_NAME + ":" + apiHttpPort + "/" + DASH_BOARD_VIEWS_API_PATH + "/" )
                .path( graphName )
                .queryParam(
                        "q",
                        "startDate>=" + dataMap.get( "startdate" ) + " AND endDate<=" + dataMap.get( "enddate" ) );
        apiResponse = target.request().header( JWT_ASSERTION_HEADER, JWT_TOKEN_VALUE ).get();

        dashboardViewResponse = apiResponse.readEntity( DashboardViewResponse.class );
        dashboardView = dashboardViewResponse.getDashboardView();

    }

    @Then( "^response with following data should be returned$" )
    public void response_with_following_data_should_be_returned( List<String> pointValue ) throws Throwable
    {
        assertEquals(
                Integer.valueOf( pointValue.get( 1 ) ),
                dashboardView.getGraphData().get( 0 ).getDataPointValues().get( 0 ).getPointValue() );

        assertEquals(
                Integer.valueOf( pointValue.get( 2 ) ),
                dashboardView.getGraphData().get( 0 ).getDataPointValues().get( 1 ).getPointValue() );

        assertEquals( "Success", dashboardView.getGraphData().get( 0 ).getDataPointLegend().get( "en" ) );

    }

    @Then( "^API Response should have (\\d+) Objects$" )
    public void api_Response_should_have_Objects( int listSize ) throws Throwable
    {
        assertEquals( 1, dashboardView.getGraphData().size() );

    }

    @When( "^retrieve ReceivedDistributionList objects for graph \"(.*?)\" from api passing <startdate> and <enddate> and <time>$" )
    public void retrieve_ReceivedDistributionList_objects_for_graph_from_api_passing_startdate_and_enddate_and_time(
            String graphName,
            Map<String, String> dataMap ) throws Throwable
    {

        target = apiClient
                .target( "http://" + API_HOST_NAME + ":" + apiHttpPort + "/" + DASH_BOARD_VIEWS_API_PATH + "/" )
                .path( graphName )
                .queryParam(
                        "q",
                        "startDate>="
                                + dataMap.get( "startdate" )
                                + " AND endDate<="
                                + dataMap.get( "enddate" )
                                + " AND time="
                                + dataMap.get( "time" ) );
        apiResponse = target.request().header( JWT_ASSERTION_HEADER, JWT_TOKEN_VALUE ).get();

        dashboardViewResponse = apiResponse.readEntity( DashboardViewResponse.class );
        dashboardView = dashboardViewResponse.getDashboardView();
    }

    @Then( "^response with following data should be returned for time :$" )
    public void response_with_following_data_should_be_returned_for_time( Map<String, String> pointData )
            throws Throwable
    {

        assertEquals(
                Integer.valueOf( pointData.get( "pointValue" ) ),
                dashboardView.getGraphData().get( 0 ).getDataPointValues().get( 0 ).getPointValue() );

        assertEquals(
                pointData.get( "pointKey" ).substring( 0, 16 ),
                dashboardView.getGraphData().get( 0 ).getDataPointValues().get( 0 ).getPointKey().get( "en" ).substring(
                        0,
                        16 ) );

    }

    @Given( "^DVS API is running$" )
    public void dvs_API_is_running() throws Throwable
    {
        LOGGER.info( "FilterOnActionListReceivedGraph >> DVS API is running...::::::::::" );

    }

    @When( "^retrieve ReceivedDistributionList objects for graph \"(.*?)\" from api passing <startdate> and <enddate> and <scheme>$" )
    public void retrieve_ReceivedDistributionList_objects_for_graph_from_api_passing_startdate_and_enddate_and_scheme(
            String graphName,
            Map<String, String> dataMap ) throws Throwable
    {

        String query = "startDate>="
                + dataMap.get( "startdate" )
                + " AND endDate<="
                + dataMap.get( "enddate" )
                + " AND scheme.link IN("
                + dataMap.get( "scheme_link1" )
                + ","
                + dataMap.get( "scheme_link2" )
                + ")";
        target = apiClient
                .target( "http://" + API_HOST_NAME + ":" + apiHttpPort + "/" + DASH_BOARD_VIEWS_API_PATH + "/" )
                .path( graphName )
                .queryParam( "q", query );
        apiResponse = target.request().header( JWT_ASSERTION_HEADER, JWT_TOKEN_VALUE ).get();

        dashboardViewResponse = apiResponse.readEntity( DashboardViewResponse.class );
        dashboardView = dashboardViewResponse.getDashboardView();
    }

    @Then( "^response status should be (\\d+)$" )
    public void response_status_should_be( int arg1 ) throws Throwable
    {
        assertEquals( arg1, apiResponse.getStatus() );
    }

    @Then( "^response with following data should be returned for time and scheme filter :$" )
    public void response_with_following_data_should_be_returned_for_time_and_scheme_filter(
            Map<String, String> pointData ) throws Throwable
    {
        assertEquals(
                Integer.valueOf( pointData.get( "pointValue" ) ),
                dashboardView.getGraphData().get( 0 ).getDataPointValues().get( 0 ).getPointValue() );

        assertEquals(
                pointData.get( "pointKey" ).substring( 0, 16 ),
                dashboardView.getGraphData().get( 0 ).getDataPointValues().get( 0 ).getPointKey().get( "en" ).substring(
                        0,
                        16 ) );
    }

}
