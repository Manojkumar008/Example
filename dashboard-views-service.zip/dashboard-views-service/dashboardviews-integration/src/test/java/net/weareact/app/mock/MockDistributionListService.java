/*
 * ************************************************************************** Copyright 2010 Applied Card Technologies
 * Ltd
 *
 * What : MockDistributionListService Who : kuyatega When : Jan 27, 2016
 *
 * Source control $Revision: 91803 $ $Author: markh2 $ $Date: 2012-11-12 14:00:56 +0000 (Mon, 12 Nov 2012) $
 *
 ****************************************************************************/

package net.weareact.app.mock;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Validation;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.dropwizard.configuration.ConfigurationException;
import io.dropwizard.configuration.ConfigurationFactory;
import io.dropwizard.jackson.Jackson;
import net.weareact.api.impl.config.DashBoardApiConfiguration;
import net.weareact.api.impl.utils.DashboardViewsImplQueryUtil;
import net.weareact.api.impl.utils.DashboardViewsImplUtil;
import net.weareact.dashboardview.model.DistributionList;
import net.weareact.dashboardview.model.DistributionList.GenerationStatusEnum;
import net.weareact.dashboardview.model.DistributionListLocation;
import net.weareact.dashboardview.model.DistributionListsResponse;
import net.weareact.dashboardview.model.Paging;
import net.weareact.dashboardview.model.ReceivedDistributionList;
import net.weareact.dashboardview.model.ReceivedDistributionList.TypeEnum;
import net.weareact.dashboardview.model.ReceivedDistributionListsResponse;
import net.weareact.dashboardview.model.SchemeLink;
import net.weareact.scheme.model.Scheme;
import net.weareact.scheme.model.SchemeResponse;

public class MockDistributionListService
{
    private static final Logger       LOGGER    = LoggerFactory
                                                        .getLogger( MockDistributionListService.class.getName() );

    private static final Integer      PORT      = 18080;
    private static final String       HOST_NAME = "localhost";

    // private static final String JWT_SECRET =
    // "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsIng1dCI6Ik1tTXlZbUZpWW1FM09XVTROMk5sTm1Kak1UQXhNV0U0T1Rjd01HRXpOelkxWkdZM05qY3dOdyJ9.eyJleHAiOjE0NTMzMTg4MzYsInNjb3BlcyI6WyJhbV9hcHBsaWNhdGlvbl9zY29wZSIsImRlZmF1bHQiXSwic3ViIjoiQUNUIiwiYXBwbGljYXRpb25fbmFtZSI6IldFQVJFQUNULkNPTV90ZXN0LUFULXdlYXJlYWN0LmNvbV9EZWZhdWx0QXBwbGljYXRpb25fUFJPRFVDVElPTiIsInNjaGVtZXMiOlt7ImFiYnJldmlhdGlvbiI6IkFDVCIsImxpbmsiOiJzY2hlbWVzXC8xIn1dLCJuaWNrbmFtZSI6IkFDVCIsIndlYnNpdGUiOiJkZWZhdWx0Iiwib3JnYW5pc2F0aW9uIjp7ImFiYnJldmlhdGlvbiI6IkFDVCIsImxpbmsiOiJvcmdhbmlzYXRpb25zXC8xIn0sImlzcyI6Imh0dHA6XC9cL3dzbzIub3JnXC9nYXRld2F5IiwiaWF0IjoxNDUzMjg1MzEwLCJwcm9maWxlIjoiZGVmYXVsdCJ9.VMt7vqoG06GSc-UYhzzrdNGJkDQpoH7AZE3BvxXxbfMt01rHRjPGQwg0gfKbIiB9CB0p4Q79rkxuFPggMEgJGzjzimo2eA63svosGzqgocqM-pePUjiCESzfvl7byWFZw4ipjc8SM4Jr7OIgzT26zG7KVrknSOKVQOLlDvAItGRPOr8e38Ip2sfuj6h0F7YkiA-DHX6k5PhIYBJ1uJMAyZ2rC-Fg2GMlwpD_N0kxiFj2L5YB6iGVWE2Rerlmtmjsh_Q74m1Uz2nQLdfcEmWU9zyhGyYmtqI6zFEPvGNF71T6tONTXqJnZ1nKYneibfi0EFB7N5-vYXtboLW6RjozYA";

    private Client                    client;

    private DashBoardApiConfiguration dashBoardApiConfiguration;

    DashboardViewsImplUtil            util      = new DashboardViewsImplUtil( dashBoardApiConfiguration );

    /**
     * This method creates and mocks DistributionList objects to passed query path
     *
     * @param dataMapList
     *            {@link List} Test data passed from feature file
     * @param type
     *            {@link TypeEnum} Type of DistributionList objects to be created e.g ACTIONLIST/HOTLIST
     * @param graphName
     *            {@link String} Graph name for which data to be mocked
     * @param query
     *            {@link String} Query for the graph
     * @param isQuerytoBeBuilt
     *            {@link boolean} Flag to decide whether to use DashboardViewsImplUtil buildQuery() method or not
     * @param offset
     */
    public void createAndMockDistributionList(
            final List<Map<String, String>> dataMapList,
            final DistributionList.TypeEnum type,
            final String graphName,
            String query,
            final boolean isQuerytoBeBuilt,
            final boolean isPrepareMeta,
            final Long limit,
            final Long offset,
            final Long total )
    {

        // Creating Mock Response
        client = ClientBuilder.newClient();

        try
        {
            List<DistributionList> dlList = new ArrayList<>();
            if ( !dataMapList.isEmpty() )
            {

                Map<String, String> dataMap = null;
                int count = 0;
                for ( Map<String, String> map : dataMapList )
                {
                    dataMap = map;

                    if ( !dataMap.isEmpty() )
                    {

                        String time = dataMap.get( "generationStartDateTime" );
                        String generationStatusType = dataMap.get( "generationStatus" ).trim();
                        String unscheduleFlag = dataMap.get( "unscheduled" ).trim();
                        int numSize = Integer.valueOf( dataMap.get( "size" ).trim() );
                        String link = map.get( "schemelink" ).trim();

                        String abbreviation = null;
                        boolean abreFlag = dataMap.containsKey( "abbreviation" );
                        if ( abreFlag )
                        {
                            abbreviation = dataMap.get( "abbreviation" ).trim();
                        }

                        ZonedDateTime zdt = ZonedDateTime.parse( time );

                        DistributionList distList = new DistributionList();
                        distList.setId( ( count + 1 ) + "_DistId_" + Math.random() );

                        distList.setGenerationStatus( GenerationStatusEnum.valueOf( generationStatusType ) );
                        distList.setUnscheduled( Boolean.valueOf( unscheduleFlag ) );

                        distList.setGenerationStartDateTime( zdt );
                        distList.setGenerationEndDateTime( ZonedDateTime.now() );

                        distList.setSize( numSize );
                        distList.setType( type );

                        SchemeLink schemeLink = new SchemeLink();
                        schemeLink.setAbbreviation( abbreviation != null ? abbreviation : "_dist_list_abr" );
                        schemeLink.setLink( ( link != null ? link : "_dist_list_scheme_link" ) );
                        distList.setScheme( schemeLink );

                        dlList.add( distList );

                        count++;

                        // Mocking scheme service for each dl schemelink id
                        SchemeResponse schemeRes = new SchemeResponse();

                        Map<String, String> nameMap = new HashMap<>();
                        nameMap.put( "en", abbreviation );

                        Scheme schemeObject = new Scheme();
                        schemeObject.setId( link );
                        schemeObject.setName( nameMap );

                        schemeRes.setScheme( schemeObject );

                        client
                                .target( "http://" + HOST_NAME + ":" + PORT )
                                .path( "/mock/responses" )
                                .queryParam( "apiPath", link )
                                .request()
                                .put( Entity.entity( schemeRes, MediaType.APPLICATION_JSON ) );

                    }
                }
            }

            // putting mock object for api GET\jwt}
            DistributionListsResponse dlr = new DistributionListsResponse();
            dlr.setDistributionLists( dlList );
            if ( isQuerytoBeBuilt )
            {
                query = buildQuery( graphName, query );
            }
            query = "/v1/distribution-lists?q=" + query;

            // set Meta Info
            if ( isPrepareMeta )
            {
                Paging meta = new Paging();
                meta.setLimit( ( long ) limit );
                meta.setOffset( offset );
                meta.setTotalCount( total );
                dlr.setMeta( meta );
            }
            query = offset > 0 ? query + "%26offset=" + offset : query;
            Response response = client
                    .target( "http://" + HOST_NAME + ":" + PORT )
                    .path( "/mock/responses" )
                    .queryParam( "apiPath", query )
                    // .queryParam( "offset", offset )
                    .request()
                    .put( Entity.entity( dlr, MediaType.APPLICATION_JSON ) );
            System.out.println( "Put Request Response" + response );

        }
        catch ( Exception e )
        {
            LOGGER.error( "Exception occured while mocking DistributionList objects" + e.getMessage() );
        }

    }

    public void createAndMockReceivedDistributionList(
            final List<Map<String, String>> dataMapList,
            final TypeEnum typeOfDL,
            final String graphName,
            String query,
            final String[] schemes,
            final boolean isQuerytoBeBuilt,
            final boolean isPrepareMeta,
            final Long limit,
            final Long offset,
            final Long total )
    {
        // Creating Mock Response
        client = ClientBuilder.newClient();

        try
        {
            List<ReceivedDistributionList> receivedDLList = new ArrayList<>();

            // Post ReceivedDistributionList objects with given data
            if ( !dataMapList.isEmpty() )
            {

                int count = 0;
                for ( Map<String, String> dataMap : dataMapList )
                {

                    if ( !dataMap.isEmpty() )
                    {

                        String type = "";
                        if ( typeOfDL == null )
                        {
                            type = ( dataMap.get( "type" ).trim() );
                        }
                        else
                        {
                            type = typeOfDL.name();
                        }
                        String schemeLink = ( dataMap.get( "scheme_link" ).trim() );
                        String schemeAbbreviation = ( dataMap.get( "scheme_abbreviation" ).trim() );
                        // String receivedDateTimeAsStr = ( dataMap.get( "receivedDateTime" ).trim() );
                        String originType = ( dataMap.get( "origin" ).trim() );
                        int numSize = Integer.valueOf( dataMap.get( "size" ).trim() );

                        // Date Time Starts
                        String time = ( dataMap.get( "receivedDateTime" ).trim() );

                        ZonedDateTime tempDate = ZonedDateTime.now();
                        String dateStr = tempDate.getYear()
                                + "-"
                                + String.format( "%02d", tempDate.getMonthValue() )
                                + "-"
                                + String.format( "%02d", tempDate.getDayOfMonth() );
                        ZonedDateTime receivedDateTime = ZonedDateTime.parse( time );
                        // Date Time Ends

                        // ZonedDateTime receivedDateTime = ZonedDateTime.parse( receivedDateTimeAsStr );

                        ReceivedDistributionList recDistList = new ReceivedDistributionList();
                        recDistList.setId( ( count + 1 ) + "_Rec_DistId_" + Math.random() );

                        recDistList.setType( ReceivedDistributionList.TypeEnum.valueOf( type ) );

                        recDistList.setSize( numSize );

                        SchemeLink scheme = new SchemeLink();
                        scheme.setLink( schemeLink );
                        scheme.setAbbreviation( schemeAbbreviation );
                        recDistList.setScheme( scheme );

                        recDistList.setReceivedDateTime( receivedDateTime );

                        DistributionListLocation origin = new DistributionListLocation();
                        origin.setType( DistributionListLocation.TypeEnum.valueOf( originType ) );
                        origin.setValue( ( count + 1 ) + "_Rec_Dist_List_Origin_Dummy_Value" );
                        recDistList.setOrigin( origin );
                        if ( schemes != null && schemes.length != 0 )
                        {
                            if ( Arrays.asList( schemes ).contains( recDistList.getScheme().getLink() ) )
                            {
                                receivedDLList.add( recDistList );
                            }
                        }
                        else
                        {
                            receivedDLList.add( recDistList );
                        }
                        count++;
                    }
                }
            }

            ReceivedDistributionListsResponse receivedDLListResponse = new ReceivedDistributionListsResponse();
            receivedDLListResponse.setDistributionLists( receivedDLList );

            if ( isQuerytoBeBuilt )
            {
                query = buildQuery( graphName, query );
            }
            query = "/v1/received-distribution-lists?q=" + query;
            // set Meta Info
            if ( isPrepareMeta )
            {
                Paging meta = new Paging();
                meta.setLimit( limit );
                meta.setOffset( offset );
                meta.setTotalCount( total );
                receivedDLListResponse.setMeta( meta );
            }
            query = offset > 0 ? query + "%26offset=" + offset : query;
            Response response = client
                    .target( "http://" + HOST_NAME + ":" + PORT )
                    .path( "/mock/responses" )
                    .queryParam( "apiPath", query )
                    // .queryParam( "offset", offset )
                    .request()
                    .put( Entity.entity( receivedDLListResponse, MediaType.APPLICATION_JSON ) );
            System.out.println( "Put Request Response" + response );

        }
        catch ( Exception e )
        {
            LOGGER.error(
                    "MockDistributionListService >> createRecDLMockObjects >> Exception Occured :::::"
                            + e.getMessage() );
        }

    }

    public MockDistributionListService()
    {
        try
        {
            ConfigurationFactory<DashBoardApiConfiguration> configurationFactory = new ConfigurationFactory<>(
                    DashBoardApiConfiguration.class,
                    Validation.buildDefaultValidatorFactory().getValidator(),
                    Jackson.newObjectMapper(),
                    "d" );
            InputStream in = this.getClass().getClassLoader().getResourceAsStream( "dashboard-internal-test.yml" );
            File tempFile = File.createTempFile( "dashboard-internal-test", "tmp" );
            tempFile.deleteOnExit();
            FileOutputStream out = new FileOutputStream( tempFile );
            IOUtils.copy( in, out );

            this.dashBoardApiConfiguration = configurationFactory.build( tempFile );
        }
        catch ( IOException | ConfigurationException ex )
        {
            LOGGER.error( "MockDistributionListService::Exception in building configuration - " + ex.getMessage() );
        }
    }

    public String buildQuery( final String graphType, final String q )
    {
        String query = null;
        switch ( graphType.toUpperCase() )
        {
        case "ACTIONLISTGENERATION":
            query = DashboardViewsImplQueryUtil.buildQuery( dashBoardApiConfiguration.getActionListGeneration(), q );
            break;
        case "ACTIONLISTRECEIVED":
            query = DashboardViewsImplQueryUtil.buildQuery( dashBoardApiConfiguration.getActionListReceived(), q );
            break;
        case "HOTLISTGENERATION":
            query = DashboardViewsImplQueryUtil.buildQuery( dashBoardApiConfiguration.getHotListGeneration(), q );
            break;
        case "HOTLISTRECEIVED":
            query = DashboardViewsImplQueryUtil.buildQuery( dashBoardApiConfiguration.getHotListReceived(), q );
            break;
        case "ACTIONLISTGENERATIONDRILLDOWN":
            query = DashboardViewsImplQueryUtil
                    .buildQuery( dashBoardApiConfiguration.getActionListGenerationDrillDown(), q );
            break;
        case "HOTLISTRECEIVEDDRILLDOWN":
            query = DashboardViewsImplQueryUtil
                    .buildQuery( dashBoardApiConfiguration.getHotListReceivedDrillDown(), q );
            break;
        case "HOTLISTGENERATIONDRILLDOWN":
            query = DashboardViewsImplQueryUtil
                    .buildQuery( dashBoardApiConfiguration.getHotListGenerationDrillDown(), q );
            break;
        default:
            LOGGER.info( "MockDistributionListService::buildQuery:: No case matched - " );
        }
        return query;

    }

}
