package net.weareact.app.mock;

import java.io.IOException;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.dropwizard.configuration.ConfigurationException;
import net.weareact.financial.model.FinancialPeriodsResponse;
import net.weareact.journeys.model.SummaryResponse;

public class MockService
{

    private Client               client    = ClientBuilder.newClient();;
    private static final Integer PORT      = 18080;
    private static final String  HOST_NAME = "localhost";

    public Response mockPostFinancialPeriod(
            FinancialPeriodsResponse financialPeriodResponse,
            String query,
            String financialPeriodBasePath,
            String applicationContextPath ) throws IOException, ConfigurationException
    {

        Response response = client
                .target( "http://" + HOST_NAME + ":" + PORT )
                .path( "/mock/responses" )
                .queryParam( "apiPath", query )
                // .queryParam( "offset", offset )
                .request()
                .put( Entity.entity( financialPeriodResponse, MediaType.APPLICATION_JSON ) );

        return response;
    }

    public Response mockPostSmartSummary(
            SummaryResponse summary,
            String query,
            String nonsmartjourneyBasePath,
            String applicationContextPath ) throws IOException, ConfigurationException
    {

        Response response = client
                .target( "http://" + HOST_NAME + ":" + PORT )
                .path( "/mock/responses" )
                .queryParam( "apiPath", query )
                // .queryParam( "offset", offset )
                .request()
                .put( Entity.entity( summary, MediaType.APPLICATION_JSON ) );

        return response;
    }

}
