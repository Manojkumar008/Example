package net.weareact.cms.stepdefs;

import java.security.KeyStore;
import java.util.List;
import java.util.Map;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.apache.http.HttpStatus;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.weareact.CucumberIT;
import net.weareact.app.DashboardViewsConfiguration;
import net.weareact.app.mock.MockCmsStatusService;
import net.weareact.common.dropwizard.DropwizardUtil;
import net.weareact.jwt.JKSKeyStoreProvider;
import net.weareact.jwt.JWTBuilder;
import net.weareact.jwt.JWTBuilderRSA;
import net.weareact.model.DashboardView;
import net.weareact.model.DashboardViewResponse;
import net.weareact.model.GraphDataPoint;
import net.weareact.model.PointData;
import net.weareact.utils.DVSIntegrationUtil;

public class DashboardViewCmsQueueMessagesGraphStepDef
{
    private static final Logger LOGGER                    = LoggerFactory
                                                                  .getLogger(
                                                                          DashboardViewCmsQueueMessagesGraphStepDef.class
                                                                                  .getName() );

    private static final String API_HOST_NAME             = "localhost";
    private static final String DASH_BOARD_VIEWS_API_PATH = "v1/dashboard-views";
    private static final String JWT_ASSERTION_HEADER      = "X-JWT-Assertion";
    private static final String KEYSTORE_PATH             = "src/test/resources/keystore/actdev.jks";

    private static final String KEYSTORE_PASSWORD         = "actdev";

    private static final String KEYSTORE_ALIAS            = "wso2am.local";

    private static boolean      isCmsServiceSetup         = false;

    private static final Object JWT_TOKEN_VALUE           = "eyJ0eXAiOiJKV1QiLCJ4NXQiOiJNbU15WW1GaVltRTNPV1U0TjJObE5tSmpNVEF4TVdFNE9UY3dNR0V6TnpZMVpHWTNOamN3TnciLCJhbGciOiJSUzI1NiJ9.eyJzY2hlbWVzIjpbeyJhYmJyZXZpYXRpb24iOiJBQ1QxIiwibGluayI6InNjaGVtZXMvMSJ9LHsiYWJicmV2aWF0aW9uIjoiQUNUMiIsImxpbmsiOiJzY2hlbWVzLzIifSx7ImFiYnJldmlhdGlvbiI6IkFDVDMiLCJsaW5rIjoic2NoZW1lcy8zIn0seyJhYmJyZXZpYXRpb24iOiJBQ1Q0IiwibGluayI6InNjaGVtZXMvNCJ9XSwic2NvcGVzIjpbXSwib3JnYW5pc2F0aW9uIjp7fSwiZXhwIjoiOTIyMzM3MjAzNjg1NDc3NTgwNyJ9.Y5w7egYWGuBpmzHEoaQpRw7fZOu1BK5MwfoH_rO0njXQx4OsMYZw7tWnB3vNRO2JKjgT__w9VgY49Mq_J1heuvGVVNgZDxzORWpZUeh2MuzmY1ME6IEhe9-2R1J3SWoj8hJrnjB_ypfNI9W4QNUSwUVoyfNx77boH20Y8akUr8M38vTwI7E5qTVZ_JRjnUIpDV-Bi3bADfNyLo9c_r-ywcsNpeoyTivsI_iIHWbuKl5U0JKtCWmYHmfR-oKR9rwW5AGtKr5i6ap5jJWFxIfre-ffp8DPxxy7NsRIzk6r214fEgNVJvq-QgPobgy-iI9sGt21MDFahBd-SaEBn_IbPg";
    private Response            apiResponse;

    private String              query;
    private static final String START_DATE                = "startDate";
    private static final String END_DATE                  = "endDate";
    private static final String SCHEME_LINK               = "scheme.link";

    private static final String GREATER_THAN_EQUAL        = ">=";
    private static final String LESS_THAN_EQUAL           = "<=";
    private static final String EQUAL                     = "=";
    private static final String IN                        = " IN";
    private static final String AND                       = " AND ";

    private DashboardView       dashboardView;

    @Given( "^cms-status-service is up and runing with following data$" )
    public void cms_status_service_is_up_and_runing_with_following_data( DataTable arg1 ) throws Throwable
    {
        List<Map<String, String>> dataMapList = arg1.asMaps( String.class, String.class );

        new MockCmsStatusService().mockCmsStatuses( dataMapList, null );
    }

    @Given( "^User has access to following schemes as$" )
    public void user_has_access_to_following_schemes_as( DataTable arg1 ) throws Throwable
    {
        final List<Map<String, String>> data = arg1.asMaps( String.class, String.class );
        final KeyStore keyStore = new JKSKeyStoreProvider().getKeyStore( KEYSTORE_PATH, KEYSTORE_PASSWORD );
        JWTBuilder builder = new JWTBuilderRSA( keyStore, KEYSTORE_PASSWORD, KEYSTORE_ALIAS );
        for ( Map<String, String> row : data )
        {
            builder = builder.addProperty(
                    row.get( "name" ),
                    row.get( "value" ),
                    Boolean.parseBoolean( row.get( "array" ) ),
                    Boolean.parseBoolean( row.get( "json" ) ) );

        }
        String jwtToken = builder.build();
        LOGGER.info( " JWT Token Prepared >> Value is - " + jwtToken );
    }

    @When( "^I make request for \"(.*?)\" graph$" )
    public void i_make_request_for_graph( String graphID ) throws Throwable
    {
        apiResponse = callDashBoardService( graphID, null );
        Assert.assertTrue( apiResponse.getStatus() == HttpStatus.SC_OK );
        Thread.sleep( 1000 );
    }

    @Then( "^Response should contains following data$" )
    public void response_should_contains_following_data( String arg1 ) throws Throwable
    {

        DashboardViewResponse response = apiResponse.readEntity( DashboardViewResponse.class );
        dashboardView = response.getDashboardView();
        GraphDataPoint graphDataPoint = dashboardView.getGraphData().get( 1 );

        ObjectMapper mapper = new ObjectMapper();
        GraphDataPoint graphDataPointExpected = mapper.readValue( arg1, GraphDataPoint.class );

        Assert.assertTrue( new DVSIntegrationUtil().comparePointDataList( graphDataPointExpected, graphDataPoint ) );

    }

    private Response callDashBoardService( String graphID, String queryParam ) throws InterruptedException
    {
        DashboardViewsConfiguration configuration = CucumberIT.RULE.getConfiguration();

        int apiHttpPort = DropwizardUtil.getApplicationHttpPort( configuration );

        Client apiClient = ClientBuilder.newClient();
        WebTarget target = apiClient.target(
                "http://" + API_HOST_NAME + ":" + apiHttpPort + "/" + DASH_BOARD_VIEWS_API_PATH + "/" + graphID );

        if ( queryParam != null )
        {
            target = target.queryParam( "q", queryParam );
        }
        apiResponse = target.request().header( JWT_ASSERTION_HEADER, JWT_TOKEN_VALUE ).get();
        Thread.sleep( 1000 );
        return apiResponse;
    }

    @Given( "^user selects time period from \"(.*?)\" to \"(.*?)\"$" )
    public void userSelectsTimePeriod( String startDate, String endDate ) throws Throwable
    {
        query = START_DATE + GREATER_THAN_EQUAL + startDate + AND + END_DATE + LESS_THAN_EQUAL + endDate;
        LOGGER.info( "User selected filter is :- " + query );

    }

    @Given( "^user selects time-period from \"(.*?)\" to \"(.*?)\" and scheme filter as \"(.*?)\"$" )
    public void user_selects_time_period_from_to_and_scheme_filter_as(
            String startDate,
            String endDate,
            String schemes ) throws Throwable
    {
        query = START_DATE
                + GREATER_THAN_EQUAL
                + startDate
                + AND
                + END_DATE
                + LESS_THAN_EQUAL
                + endDate
                + AND
                + SCHEME_LINK
                + IN
                + "("
                + schemes
                + ")";
        LOGGER.info( "User selected time-period and schemes filter is :- " + query );
    }

    @Given( "^cms-status-serivce is running and has following data for above time period$" )
    public void cms_status_serivce_is_running_and_has_following_data_for_above_time_period( DataTable arg1 )
            throws Throwable
    {
        List<Map<String, String>> dataMapList = arg1.asMaps( String.class, String.class );

        new MockCmsStatusService().mockCmsStatuses( dataMapList, query );
    }

    @Given( "^cms-status-service has some past data for above time period for cms \"(.*?)\"$" )
    public void cms_status_service_has_some_past_data_for_above_time_period_for_cms( String cmsName, DataTable data )
            throws Throwable
    {
        List<Map<String, String>> dataMapList = data.asMaps( String.class, String.class );

        new MockCmsStatusService().mockCmsStatusesForAverage( dataMapList, cmsName );
    }

    @When( "^user requests for CMSQUEUEMESSAGES graph with above filter$" )
    public void user_requests_for_CMSQUEUEMESSAGES_graph_with_above_filter() throws Throwable
    {
        apiResponse = callDashBoardService( "CMS_QUEUED_MESSAGES", query );
        Assert.assertTrue( apiResponse.getStatus() == 200 );
        getDashBoardViewFromResponse();
    }

    @Then( "^response contains data for AverageLine and CurrentLine$" )
    public void response_contains_data_for_AverageLine_and_CurrentLine() throws Throwable
    {

        List<GraphDataPoint> graphDataPointList = dashboardView.getGraphData();
        Assert.assertTrue( graphDataPointList.size() == 2 );
    }

    @Then( "^response contains data for AverageLine and CurrentLine for two cmses$" )
    public void response_contains_data_for_AverageLine_and_CurrentLine_for_two_cmses() throws Throwable
    {
        List<GraphDataPoint> graphDataPointList = dashboardView.getGraphData();
        Assert.assertTrue( graphDataPointList.size() == 4 );
    }

    private void getDashBoardViewFromResponse()
    {
        DashboardViewResponse response = apiResponse.readEntity( DashboardViewResponse.class );
        dashboardView = response.getDashboardView();

    }

    @Then( "^AverageLine data has (\\d+) average points for cms no (\\d+)$" )
    public void averageline_data_has_average_points_for_cms_no( int expectedPointDataNumber, int cmsNumber )
            throws Throwable
    {

        int index = cmsNumber == 1 ? 0 : 2;
        GraphDataPoint graphDataPointAverageLine = dashboardView.getGraphData().get( index );
        List<PointData> pointDataList = graphDataPointAverageLine.getDataPointValues();

        Assert.assertTrue( pointDataList.size() == expectedPointDataNumber );

    }

    @Then( "^Value of point (\\d+) in AverageLine is (\\d+) for cms no (\\d+)$" )
    public void value_of_point_in_AverageLine_is_for_cms_no( int pointDataIndex, int value, int cmsNumber )
            throws Throwable
    {

        int index = cmsNumber == 1 ? 0 : 2;
        GraphDataPoint graphDataPointAverageLine = dashboardView.getGraphData().get( index );
        List<PointData> pointDataList = graphDataPointAverageLine.getDataPointValues();

        PointData pointData = pointDataList.get( pointDataIndex - 1 );
        Assert.assertTrue( pointData.getPointValue() == value );

    }

    @Then( "^CurrentLine data has (\\d+) points for cms no (\\d+)$" )
    public void currentline_data_has_points_for_cms_no( int expectedPointDataNumber, int cmsNumber ) throws Throwable
    {
        int index = cmsNumber == 1 ? 1 : 3;
        GraphDataPoint graphDataPointAverageLine = dashboardView.getGraphData().get( index );
        List<PointData> pointDataList = graphDataPointAverageLine.getDataPointValues();
        Assert.assertTrue( pointDataList.size() == expectedPointDataNumber );
    }

    @Then( "^Value of point (\\d+) in CurrentLine is (\\d+) for cms no (\\d+)$" )
    public void value_of_point_in_CurrentLine_is_for_cms_no( int pointDataIndex, int value, int cmsNumber )
            throws Throwable
    {
        int index = cmsNumber == 1 ? 1 : 3;
        GraphDataPoint graphDataPointAverageLine = dashboardView.getGraphData().get( index );
        List<PointData> pointDataList = graphDataPointAverageLine.getDataPointValues();

        PointData pointData = pointDataList.get( pointDataIndex - 1 );
        Assert.assertTrue( pointData.getPointValue() == value );
    }

    @Then( "^point (\\d+) in CurrentLine is \"(.*?)\" for cms no (\\d+)$" )
    public void point_in_CurrentLine_is_for_cms_no( int pointDataIndex, String arg2, int cmsNumber ) throws Throwable
    {
        int index = cmsNumber == 1 ? 1 : 3;
        GraphDataPoint graphDataPointAverageLine = dashboardView.getGraphData().get( index );
        List<PointData> pointDataList = graphDataPointAverageLine.getDataPointValues();

        PointData pointData = pointDataList.get( pointDataIndex - 1 );
        Assert.assertTrue( pointData.getPointLegend().get( "en" ).equals( "cms00".concat( cmsNumber + "-" + arg2 ) ) );
    }

    @Given( "^cms-status-service provides following data for average calculation for cms \"(.*?)\"$" )
    public void cms_status_service_provides_following_data_for_average_calculation_for_cms(
            String cmsName,
            List<Map<String, String>> dataMapList ) throws Throwable
    {

        new MockCmsStatusService().mockCmsStatusesForAverage( dataMapList, cmsName );
    }
}
