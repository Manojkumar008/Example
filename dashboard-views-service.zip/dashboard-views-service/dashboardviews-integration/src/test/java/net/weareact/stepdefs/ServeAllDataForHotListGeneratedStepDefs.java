package net.weareact.stepdefs;

import java.util.List;
import java.util.Map;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.weareact.CucumberIT;
import net.weareact.app.DashboardViewsConfiguration;
import net.weareact.app.mock.MockDistributionListService;
import net.weareact.common.dropwizard.DropwizardUtil;
import net.weareact.dashboardview.model.DistributionList.TypeEnum;
import net.weareact.model.DashboardViewResponse;
import net.weareact.model.GraphDataPoint;
import net.weareact.model.PointData;

/**
 * ServeAllDataForHotListGeneratedStepDefs class defines the Cucumber step definitions for serving all data for
 * HOTLISTGENERATED graph
 * <p>
 * Copyright 2016 Applied Card Technologies Ltd
 *
 * @author patilsan
 */
public class ServeAllDataForHotListGeneratedStepDefs
{

    private static final Logger LOGGER                    = LoggerFactory
                                                                  .getLogger(
                                                                          ServeAllDataForHotListGeneratedStepDefs.class
                                                                                  .getName() );

    private static final String API_HOST_NAME             = "localhost";
    private static final String DASH_BOARD_VIEWS_API_PATH = "v1/dashboard-views";
    private static final String JWT_ASSERTION_HEADER      = "X-JWT-Assertion";

    private static String       JWT_TOKEN_VALUE           = "eyJ0eXAiOiJKV1QiLCJ4NXQiOiJNbU15WW1GaVltRTNPV1U0TjJObE5tSmpNVEF4TVdFNE9UY3dNR0V6TnpZMVpHWTNOamN3TnciLCJhbGciOiJSUzI1NiJ9.eyJzY2hlbWVzIjpbeyJhYmJyZXZpYXRpb24iOiJBQ1QxIiwibGluayI6InNjaGVtZXMvMSJ9LHsiYWJicmV2aWF0aW9uIjoiQUNUMiIsImxpbmsiOiJzY2hlbWVzLzIifSx7ImFiYnJldmlhdGlvbiI6IkFDVDMiLCJsaW5rIjoic2NoZW1lcy8zIn0seyJhYmJyZXZpYXRpb24iOiJBQ1Q0IiwibGluayI6InNjaGVtZXMvNCJ9XSwic2NvcGVzIjpbXSwib3JnYW5pc2F0aW9uIjp7fSwiZXhwIjoiOTIyMzM3MjAzNjg1NDc3NTgwNyJ9.Y5w7egYWGuBpmzHEoaQpRw7fZOu1BK5MwfoH_rO0njXQx4OsMYZw7tWnB3vNRO2JKjgT__w9VgY49Mq_J1heuvGVVNgZDxzORWpZUeh2MuzmY1ME6IEhe9-2R1J3SWoj8hJrnjB_ypfNI9W4QNUSwUVoyfNx77boH20Y8akUr8M38vTwI7E5qTVZ_JRjnUIpDV-Bi3bADfNyLo9c_r-ywcsNpeoyTivsI_iIHWbuKl5U0JKtCWmYHmfR-oKR9rwW5AGtKr5i6ap5jJWFxIfre-ffp8DPxxy7NsRIzk6r214fEgNVJvq-QgPobgy-iI9sGt21MDFahBd-SaEBn_IbPg";
    private static Integer      apiHttpPort;

    private Client              apiClient                 = ClientBuilder.newClient();
    private WebTarget           target;
    private Response            apiResponse;

    private static final String KEYSTORE_PATH             = "src/test/resources/keystore/actdev.jks";

    private static final String KEYSTORE_PASSWORD         = "actdev";

    private static final String KEYSTORE_ALIAS            = "wso2am.local";

    @Given( "^Create DistributionList objects of type HOTLIST, with following properties$" )
    public void create_DistributionList_objects_of_type_HOTLIST_with_following_properties( DataTable arg1 )
            throws Throwable
    {
        List<Map<String, String>> dataMapList = arg1.asMaps( String.class, String.class );
        MockDistributionListService dlService = new MockDistributionListService();
        // dlService.setupDL( dataMapList.size(), dataMapList, TypeEnum.HOTLIST, "HOTLISTGENERATION" );
        dlService.createAndMockDistributionList(
                dataMapList,
                TypeEnum.HOTLIST,
                "HOTLISTGENERATION",
                null,
                true,
                false,
                0L,
                0L,
                0L );
    }

    @When( "^DashboardViews service is called to get data for \"(.*?)\" graph$" )
    public void dashboardviews_service_is_called_to_get_data_for_graph( String graphID ) throws Throwable
    {
        DashboardViewsConfiguration configuration = CucumberIT.RULE.getConfiguration();

        apiHttpPort = DropwizardUtil.getApplicationHttpPort( configuration );

        target = apiClient.target(
                "http://" + API_HOST_NAME + ":" + apiHttpPort + "/" + DASH_BOARD_VIEWS_API_PATH + "/" + graphID );
        apiResponse = target.request().header( JWT_ASSERTION_HEADER, JWT_TOKEN_VALUE ).get();

        Thread.sleep( 2000 );

    }

    @Then( "^Validate the returned data$" )
    public void validate_the_returned_data() throws Throwable
    {

        DashboardViewResponse dashBoardResponse = apiResponse.readEntity( DashboardViewResponse.class );
        List<GraphDataPoint> graphData = dashBoardResponse.getDashboardView().getGraphData();

        Assert.assertNotNull( graphData.get( 0 ).getDataPointLegend() );
        Assert.assertNotNull( graphData.get( 1 ).getDataPointLegend() );
        Assert.assertNotNull( graphData.get( 2 ).getDataPointLegend() );
        Assert.assertNotNull( graphData.get( 3 ).getDataPointLegend() );
        Assert.assertNotNull( graphData.get( 4 ).getDataPointLegend() );

        // Assert datapoint legent
        Assert.assertEquals( "Success", graphData.get( 0 ).getDataPointLegend().get( "en" ) );
        Assert.assertEquals( "Partial", graphData.get( 1 ).getDataPointLegend().get( "en" ) );
        Assert.assertEquals( "Failed", graphData.get( 2 ).getDataPointLegend().get( "en" ) );
        Assert.assertEquals( "Unscheduled", graphData.get( 3 ).getDataPointLegend().get( "en" ) );
        Assert.assertEquals( "Next", graphData.get( 4 ).getDataPointLegend().get( "en" ) );

        // Assert point data legent
        Assert.assertEquals( "Success", graphData.get( 0 ).getDataPointValues().get( 0 ).getPointLegend().get( "en" ) );
        Assert.assertEquals( "Partial", graphData.get( 1 ).getDataPointValues().get( 0 ).getPointLegend().get( "en" ) );
        Assert.assertEquals( "Failed", graphData.get( 2 ).getDataPointValues().get( 0 ).getPointLegend().get( "en" ) );
        Assert.assertEquals(
                "Unscheduled",
                graphData.get( 3 ).getDataPointValues().get( 0 ).getPointLegend().get( "en" ) );
        Assert.assertEquals( "Next", graphData.get( 4 ).getDataPointValues().get( 0 ).getPointLegend().get( "en" ) );

        Object[] successCount =
        { 15000, 0, 0, 0, 0, 0, 12000, 0, 0, 0 };
        Assert.assertArrayEquals(
                successCount,
                graphData.get( 0 ).getDataPointValues().stream().map( PointData::getPointValue ).toArray() );

        Object[] partialCount =
        { 0, 0, 15000, 0, 0, 0, 0, 0, 16000, 0 };
        Assert.assertArrayEquals(
                partialCount,
                graphData.get( 1 ).getDataPointValues().stream().map( PointData::getPointValue ).toArray() );

        Object[] failedCount =
        { 0, 0, 0, 0, 4500, 0, 0, 15500, 0, 0 };
        Assert.assertArrayEquals(
                failedCount,
                graphData.get( 2 ).getDataPointValues().stream().map( PointData::getPointValue ).toArray() );

        Object[] unscheduleCount =
        { 500, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        Assert.assertArrayEquals(
                unscheduleCount,
                graphData.get( 3 ).getDataPointValues().stream().map( PointData::getPointValue ).toArray() );

        Object[] nextCount =
        { 0, 1000, 0, 2000, 0, 3300, 0, 0, 0, 7000 };
        Assert.assertArrayEquals(
                nextCount,
                graphData.get( 4 ).getDataPointValues().stream().map( PointData::getPointValue ).toArray() );

    }

}
