/**
 * Copyright 2015 Applied Card Technologies Ltd
 */
package net.weareact.jwt;

import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateEncodingException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;

public class JWTBuilderRSA extends JWTBuilder
{
    private final KeyStore keyStore;
    private final String   keyPassword;
    private final String   keyAlias;

    public JWTBuilderRSA( final KeyStore keyStore, final String keyPassword, final String keyAlias )
    {
        this.keyStore = keyStore;
        this.keyPassword = keyPassword;
        this.keyAlias = keyAlias;
    }

    @Override
    protected Map<String, String> getHeaders()
    {
        final Map<String, String> headers = new HashMap<>();
        headers.put( "alg", "RS256" );

        try
        {
            final MessageDigest messageDigest = MessageDigest.getInstance( "SHA-1" );
            messageDigest.update( keyStore.getCertificate( keyAlias ).getEncoded() );
            byte[] digest = messageDigest.digest();
            headers.put( "x5t", Base64.encodeBase64URLSafeString( Hex.encodeHexString( digest ).getBytes() ) );
        }
        catch ( NoSuchAlgorithmException | CertificateEncodingException | KeyStoreException ex )
        {
            Logger.getLogger( JWTBuilderRSA.class.getName() ).log( Level.SEVERE, null, ex );
        }

        return headers;
    }

    @Override
    protected byte[] sign( final String jwtPayload ) throws JWTBuilderException
    {
        try
        {
            final PrivateKey key = ( PrivateKey ) keyStore.getKey( keyAlias, keyPassword.toCharArray() );

            final Signature signature = Signature.getInstance( "SHA256withRSA" );
            signature.initSign( key );
            signature.update( jwtPayload.getBytes() );
            return signature.sign();
        }
        catch (
                KeyStoreException
                | NoSuchAlgorithmException
                | UnrecoverableKeyException
                | InvalidKeyException
                | SignatureException ex )
        {
            throw new JWTBuilderException( ex );
        }
    }
}
