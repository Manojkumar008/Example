/**
 * Copyright 2015 Applied Card Technologies Ltd
 */
package net.weareact.jwt;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;

import net.weareact.common.dropwizard.security.ResourceLink;

/**
 *
 * @author alexs
 */
public abstract class JWTBuilder
{
    private final Map<String, List<Object>> arrayProperties = new HashMap<>();

    private final Map<String, Object>       properties      = new HashMap<>();

    private final JsonObject                headerObj       = new JsonObject();

    private final Gson                      gson            = new Gson();

    public JWTBuilder()
    {
        properties.put( "organisation", new ResourceLink() );
        arrayProperties.put( "schemes", new ArrayList<>() );
        arrayProperties.put( "scopes", new ArrayList<>() );
    }

    public JWTBuilder addProperty( String name, Object value, boolean array, boolean json )
    {
        if ( json )
        {
            JsonParser parser = new JsonParser();

            value = parser.parse( ( String ) value );
        }

        if ( array )
        {
            List<Object> values = arrayProperties.get( name );

            if ( values == null )
            {
                values = new ArrayList<>();

                arrayProperties.put( name, values );
            }

            values.add( value );
        }
        else
        {
            properties.put( name, value );
        }

        return this;
    }

    public String build() throws Exception
    {
        JsonObject root = new JsonObject();

        addArrayProperties( root );

        addProperties( root );

        headerObj.addProperty( "typ", "JWT" );
        getHeaders().forEach( headerObj::addProperty );

        String header = gson.toJson( headerObj ).replaceAll( "\\s+", "" );
        String body = gson.toJson( root ).replaceAll( "\\s+", "" );

        String jwtPayload = Base64.encodeBase64URLSafeString( header.getBytes() )
                + "."
                + Base64.encodeBase64URLSafeString( body.getBytes() );

        String signature = Base64.encodeBase64URLSafeString( sign( jwtPayload ) );

        return jwtPayload + "." + signature;
    }

    private void addArrayProperties( JsonObject root )
    {
        arrayProperties.entrySet().stream().forEach( ( entry ) ->
        {
            JsonArray array = ( JsonArray ) gson.toJsonTree( entry.getValue(), new TypeToken<List<Object>>()
            {
            }.getType() );

            root.add( entry.getKey(), array );
        } );
    }

    private void addProperties( JsonObject root )
    {
        properties.entrySet().stream().forEach( ( entry ) ->
        {
            root.add( entry.getKey(), gson.toJsonTree( entry.getValue() ) );
        } );
    }

    protected Map<String, String> getHeaders()
    {
        return new HashMap<>();
    }

    protected abstract byte[] sign( final String jwtPayload ) throws JWTBuilderException;
}
