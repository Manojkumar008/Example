/**
 * HotListReceivedDrillDownStepDef.
 * Copyright 2016 Applied Card Technologies Ltd
 */
package net.weareact.drilldown.stepdefs;

import java.security.KeyStore;
import java.util.List;
import java.util.Map;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.weareact.CucumberIT;
import net.weareact.app.DashboardViewsConfiguration;
import net.weareact.app.mock.MockDistributionListService;
import net.weareact.common.dropwizard.DropwizardUtil;
import net.weareact.jwt.JKSKeyStoreProvider;
import net.weareact.jwt.JWTBuilder;
import net.weareact.jwt.JWTBuilderRSA;
import net.weareact.model.DashboardView;
import net.weareact.model.DashboardViewResponse;
import net.weareact.model.GraphDataPoint;
import net.weareact.utils.DVSIntegrationUtil;

/**
 * Step Definition test various scenarios for "HOTLISTRECEIVEDDRILLDOWN" Graph by hitting the DashBoardViews API
 * Endpoint.
 * 
 * @author Atul Tripathi
 */
public class HotListReceivedDrillDownStepDef
{
    private Client                apiClient                 = ClientBuilder.newClient();
    private WebTarget             target;
    private Response              apiResponse;

    private static final String   API_HOST_NAME             = "localhost";
    private static final String   DASH_BOARD_VIEWS_API_PATH = "v1/dashboard-views";
    private static final String   JWT_ASSERTION_HEADER      = "X-JWT-Assertion";
    private static String         JWT_TOKEN_VALUE           = "";

    private static Integer        apiHttpPort;

    private DashboardViewResponse dashboardViewResponse;
    private DashboardView         dashboardView;

    private static final String   KEYSTORE_PATH             = "src/test/resources/keystore/actdev.jks";

    private static final String   KEYSTORE_PASSWORD         = "actdev";

    private static final String   KEYSTORE_ALIAS            = "wso2am.local";

    private static final Logger   LOGGER                    = LoggerFactory
                                                                    .getLogger(
                                                                            HotListReceivedDrillDownStepDef.class
                                                                                    .getName() );

    /**
     * Get API Http Port using DropwizardUtil
     */
    public HotListReceivedDrillDownStepDef()
    {
        DashboardViewsConfiguration dashboardViewConfiguration = CucumberIT.RULE.getConfiguration();
        apiHttpPort = DropwizardUtil.getApplicationHttpPort( dashboardViewConfiguration );
        LOGGER.info( "Constructor HotListReceivedDrillDownStepDef:: apiHttpPort - " + apiHttpPort );
    }

    /**
     * Method mocks Objects at given end point (passed queryParam from feature file)
     * 
     * @param graphName
     *            - This is used to build appropriate query
     * @param queryParam
     * @param dataTable
     */
    @Given( "^that I mock Received HotList objects for \"(.*?)\" Graph at the endpoint \"(.*?)\" with following properties:$" )
    public void mockReceivedHotListObjects( String graphName, String queryParam, DataTable dataTable )
    {
        List<Map<String, String>> dataMapList = dataTable.asMaps( String.class, String.class );

        // Just to differentiate as same method is being used to mock for time filter and time & scheme filter
        // Feature file will have more schemes but only schemes in array will be inserted.
        String[] schemeArray = null;
        if ( queryParam.contains( "scheme.link IN" ) )
        {
            schemeArray = new String[]
            { "/schemes/010e45cc-b9e0-11e5-9912-ba0be0483c11", "/schemes/020e45cc-b9e0-11e5-9912-ba0be0483c12" };
        }

        // if schemeArray!=null -> then only those objects will be mocked/created which matches schemes in array
        // This is to demonstrate scheme filter for HOTLIST Received Drill Down Graph
        new MockDistributionListService().createAndMockReceivedDistributionList(
                dataMapList,
                net.weareact.dashboardview.model.ReceivedDistributionList.TypeEnum.HOTLIST,
                graphName,
                queryParam,
                schemeArray,
                true,
                false,
                0L,
                0L,
                0L );
        LOGGER.info( "Method mockReceivedHotListObjects:: Received HotList Mock Objects Created " );
    }

    @Given( "^User has access to following given schemes:$" )
    public void mockJWTToken( DataTable arg1 ) throws Throwable
    {
        final List<Map<String, String>> data = arg1.asMaps( String.class, String.class );
        final KeyStore keyStore = new JKSKeyStoreProvider().getKeyStore( KEYSTORE_PATH, KEYSTORE_PASSWORD );
        JWTBuilder builder = new JWTBuilderRSA( keyStore, KEYSTORE_PASSWORD, KEYSTORE_ALIAS );
        for ( Map<String, String> row : data )
        {
            builder = builder.addProperty(
                    row.get( "name" ),
                    row.get( "value" ),
                    Boolean.parseBoolean( row.get( "array" ) ),
                    Boolean.parseBoolean( row.get( "json" ) ) );

        }
        JWT_TOKEN_VALUE = builder.build();

        LOGGER.info( " Method::mockJWTToken >> Value is - " + JWT_TOKEN_VALUE );
    }

    /**
     * Method calls Dashboard API, same will be used for time period filter and time & scheme filters
     * 
     * @param graphName
     * @param dataMap
     */
    @When( "^make a call for \"(.*?)\" Graph with following properties :$" )
    public void callDashboardAPI( String graphName, Map<String, String> dataMap )
    {

        String queryParam = "startDate>="
                + dataMap.get( "startdate" )
                + " AND endDate<="
                + dataMap.get( "enddate" )
                + " AND time="
                + dataMap.get( "time" );

        // Just to differentiate as same method is being used to mock for time filter and time & scheme filter
        if ( dataMap.containsKey( "scheme1" ) )
        {
            queryParam = queryParam
                    + " AND scheme.link IN("
                    + dataMap.get( "scheme1" )
                    + ","
                    + dataMap.get( "scheme2" )
                    + ")";
        }

        LOGGER.info(
                "Method callDashboardAPI:: Calling Dashboard API Endpoint for HotListReceivedDrillDownGraph:: queryParam is - "
                        + queryParam );

        target = apiClient
                .target( "http://" + API_HOST_NAME + ":" + apiHttpPort + "/" + DASH_BOARD_VIEWS_API_PATH + "/" )
                .path( graphName )
                .queryParam( "q", queryParam );

        apiResponse = target.request().header( JWT_ASSERTION_HEADER, JWT_TOKEN_VALUE ).get();
        dashboardViewResponse = apiResponse.readEntity( DashboardViewResponse.class );
        this.dashboardView = dashboardViewResponse.getDashboardView();

        LOGGER.info(
                "Method callDashboardAPI:: Calling Dashboard API Endpoint for HotListReceivedDrillDownGraph:: dashboardView response returned successfully" );
    }

    /**
     * Method asserts status code against API Response Status
     * 
     * @param statusCode
     * @throws Throwable
     */
    @Then( "^api response for HotList Received Drill Down Graph should be (\\d+)$" )
    public void assertAPIStatus( int statusCode ) throws Throwable
    {
        Assert.assertEquals( statusCode, apiResponse.getStatus() );
    }

    @Then( "^List<GraphData> for HotList received should be returned with following properties as:$" )
    public void assertDashboardAPIResponse( String expectedGraphData ) throws Throwable
    {

        LOGGER.info( "Method assertDashboardAPIResponse:: Asserting dashboardView response against expected outcome" );
        JSONArray jsonArray = new JSONArray( expectedGraphData );

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure( DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false );
        for ( int i = 0; i < jsonArray.length(); i++ )
        {
            GraphDataPoint graphDataPointExpected = mapper
                    .readValue( jsonArray.getJSONObject( i ).toString(), GraphDataPoint.class );

            Assert.assertTrue(
                    new DVSIntegrationUtil()
                            .comparePointDataList( graphDataPointExpected, dashboardView.getGraphData().get( i ) ) );
        }
        LOGGER.info( "Method assertDashboardAPIResponse:: Assertion Done!!!!" );

    }

    /**
     * Method asserts expected outcome against API Response
     * 
     * @param expectedGraphData
     * @throws Throwable
     */
    @Then( "^List<GraphData> for HotListReceived Drill Down Graph with scheme filter should be returned with following properties as:$" )
    public void assertDashboardAPIResponseWithSchemeFilters( String expectedGraphData ) throws Throwable
    {
        LOGGER.info(
                "Method assertDashboardAPIResponseWithSchemeFilters:: Asserting dashboardView response against expected outcome for success legend" );
        DVSIntegrationUtil dvsUtil = new DVSIntegrationUtil();
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure( DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false );
        GraphDataPoint graphDataPointExpected = mapper.readValue( expectedGraphData, GraphDataPoint.class );

        GraphDataPoint graphDataPointActual = dashboardView.getGraphData().get( 1 );

        Assert.assertTrue( dvsUtil.comparePointDataList( graphDataPointExpected, graphDataPointActual ) );
        LOGGER.info(
                "Method assertDashboardAPIResponse:: Assertion against expected outcome for success legend Done!!!!" );
    }

}
