package net.weareact.stepdefs;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.Map;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.weareact.CucumberIT;
import net.weareact.app.DashboardViewsConfiguration;
import net.weareact.app.mock.MockDistributionListService;
import net.weareact.common.dropwizard.DropwizardUtil;
import net.weareact.dashboardview.model.DistributionList.TypeEnum;
import net.weareact.model.DashboardView;
import net.weareact.model.DashboardViewResponse;
import net.weareact.model.GraphDataPoint;
import net.weareact.model.PointData;
import net.weareact.utils.DVSIntegrationUtil;

public class FilterForACTIONLISTGENERATE
{
    private static final Logger   LOGGER                    = LoggerFactory
                                                                    .getLogger(
                                                                            FilterForACTIONLISTGENERATE.class
                                                                                    .getCanonicalName() );

    private static final String   API_HOST_NAME             = "localhost";
    private static final String   DASH_BOARD_VIEWS_API_PATH = "v1/dashboard-views";
    private static final String   JWT_ASSERTION_HEADER      = "X-JWT-Assertion";
    private static String         JWT_TOKEN_VALUE           = "eyJ0eXAiOiJKV1QiLCJ4NXQiOiJNbU15WW1GaVltRTNPV1U0TjJObE5tSmpNVEF4TVdFNE9UY3dNR0V6TnpZMVpHWTNOamN3TnciLCJhbGciOiJSUzI1NiJ9.eyJzY2hlbWVzIjpbeyJhYmJyZXZpYXRpb24iOiJBQ1QxIiwibGluayI6InNjaGVtZXMvMSJ9LHsiYWJicmV2aWF0aW9uIjoiQUNUMiIsImxpbmsiOiJzY2hlbWVzLzIifSx7ImFiYnJldmlhdGlvbiI6IkFDVDMiLCJsaW5rIjoic2NoZW1lcy8zIn0seyJhYmJyZXZpYXRpb24iOiJBQ1Q0IiwibGluayI6InNjaGVtZXMvNCJ9XSwic2NvcGVzIjpbXSwib3JnYW5pc2F0aW9uIjp7fSwiZXhwIjoiOTIyMzM3MjAzNjg1NDc3NTgwNyJ9.Y5w7egYWGuBpmzHEoaQpRw7fZOu1BK5MwfoH_rO0njXQx4OsMYZw7tWnB3vNRO2JKjgT__w9VgY49Mq_J1heuvGVVNgZDxzORWpZUeh2MuzmY1ME6IEhe9-2R1J3SWoj8hJrnjB_ypfNI9W4QNUSwUVoyfNx77boH20Y8akUr8M38vTwI7E5qTVZ_JRjnUIpDV-Bi3bADfNyLo9c_r-ywcsNpeoyTivsI_iIHWbuKl5U0JKtCWmYHmfR-oKR9rwW5AGtKr5i6ap5jJWFxIfre-ffp8DPxxy7NsRIzk6r214fEgNVJvq-QgPobgy-iI9sGt21MDFahBd-SaEBn_IbPg";

    private static Integer        apiHttpPort;
    private Client                apiClient                 = ClientBuilder.newClient();
    private WebTarget             target;
    private Response              apiResponse;
    private DashboardViewResponse dashboardViewResponse;
    private DashboardView         dashboardView;
    MockDistributionListService   dlService                 = new MockDistributionListService();

    public FilterForACTIONLISTGENERATE()
    {
        DashboardViewsConfiguration dashboardViewConfiguration = CucumberIT.RULE.getConfiguration();
        apiHttpPort = DropwizardUtil.getApplicationHttpPort( dashboardViewConfiguration );
        LOGGER.info( "Constructor FilterForACTIONLISTGENERATE:: apiHttpPort - " + apiHttpPort );
    }

    @Given( "^that I mock Generated ActionList objects at the endpoint \"(.*?)\" with the following properties :$" )
    public void that_I_mock_Generated_ActionList_objects_at_the_endpoint_with_the_following_properties(
            String q,
            DataTable table ) throws Throwable
    {

        LOGGER.info( "Creating test data for " + q );
        List<Map<String, String>> dataMapList = table.asMaps( String.class, String.class );

        // dlService.mockAndPutALData( q, dataMapList );

        dlService.createAndMockDistributionList(
                dataMapList,
                TypeEnum.ACTIONLIST,
                "ACTIONLISTGENERATION",
                q,
                true,
                false,
                0L,
                0L,
                0L );

    }

    @Given( "^that the Distribution List mock service is running with the test data stored$" )
    public void that_the_Distribution_List_mock_service_is_running_with_the_test_data_stored() throws Throwable
    {
        LOGGER.info( " DL Mock service is running " );
    }

    @Given( "^the DashboardView service is running$" )
    public void the_DashboardView_service_is_running() throws Throwable
    {
        LOGGER.info( "Dashboard service is running" );
    }

    @When( "^I make a request to the DashboardView service for the graph \"(.*?)\" and filter on the following schemes:$" )
    public void i_make_a_request_to_the_DashboardView_service_for_the_graph_and_filter_on_the_following_schemes(
            String graphName,
            List<String> dataTable ) throws Throwable
    {
        // data table has scheme filter values. Create a scheme query
        String q = "scheme.link IN(" + StringUtils.join( dataTable, "," ) + ")";

        // Make a request to the dashboard views service passing this as the q param value
        target = apiClient
                .target( "http://" + API_HOST_NAME + ":" + apiHttpPort + "/" + DASH_BOARD_VIEWS_API_PATH + "/" )
                .path( graphName )
                .queryParam( "q", q );
        apiResponse = target.request().header( JWT_ASSERTION_HEADER, JWT_TOKEN_VALUE ).get();

        // Get the Dashboard View response and store it
        dashboardViewResponse = apiResponse.readEntity( DashboardViewResponse.class );
        this.dashboardView = dashboardViewResponse.getDashboardView();
    }

    @Then( "^I should get a successful response with (\\d+) values$" )
    public void i_should_get_a_successful_response_with_values( int arg1 ) throws Throwable
    {
        // Check that the stored Dashboard View response has the correct number of values
        // There should be 5 graph data returned for Action List Generated graph - one each for
        // Success, Failed, Unscheduled, Partial and Next Action Lists
        assertEquals( dashboardView.getGraphData().size(), arg1 );
        LOGGER.info( dashboardView.toString() );
    }

    @Then( "^the response should have data with the following values :$" )
    public void the_response_should_have_data_with_the_following_values( List<PointData> listPointData )
            throws Throwable
    {
        // Check that the Graph Data returned has the values that we are expecting
        listPointData.stream().forEach( pd -> LOGGER.info( pd.toString() ) );
        for ( int i = 0; i < listPointData.size(); i++ )
            assertEquals(
                    listPointData.get( i ).getPointValue(),
                    dashboardView.getGraphData().get( 0 ).getDataPointValues().get( i ).getPointValue() );

    }

    @When( "^I make a request to the DashboardView service for the graph \"(.*?)\" and filter by <startdate> and <enddate>$" )
    public void i_make_a_request_to_the_DashboardView_service_for_the_graph_and_filter_by_startdate_and_enddate(
            String graphName,
            Map<String, String> dataTable ) throws Throwable
    {
        // The data Table has start and end date times now. Make a time query
        String q = "startDate >=" + dataTable.get( "startdate" ) + " AND endDate <=" + dataTable.get( "enddate" );

        // Make a request to the dashboard views service passing this as the q param value
        target = apiClient
                .target( "http://" + API_HOST_NAME + ":" + apiHttpPort + "/" + DASH_BOARD_VIEWS_API_PATH + "/" )
                .path( graphName )
                .queryParam( "q", q );

        // GET the Dashboard View response and store it
        apiResponse = target.request().header( JWT_ASSERTION_HEADER, JWT_TOKEN_VALUE ).get();

        dashboardViewResponse = apiResponse.readEntity( DashboardViewResponse.class );
        this.dashboardView = dashboardViewResponse.getDashboardView();
    }

    @When( "^I make a request to the DashboardView service for the graph \"(.*?)\" and filter by the following <scheme> and by <startdate> and <enddate>$" )
    public void i_make_a_request_to_the_DashboardView_service_for_the_graph_and_filter_by_the_following_scheme_and_by_startdate_and_enddate(
            String graphName,
            Map<String, String> dataTable ) throws Throwable
    {
        // The data Table has scheme, start and end date times now. Make a full query query
        String q = "scheme.link IN("
                + dataTable.get( "scheme" )
                + ")"
                + " AND startDate >="
                + dataTable.get( "startdate" )
                + " AND endDate <="
                + dataTable.get( "enddate" );
        ;

        // Make a request to the dashboard views service passing this as the q param value
        target = apiClient
                .target( "http://" + API_HOST_NAME + ":" + apiHttpPort + "/" + DASH_BOARD_VIEWS_API_PATH + "/" )
                .path( graphName )
                .queryParam( "q", q );

        // GET the Dashboard View response and store it
        apiResponse = target.request().header( JWT_ASSERTION_HEADER, JWT_TOKEN_VALUE ).get();
        dashboardViewResponse = apiResponse.readEntity( DashboardViewResponse.class );
        this.dashboardView = dashboardViewResponse.getDashboardView();
    }

    @Then( "^the response should have data with the following json values :$" )
    public void the_response_should_have_data_with_the_following_json_values( String arg1 ) throws Throwable
    {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure( DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false );
        GraphDataPoint graphDataPointExpected = mapper.readValue( arg1, GraphDataPoint.class );

        GraphDataPoint graphDataPointActual = dashboardView.getGraphData().get( 0 );

        DVSIntegrationUtil util = new DVSIntegrationUtil();
        Assert.assertTrue( util.comparePointDataList( graphDataPointExpected, graphDataPointActual ) );
    }
}
