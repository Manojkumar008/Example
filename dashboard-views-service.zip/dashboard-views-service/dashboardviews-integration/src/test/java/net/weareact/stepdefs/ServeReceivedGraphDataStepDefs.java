/*
 * ************************************************************************** Copyright 2016 Applied Card Technologies
 * Ltd
 ****************************************************************************/

package net.weareact.stepdefs;

import java.security.KeyStore;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.weareact.CucumberIT;
import net.weareact.app.DashboardViewsConfiguration;
import net.weareact.app.mock.MockDistributionListService;
import net.weareact.common.dropwizard.DropwizardUtil;
import net.weareact.dashboardview.model.ReceivedDistributionList.TypeEnum;
import net.weareact.jwt.JKSKeyStoreProvider;
import net.weareact.jwt.JWTBuilder;
import net.weareact.jwt.JWTBuilderRSA;
import net.weareact.model.DashboardViewResponse;
import net.weareact.model.GraphDataPoint;
import net.weareact.model.PointData;

public class ServeReceivedGraphDataStepDefs
{

    private static final Logger LOGGER                    = LoggerFactory
                                                                  .getLogger(
                                                                          ServeReceivedGraphDataStepDefs.class
                                                                                  .getName() );

    private static final String API_HOST_NAME             = "localhost";
    private static final String DASH_BOARD_VIEWS_API_PATH = "v1/dashboard-views";
    private static final String JWT_ASSERTION_HEADER      = "X-JWT-Assertion";

    private static String       JWT_TOKEN_VALUE           = "";
    private static Integer      apiHttpPort;

    private Client              apiClient                 = ClientBuilder.newClient();
    private WebTarget           target;
    private Response            apiResponse;

    private static final String KEYSTORE_PATH             = "src/test/resources/keystore/actdev.jks";

    private static final String KEYSTORE_PASSWORD         = "actdev";

    private static final String KEYSTORE_ALIAS            = "wso2am.local";

    @Given( "^ReceivedDistributionList objects are inserted with following properties:$" )
    public void receiveddistributionlist_objects_are_inserted_with_following_properties( final DataTable dataTable )
            throws Throwable
    {
        List<Map<String, String>> dataMapList = dataTable.asMaps( String.class, String.class );
        MockDistributionListService dlService = new MockDistributionListService();
        dlService.createAndMockReceivedDistributionList(
                dataMapList,
                TypeEnum.ACTIONLIST,
                "ACTIONLISTRECEIVED",
                null,
                null,
                true,
                false,
                0L,
                0L,
                0L );
        LOGGER.info( "ServeReceivedGraphDataStepDefs >> Mock Objects Created ::::::::::" );
    }

    @Given( "^prepare jwt token with following schemes:$" )
    public void prepare_jwt_token_with_following_schemes( final DataTable arg1 ) throws Throwable
    {
        final List<Map<String, String>> data = arg1.asMaps( String.class, String.class );
        final KeyStore keyStore = new JKSKeyStoreProvider().getKeyStore( KEYSTORE_PATH, KEYSTORE_PASSWORD );
        JWTBuilder builder = new JWTBuilderRSA( keyStore, KEYSTORE_PASSWORD, KEYSTORE_ALIAS );
        for ( Map<String, String> row : data )
        {
            builder = builder.addProperty(
                    row.get( "name" ),
                    row.get( "value" ),
                    Boolean.parseBoolean( row.get( "array" ) ),
                    Boolean.parseBoolean( row.get( "json" ) ) );

        }
        JWT_TOKEN_VALUE = builder.build();
        LOGGER.info( "ServeReceivedGraphDataStepDefs >> JWT Token Prepared ::::::::::" );
    }

    @When( "^I make a call to Dashboard API for \"(.*?)\" Status graph$" )
    public void i_make_a_call_to_Dashboard_API_for_Status_graph( final String graphName ) throws Throwable
    {
        LOGGER.info( "ServeReceivedGraphDataStepDefs >> Call Action List Received ::::::::::" );

        DashboardViewsConfiguration configuration = CucumberIT.RULE.getConfiguration();

        apiHttpPort = DropwizardUtil.getApplicationHttpPort( configuration );

        LOGGER.info( " ServeReceivedGraphDataStepDefs >> calling API with Graph Name as ::::::::::" + graphName );

        target = apiClient.target(
                "http://" + API_HOST_NAME + ":" + apiHttpPort + "/" + DASH_BOARD_VIEWS_API_PATH + "/" + graphName );
        apiResponse = target.request().header( JWT_ASSERTION_HEADER, JWT_TOKEN_VALUE ).get();

        LOGGER.info(
                " ServeReceivedGraphDataStepDefs >> calling API with Graph Name as :"
                        + graphName
                        + " response status is :::::"
                        + apiResponse.getStatus() );

        Thread.sleep( 2000 );
    }

    @Then( "^Following data should be returned:$" )
    public void following_data_should_be_returned( final DataTable dataTable ) throws Throwable
    {
        // Build expected response
        String dateTimeStr = "";

        ZonedDateTime tempDate = ZonedDateTime.now();
        String dateStr = tempDate.getYear()
                + "-"
                + String.format( "%02d", tempDate.getMonthValue() )
                + "-"
                + String.format( "%02d", tempDate.getDayOfMonth() );

        List<Map<String, String>> dataMapList = dataTable.asMaps( String.class, String.class );

        List<String> pointKeyList = new ArrayList<>();
        List<Integer> pointValueList = new ArrayList<>();

        for ( Map<String, String> map : dataMapList )
        {
            if ( !map.isEmpty() )
            {
                String pointKey = map.get( "Point_Key" ).trim();

                dateTimeStr = dateStr + pointKey;
                pointKeyList.add( dateTimeStr );

                String pointValue = map.get( "Point_Value" ).trim();
                pointValueList.add( Integer.valueOf( pointValue ) );
            }
        }

        DashboardViewResponse dashBoardResponse = apiResponse.readEntity( DashboardViewResponse.class );
        List<GraphDataPoint> graphDataList = dashBoardResponse.getDashboardView().getGraphData();
        LOGGER.info( "ServeReceivedGraphDataStepDefs >> graphDataList reterived from dashBoardResponse:::::" );

        // Assert Data [-> GraphDataPoint Object Contains dataPointLegend(String) and dataPointValues(List<PointData>)]

        /*
         * Assert Data Point Legend
         */
        GraphDataPoint dataPointObj = graphDataList.get( 0 );

        Map<String, String> legendMap = dataPointObj.getDataPointLegend();

        Assert.assertNotNull( legendMap );
        // Assert.assertEquals( "successful", legendMap );

        /*
         * Assert all keys and aggregated values
         */
        List<PointData> dataPointValues = dataPointObj.getDataPointValues();

        int actualKeyArraySize = dataPointValues.stream().map( PointData::getPointKey ).toArray().length;

        Object[] pointKeyArray = pointKeyList.toArray();
        int expectedKeyArraySize = pointKeyArray.length;

        Object[] pointValueArray = pointValueList.toArray();

        Assert.assertEquals( expectedKeyArraySize, actualKeyArraySize );
        Assert.assertArrayEquals( pointValueArray, dataPointValues.stream().map( PointData::getPointValue ).toArray() );

        LOGGER.info( "ServeReceivedGraphDataStepDefs >> Data Assertion Done ::::::::::" );
    }
}
