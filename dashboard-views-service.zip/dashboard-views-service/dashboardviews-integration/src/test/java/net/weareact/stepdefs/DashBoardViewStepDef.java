package net.weareact.stepdefs;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.weareact.CucumberIT;
import net.weareact.app.DashboardViewsConfiguration;
import net.weareact.app.mock.MockDistributionListService;
import net.weareact.common.dropwizard.DropwizardUtil;
import net.weareact.dashboardview.model.DistributionList.TypeEnum;
import net.weareact.model.DashboardViewResponse;
import net.weareact.model.GraphDataPoint;

public class DashBoardViewStepDef
{

    private static final Logger LOGGER                    = LoggerFactory
                                                                  .getLogger( DashBoardViewStepDef.class.getName() );

    private static final String API_HOST_NAME             = "localhost";
    private static final String DASH_BOARD_VIEWS_API_PATH = "v1/dashboard-views";
    private static final String JWT_ASSERTION_HEADER      = "X-JWT-Assertion";
    private static String       JWT_TOKEN_VALUE           = "eyJ0eXAiOiJKV1QiLCJ4NXQiOiJNbU15WW1GaVltRTNPV1U0TjJObE5tSmpNVEF4TVdFNE9UY3dNR0V6TnpZMVpHWTNOamN3TnciLCJhbGciOiJSUzI1NiJ9.eyJzY2hlbWVzIjpbeyJhYmJyZXZpYXRpb24iOiJBQ1QxIiwibGluayI6InNjaGVtZXMvMSJ9LHsiYWJicmV2aWF0aW9uIjoiQUNUMiIsImxpbmsiOiJzY2hlbWVzLzIifSx7ImFiYnJldmlhdGlvbiI6IkFDVDMiLCJsaW5rIjoic2NoZW1lcy8zIn0seyJhYmJyZXZpYXRpb24iOiJBQ1Q0IiwibGluayI6InNjaGVtZXMvNCJ9XSwic2NvcGVzIjpbXSwib3JnYW5pc2F0aW9uIjp7fSwiZXhwIjoiOTIyMzM3MjAzNjg1NDc3NTgwNyJ9.Y5w7egYWGuBpmzHEoaQpRw7fZOu1BK5MwfoH_rO0njXQx4OsMYZw7tWnB3vNRO2JKjgT__w9VgY49Mq_J1heuvGVVNgZDxzORWpZUeh2MuzmY1ME6IEhe9-2R1J3SWoj8hJrnjB_ypfNI9W4QNUSwUVoyfNx77boH20Y8akUr8M38vTwI7E5qTVZ_JRjnUIpDV-Bi3bADfNyLo9c_r-ywcsNpeoyTivsI_iIHWbuKl5U0JKtCWmYHmfR-oKR9rwW5AGtKr5i6ap5jJWFxIfre-ffp8DPxxy7NsRIzk6r214fEgNVJvq-QgPobgy-iI9sGt21MDFahBd-SaEBn_IbPg";

    private static Integer      apiHttpPort;

    private Client              apiClient                 = ClientBuilder.newClient();
    private WebTarget           target;
    private Response            apiResponse;

    public DashBoardViewStepDef()
    {
        DashboardViewsConfiguration dashboardViewConfiguration = CucumberIT.RULE.getConfiguration();
        apiHttpPort = DropwizardUtil.getApplicationHttpPort( dashboardViewConfiguration );
        LOGGER.info( "Constructor DashBoardViewStepDef:: apiHttpPort - " + apiHttpPort );
    }

    @Given( "^the  DistributionList service is running and has the following data:$" )
    public void the_DistributionList_service_is_running_and_has_the_following_data( final DataTable table )
            throws Throwable
    {

        List<Map<String, String>> dataMapList = table.asMaps( String.class, String.class );
        MockDistributionListService dlService = new MockDistributionListService();
        // dlService.setupDL( dataMapList.size(), dataMapList, TypeEnum.ACTIONLIST, "ACTIONLISTGENERATION" );
        dlService.createAndMockDistributionList(
                dataMapList,
                TypeEnum.ACTIONLIST,
                "ACTIONLISTGENERATION",
                null,
                true,
                false,
                0L,
                0L,
                Long.valueOf( dataMapList.size() ) );

    }

    @Given( "^the  DistributionList service is running and has the following data and limit is set to \"(.*?)\":$" )
    public void the_DistributionList_service_is_running_and_has_the_following_data_and_limit_is_set_to(
            final String limit,
            final DataTable table ) throws Throwable
    {
        List<Map<String, String>> dataMapList = table.asMaps( String.class, String.class );
        MockDistributionListService dlService = new MockDistributionListService();
        // dlService.setupDL( dataMapList.size(), dataMapList, TypeEnum.ACTIONLIST, "ACTIONLISTGENERATION" );
        List<Map<String, String>> tempMap = new ArrayList<>();
        tempMap.add( dataMapList.get( 0 ) );
        tempMap.add( dataMapList.get( 1 ) );
        tempMap.add( dataMapList.get( 2 ) );
        dlService.createAndMockDistributionList(
                tempMap,
                TypeEnum.ACTIONLIST,
                "ACTIONLISTGENERATION",
                null,
                true,
                true,
                Long.valueOf( limit ),
                0L,
                Long.valueOf( dataMapList.size() ) );
        tempMap = new ArrayList<>();
        tempMap.add( dataMapList.get( 3 ) );
        tempMap.add( dataMapList.get( 4 ) );
        tempMap.add( dataMapList.get( 5 ) );
        dlService.createAndMockDistributionList(
                tempMap,
                TypeEnum.ACTIONLIST,
                "ACTIONLISTGENERATION",
                null,
                true,
                true,
                Long.valueOf( limit ),
                1 * Long.valueOf( limit ),
                Long.valueOf( dataMapList.size() ) );
        tempMap = new ArrayList<>();
        tempMap.add( dataMapList.get( 6 ) );
        tempMap.add( dataMapList.get( 7 ) );
        tempMap.add( dataMapList.get( 8 ) );
        dlService.createAndMockDistributionList(
                tempMap,
                TypeEnum.ACTIONLIST,
                "ACTIONLISTGENERATION",
                null,
                true,
                true,
                Long.valueOf( limit ),
                2 * Long.valueOf( limit ),
                Long.valueOf( dataMapList.size() ) );
        tempMap = new ArrayList<>();
        tempMap.add( dataMapList.get( 9 ) );
        tempMap.add( dataMapList.get( 10 ) );
        tempMap.add( dataMapList.get( 11 ) );
        dlService.createAndMockDistributionList(
                tempMap,
                TypeEnum.ACTIONLIST,
                "ACTIONLISTGENERATION",
                null,
                true,
                true,
                Long.valueOf( limit ),
                3 * Long.valueOf( limit ),
                Long.valueOf( dataMapList.size() ) );
        tempMap = new ArrayList<>();
        tempMap.add( dataMapList.get( 12 ) );
        dlService.createAndMockDistributionList(
                tempMap,
                TypeEnum.ACTIONLIST,
                "ACTIONLISTGENERATION",
                null,
                true,
                true,
                Long.valueOf( limit ),
                4 * Long.valueOf( limit ),
                Long.valueOf( dataMapList.size() ) );
    }

    @Given( "^the Dashboard view application is running$" )
    public void the_Dashboard_view_application_is_running() throws Throwable
    {

        LOGGER.info( "GetReceivedDistributionListsSteps >> received Distribution List API is running ::::::::::" );

    }

    @When( "^make a call to DVS for \"(.*?)\" Status gragh$" )
    public void make_a_call_to_DVS_for_Status_gragh( final String graphID ) throws Throwable
    {

        DashboardViewsConfiguration configuration = CucumberIT.RULE.getConfiguration();

        apiHttpPort = DropwizardUtil.getApplicationHttpPort( configuration );

        LOGGER.info( " DashBOard  views>> Default  API calls ::::::::::" );

        target = apiClient.target(
                "http://" + API_HOST_NAME + ":" + apiHttpPort + "/" + DASH_BOARD_VIEWS_API_PATH + "/" + graphID );
        apiResponse = target.request().header( JWT_ASSERTION_HEADER, JWT_TOKEN_VALUE ).get();

        Thread.sleep( 2000 );
    }

    @Then( "^API respose status should be \"(.*?)\"$" )
    public void api_respose_status_should_be( final String statusCode ) throws Throwable
    {
        LOGGER.info(
                "GetReceivedDistributionListsSteps >> Get all records from API >> api response status should be ::::::::::"
                        + statusCode );
        assertEquals( Integer.valueOf( statusCode ).intValue(), apiResponse.getStatus() );
    }

    @Then( "^then the DashBoardView Service should return the response\\.$" )
    public void then_the_DashBoardView_Service_should_return_the_response( final DataTable table ) throws Throwable
    {

        DashboardViewResponse dashBoardResponse = apiResponse.readEntity( DashboardViewResponse.class );
        List<GraphDataPoint> graphData = dashBoardResponse.getDashboardView().getGraphData();

        assertTrue( graphData instanceof List<?> );
        assertTrue( graphData.get( 0 ) instanceof GraphDataPoint );

        List<Map<String, String>> expectedOutcomeMap = table.asMaps( String.class, String.class );

        for ( Map<String, String> map : expectedOutcomeMap )
        {

            String pointLegend = map.get( "pointLegend" );
            String[] pointValueAsArray = map.get( "pointValueAsArray" ).split( "," );
            Arrays.asList( pointValueAsArray ).stream().mapToInt( Integer::parseInt ).toArray();
            switch ( pointLegend.toLowerCase() )
            {
            case "successful":
                // assertEquals("successful",graphData.get( 0 ).getDataPointLegend());
                // assertEquals(Arrays.toString(cycu),Arrays.toString(graphData.get( 0
                // ).getDataPointValues().stream().map(PointData :: getPointValue).toArray()));
                break;

            case "partial":
                // assertEquals("partial",graphData.get( 1 ).getDataPointLegend());
                // assertEquals(Arrays.toString(cycu),Arrays.toString(graphData.get( 1
                // ).getDataPointValues().stream().map(PointData :: getPointValue).toArray()));
                break;

            case "failed":
                // assertEquals("failed",graphData.get( 2 ).getDataPointLegend());
                // assertEquals(Arrays.toString(cycu),Arrays.toString(graphData.get( 2
                // ).getDataPointValues().stream().map(PointData :: getPointValue).toArray()));
                break;

            case "unschedule":
                // assertEquals("unschedule",graphData.get( 3 ).getDataPointLegend());
                // assertEquals(Arrays.toString(cycu),Arrays.toString(graphData.get(3
                // ).getDataPointValues().stream().map(PointData :: getPointValue).toArray()));
                break;

            case "next":
                // assertEquals("next",graphData.get( 4 ).getDataPointLegend());
                // assertEquals(Arrays.toString(cycu),Arrays.toString(graphData.get(4
                // ).getDataPointValues().stream().map(PointData :: getPointValue).toArray()));
                break;

            }

        }

    }

}
