/**
 * Copyright 2015 Applied Card Technologies Ltd
 */
package net.weareact.utils;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.reflect.ClassPath;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.spi.json.JacksonJsonNodeJsonProvider;
import com.jayway.jsonpath.spi.mapper.JacksonMappingProvider;

public class EntityBuilder
{
    private String                    packageName;
    private String                    className;

    private final Map<String, Object> propertyMap = new HashMap<>();

    public String getPackageName()
    {
        return packageName;
    }

    public EntityBuilder setPackageName( String packageName )
    {
        this.packageName = packageName;
        return this;
    }

    public String getClassName()
    {
        return className;
    }

    public EntityBuilder setClassName( final String className )
    {
        this.className = className;
        return this;
    }

    public EntityBuilder addProperty( final String name, final Object value )
    {
        propertyMap.put( name, value );
        return this;
    }

    public JsonNode build() throws Exception
    {
        final ClassPath.ClassInfo entityClassInfo = ClassPath
                .from( Thread.currentThread().getContextClassLoader() )
                .getTopLevelClassesRecursive( packageName )
                .stream()
                .filter( classInfo -> classInfo.getSimpleName().equals( className ) )
                .distinct()
                .findFirst()
                .get();

        final Object entity = entityClassInfo.load().newInstance();

        applyProperties( entity );

        return new ObjectMapper().valueToTree( entity );
    }

    private void applyProperties( final Object entity )
    {
        final ObjectMapper objectMapper = new ObjectMapper();

        final Configuration configuration = Configuration
                .builder()
                .jsonProvider( new JacksonJsonNodeJsonProvider() )
                .mappingProvider( new JacksonMappingProvider( objectMapper ) )
                .build();

        propertyMap.forEach( ( fieldPath, value ) ->
        {
            try
            {
                final JsonNode updatedJson = JsonPath
                        .using( configuration )
                        .parse( objectMapper.writeValueAsString( entity ) )
                        .set( fieldPath, value )
                        .json();

                objectMapper.readerForUpdating( entity ).readValue( updatedJson );
            }
            catch ( final IOException ex )
            {
                throw new RuntimeException( ex );
            }
        } );
    }
}
