/**
 * Copyright 2015 Applied Card Technologies Ltd
 */
package net.weareact.jwt;

import java.nio.charset.Charset;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class JWTBuilderSecret extends JWTBuilder
{
    private final byte[] secret;

    public JWTBuilderSecret( final String secret ) throws Exception
    {
        this.secret = secret.getBytes( Charset.defaultCharset() );
    }

    @Override
    protected Map<String, String> getHeaders()
    {
        return new HashMap<String, String>()
        {
            {
                put( "alg", "HS256" );
            }
        };
    }

    @Override
    protected byte[] sign( final String jwtPayload ) throws JWTBuilderException
    {
        try
        {
            Mac mac = Mac.getInstance( "HmacSHA256" );

            mac.init( new SecretKeySpec( secret, "HmacSHA256" ) );

            return mac.doFinal( jwtPayload.getBytes() );
        }
        catch ( NoSuchAlgorithmException | InvalidKeyException ex )
        {
            throw new JWTBuilderException( ex );
        }
    }
}
