/* **************************************************************************
 *             Copyright 2010 Applied Card Technologies Ltd
 *
 * What : ServeGraghDataStepDefs
 * Who  : kuyatega
 * When : Jan 27, 2016
 *
 * Source control
 *		$Revision: 91803 $
 *		$Author: markh2 $
 *		$Date: 2012-11-12 14:00:56 +0000 (Mon, 12 Nov 2012) $
 *
 ****************************************************************************/

package net.weareact.stepdefs;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

import javax.validation.Validation;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.dropwizard.configuration.ConfigurationFactory;
import io.dropwizard.jackson.Jackson;
import net.weareact.api.impl.DistributionListToGraphDataForTopLevelGraph;
import net.weareact.api.impl.config.DashBoardApiConfiguration;
import net.weareact.api.impl.utils.DashboardViewsImplQueryUtil;
import net.weareact.api.impl.utils.DashboardViewsImplUtil;
import net.weareact.app.mock.MockDistributionListService;
import net.weareact.dashboardview.model.DistributionList;
import net.weareact.dashboardview.model.DistributionList.TypeEnum;
import net.weareact.dashboardview.model.DistributionListsResponse;
import net.weareact.model.GraphDataPoint;
import net.weareact.model.PointData;

public class ServeGraphDataStepDefs
{
    private static String             esIndexName = "distributionlist";
    private static Integer            esHttpPort  = 9200;
    private static String             esHost      = "localhost";
    private Client                    apiClient   = ClientBuilder.newClient();
    private WebTarget                 target;
    private Response                  apiResponse;
    private List<DistributionList>    distributionList;
    private DistributionListsResponse dlResponse;

    private static final Logger       LOGGER      = LoggerFactory.getLogger( ServeGraphDataStepDefs.class.getName() );

    @Given( "^Clear existing data$" )
    public void clear_existing_data() throws Throwable
    {

        LOGGER.info( "ServeGraghDataStepDefs >> Clear existing data ::::::::::" );

    }

    @Given( "^the  DistributionList objects of ActionList type are  inserted  with following properties:$" )
    public void the_DistributionList_objects_of_ActionList_type_are_inserted_with_following_properties(
            DataTable table ) throws Throwable
    {
        LOGGER.info( "ServeGraghDataStepDefs >> create_Test_Data ::::::::::" );
        List<Map<String, String>> dataMapList = table.asMaps( String.class, String.class );

        try
        {
            // create fresh test data
            MockDistributionListService dlService = new MockDistributionListService();
            // dlService.setupDL( dataMapList.size(), dataMapList, TypeEnum.ACTIONLIST, "ACTIONLISTGENERATION" );
            dlService.createAndMockDistributionList(
                    dataMapList,
                    TypeEnum.ACTIONLIST,
                    "ACTIONLISTGENERATION",
                    null,
                    true,
                    false,
                    0L,
                    0L,
                    0L );

        }

        catch ( Exception e )
        {
            LOGGER.error( "ServeGraghDataStepDefs >> Exception in getConfigValues ::::::::::" + e.getMessage() );
            e.printStackTrace();
        }

    }

    @Given( "^Distribution List Service is running$" )
    public void distribution_List_Service_is_running() throws Throwable
    {
        LOGGER.info( "ServeGraghDataStepDefs >> DL Application Running ::::::::::" );

    }

    @When( "^make a call for ActionList Generation Status gragh$" )
    public void make_a_call_for_ActionList_Generation_Status_gragh() throws Throwable
    {

        LOGGER.info( "ServeGraghDataStepDefs >>make req::::::::::" );
    }

    @Then( "^then the List<GraghData> should be returned with following properties as:$" )
    public void then_the_List_GraghData_should_be_returned_with_following_properties_as() throws Throwable
    {

        ConfigurationFactory<DashBoardApiConfiguration> configurationFactory = new ConfigurationFactory(
                DashBoardApiConfiguration.class,
                Validation.buildDefaultValidatorFactory().getValidator(),
                Jackson.newObjectMapper(),
                "d" );
        InputStream in = this.getClass().getClassLoader().getResourceAsStream( "dashboard-internal-test.yml" );
        File tempFile = File.createTempFile( "dashboard-internal-test", "tmp" );
        tempFile.deleteOnExit();
        FileOutputStream out = new FileOutputStream( tempFile );
        IOUtils.copy( in, out );

        DashBoardApiConfiguration dashBoardApiConfiguration = configurationFactory.build( tempFile );
        DistributionListToGraphDataForTopLevelGraph retriveGraghData = new DistributionListToGraphDataForTopLevelGraph();
        DashboardViewsImplUtil util = new DashboardViewsImplUtil( dashBoardApiConfiguration );

        String query = DashboardViewsImplQueryUtil
                .buildQuery( dashBoardApiConfiguration.getActionListGeneration(), null );

        // String query = dlQueryBuilder.build( "ACTIONLISTGENERATION", null );
        apiResponse = apiClient
                .target( "http://localhost:18080/v1/distribution-lists" )
                .queryParam( "q", query )
                // .queryParam( "offset", 0 )
                .request()
                .get();
        dlResponse = apiResponse.readEntity( DistributionListsResponse.class );
        distributionList = dlResponse.getDistributionLists();
        distributionList = util.filterDLResponse( distributionList );

        List<GraphDataPoint> graghDataList = retriveGraghData
                .splitDistributionListByTime( distributionList, dashBoardApiConfiguration.getActionListGeneration() );

        Assert.assertNotNull( graghDataList.get( 0 ).getDataPointLegend() );
        Assert.assertNotNull( graghDataList.get( 1 ).getDataPointLegend() );
        Assert.assertNotNull( graghDataList.get( 2 ).getDataPointLegend() );
        Assert.assertNotNull( graghDataList.get( 3 ).getDataPointLegend() );
        Assert.assertNotNull( graghDataList.get( 4 ).getDataPointLegend() );

        // Assert datapoint legent
        Assert.assertEquals( "Success", graghDataList.get( 0 ).getDataPointLegend().get( "en" ) );
        Assert.assertEquals( "Partial", graghDataList.get( 1 ).getDataPointLegend().get( "en" ) );
        Assert.assertEquals( "Failed", graghDataList.get( 2 ).getDataPointLegend().get( "en" ) );
        Assert.assertEquals( "Unscheduled", graghDataList.get( 3 ).getDataPointLegend().get( "en" ) );
        Assert.assertEquals( "Next", graghDataList.get( 4 ).getDataPointLegend().get( "en" ) );

        // Assert point data legent
        Assert.assertEquals(
                "Success",
                graghDataList.get( 0 ).getDataPointValues().get( 0 ).getPointLegend().get( "en" ) );
        Assert.assertEquals(
                "Partial",
                graghDataList.get( 1 ).getDataPointValues().get( 0 ).getPointLegend().get( "en" ) );
        Assert.assertEquals(
                "Failed",
                graghDataList.get( 2 ).getDataPointValues().get( 0 ).getPointLegend().get( "en" ) );
        Assert.assertEquals(
                "Unscheduled",
                graghDataList.get( 3 ).getDataPointValues().get( 0 ).getPointLegend().get( "en" ) );
        Assert.assertEquals(
                "Next",
                graghDataList.get( 4 ).getDataPointValues().get( 0 ).getPointLegend().get( "en" ) );

        Object[] successCount =
        { 15000, 0, 0, 0, 0, 0, 12000, 0, 0, 0 };
        Assert.assertArrayEquals(
                successCount,
                graghDataList.get( 0 ).getDataPointValues().stream().map( PointData::getPointValue ).toArray() );

        Object[] partialCount =
        { 0, 0, 15000, 0, 0, 0, 0, 0, 16000, 0 };
        Assert.assertArrayEquals(
                partialCount,
                graghDataList.get( 1 ).getDataPointValues().stream().map( PointData::getPointValue ).toArray() );

        Object[] failedCount =
        { 0, 0, 0, 0, 4500, 0, 0, 15500, 0, 0 };
        Assert.assertArrayEquals(
                failedCount,
                graghDataList.get( 2 ).getDataPointValues().stream().map( PointData::getPointValue ).toArray() );

        Object[] unscheduleCount =
        { 500, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        Assert.assertArrayEquals(
                unscheduleCount,
                graghDataList.get( 3 ).getDataPointValues().stream().map( PointData::getPointValue ).toArray() );

        Object[] nextCount =
        { 0, 1000, 0, 2000, 0, 3300, 0, 0, 0, 7000 };
        Assert.assertArrayEquals(
                nextCount,
                graghDataList.get( 4 ).getDataPointValues().stream().map( PointData::getPointValue ).toArray() );

    }
}
