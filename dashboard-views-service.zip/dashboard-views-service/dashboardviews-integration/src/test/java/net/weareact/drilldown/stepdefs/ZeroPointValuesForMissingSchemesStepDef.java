package net.weareact.drilldown.stepdefs;

import java.security.KeyStore;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.weareact.app.mock.MockDistributionListService;
import net.weareact.dashboardview.model.DistributionList.TypeEnum;
import net.weareact.jwt.JKSKeyStoreProvider;
import net.weareact.jwt.JWTBuilder;
import net.weareact.jwt.JWTBuilderRSA;
import net.weareact.model.DashboardView;
import net.weareact.model.DashboardViewResponse;
import net.weareact.model.GraphDataPoint;
import net.weareact.utils.DVSIntegrationUtil;

public class ZeroPointValuesForMissingSchemesStepDef
{

    private Client                apiClient                 = ClientBuilder.newClient();
    private WebTarget             target;
    private Response              apiResponse;

    private static final String   API_HOST_NAME             = "localhost";
    private static final String   DASH_BOARD_VIEWS_API_PATH = "v1/dashboard-views";

    private static final String   JWT_ASSERTION_HEADER      = "X-JWT-Assertion";
    private static String         JWT_TOKEN_VALUE           = "";

    private static Integer        apiHttpPort               = 18090;

    private DashboardViewResponse dashboardViewResponse;
    private DashboardView         dashboardView;

    private static final String   KEYSTORE_PATH             = "src/test/resources/keystore/actdev.jks";

    private static final String   KEYSTORE_PASSWORD         = "actdev";

    private static final String   KEYSTORE_ALIAS            = "wso2am.local";

    private static final Logger   LOGGER                    = LoggerFactory
                                                                    .getLogger(
                                                                            ZeroPointValuesForMissingSchemesStepDef.class
                                                                                    .getName() );

    @Given( "^that I mock \"(.*?)\" objects for \"(.*?)\" graph at following endpoint \"(.*?)\" with below properties:$" )
    public void mockSchemeAndDLObjects( String type, String graphId, String q, DataTable dataTable ) throws Throwable
    {
        LOGGER.info( "Method::mockSchemeAndDLObjects >> Mock for [" + graphId + "] at following endpoint [" + q + "]" );
        List<Map<String, String>> dataMapList = dataTable.asMaps( String.class, String.class );

        MockDistributionListService dlService = new MockDistributionListService();
        dlService.createAndMockDistributionList(
                dataMapList,
                TypeEnum.valueOf( type ),
                graphId,
                q,
                true,
                false,
                0L,
                0L,
                0L );
    }

    @Given( "^that I mock \"(.*?)\" objects for \"(.*?)\" graph at following endpoint \"(.*?)\" with below given properties:$" )
    public void mockFilteredSchemeAndDLObjects( String type, String graphId, String q, DataTable dataTable )
            throws Throwable
    {
        LOGGER.info( "Method::mockSchemeAndDLObjects >> Mock for [" + graphId + "] at following endpoint [" + q + "]" );
        List<Map<String, String>> dataMapList = dataTable.asMaps( String.class, String.class );

        List<Map<String, String>> filteredDataMapList = dataMapList
                .stream()
                .filter( map -> !map.get( "schemelink" ).trim().equals( "schemes/3" ) )
                .collect( Collectors.toList() );

        MockDistributionListService dlService = new MockDistributionListService();
        dlService.createAndMockDistributionList(
                filteredDataMapList,
                TypeEnum.valueOf( type ),
                graphId,
                q,
                true,
                false,
                0L,
                0L,
                0L );
    }

    @Given( "^User has access to following schemes:$" )
    public void mockJWTToken( DataTable arg1 ) throws Throwable
    {
        final List<Map<String, String>> data = arg1.asMaps( String.class, String.class );
        final KeyStore keyStore = new JKSKeyStoreProvider().getKeyStore( KEYSTORE_PATH, KEYSTORE_PASSWORD );
        JWTBuilder builder = new JWTBuilderRSA( keyStore, KEYSTORE_PASSWORD, KEYSTORE_ALIAS );
        for ( Map<String, String> row : data )
        {
            builder = builder.addProperty(
                    row.get( "name" ),
                    row.get( "value" ),
                    Boolean.parseBoolean( row.get( "array" ) ),
                    Boolean.parseBoolean( row.get( "json" ) ) );

        }
        JWT_TOKEN_VALUE = builder.build();

        LOGGER.info( " Method::mockJWTToken >> Value is - " + JWT_TOKEN_VALUE );
    }

    @When( "^I make call to DashboarViewsService for \"(.*?)\" graph with below properties:$" )
    public void callDashboarViewsServiceForGivenGraph( String graphId, DataTable dataTable ) throws Throwable
    {
        LOGGER.info(
                "Method::callDashboarViewsServiceForGivenGraph >> Call Dashboard Service for Graph [" + graphId + "]" );
        Map<String, String> dataMap = dataTable.asMap( String.class, String.class );
        String query = "startDate>="
                + dataMap.get( "startdate" )
                + " AND endDate<="
                + dataMap.get( "enddate" )
                + " AND time="
                + dataMap.get( "time" );

        if ( dataMap.get( "scheme" ) != null && !dataMap.get( "scheme" ).isEmpty() )
        {
            query = query + " AND scheme.link IN(" + dataMap.get( "scheme" ) + ")";

        }

        target = apiClient
                .target( "http://" + API_HOST_NAME + ":" + apiHttpPort + "/" + DASH_BOARD_VIEWS_API_PATH + "/" )
                .path( graphId )
                .queryParam( "q", query );
        apiResponse = target.request().header( JWT_ASSERTION_HEADER, JWT_TOKEN_VALUE ).get();
        LOGGER.info(
                "Method::callDashboarViewsServiceForGivenGraph >> Called Dashboard Service >> apiResponse is ["
                        + apiResponse
                        + "]" );

        dashboardViewResponse = apiResponse.readEntity( DashboardViewResponse.class );
        this.dashboardView = dashboardViewResponse.getDashboardView();
    }

    @Then( "^API Response Status for HotListGenerationDrillDown Graph should be (\\d+)$" )
    public void assertAPIResponseStatus( int statusCode ) throws Throwable
    {
        LOGGER.info( "Method::assertAPIResponseStatus >> Assert dashboardView response against expected outcome" );
        Assert.assertEquals( statusCode, apiResponse.getStatus() );
    }

    @Then( "^List<GraphData> for HotList Generation should be returned with following properties:$" )
    public void assertAPIResponseData( String expectedGraphData ) throws Throwable
    {
        LOGGER.info( "Method::assertAPIResponseData >> Assert dashboardView response against expected outcome" );
        JSONArray jsonArray = new JSONArray( expectedGraphData );

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure( DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false );

        for ( int i = 0; i < jsonArray.length(); i++ )
        {

            GraphDataPoint graphDataPointExpected = mapper
                    .readValue( jsonArray.getJSONObject( i ).toString(), GraphDataPoint.class );

            Assert.assertTrue(
                    new DVSIntegrationUtil()
                            .comparePointDataList( graphDataPointExpected, dashboardView.getGraphData().get( i ) ) );
        }
        LOGGER.info(
                "Method::assertAPIResponseData >> Assert dashboardView response against expected outcome - Done!!!!" );
    }

}
