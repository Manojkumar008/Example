
package net.weareact.app.mock;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Validation;
import javax.ws.rs.core.Response;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.dropwizard.configuration.ConfigurationException;
import io.dropwizard.configuration.ConfigurationFactory;
import io.dropwizard.jackson.Jackson;
import net.weareact.api.impl.config.DashBoardApiConfiguration;
import net.weareact.journeys.model.GroupSummary;
import net.weareact.journeys.model.Notification;
import net.weareact.journeys.model.Notification.TypeEnum;
import net.weareact.journeys.model.SummaryMeta;
import net.weareact.journeys.model.SummaryResponse;

public class MockSmartJourneyService
{
    private static final Logger       LOGGER                  = LoggerFactory
            .getLogger( MockSmartJourneyService.class.getName() );
    private DashBoardApiConfiguration dashBoardApiConfiguration;

    private MockService               smartJourneyMockService = new MockService();

    public MockSmartJourneyService()
    {
        try
        {
            ConfigurationFactory<DashBoardApiConfiguration> configurationFactory = new ConfigurationFactory<>(
                    DashBoardApiConfiguration.class,
                    Validation.buildDefaultValidatorFactory().getValidator(),
                    Jackson.newObjectMapper(),
                    "d" );
            InputStream in = this.getClass().getClassLoader().getResourceAsStream( "dashboard-internal-test.yml" );
            File tempFile = File.createTempFile( "dashboard-internal-test", "tmp" );
            tempFile.deleteOnExit();
            FileOutputStream out = new FileOutputStream( tempFile );
            IOUtils.copy( in, out );

            this.dashBoardApiConfiguration = configurationFactory.build( tempFile );
        }
        catch ( IOException | ConfigurationException ex )
        {
            LOGGER.error( "MockDistributionListService::Exception in building configuration - " + ex.getMessage() );
        }
    };

    public void createMockDataForSummary(
            String query,
            List<Map<String, Integer>> normalPriceValueMapList,
            String smartjourneyBasePath,
            String applicationContextPath ) throws IOException, ConfigurationException
    {
        // List<Map<String, String>> listOfMaps = dataTable.asMaps( String.class, String.class );
        SummaryResponse summaryResponse = new SummaryResponse();

        SummaryMeta meta = new SummaryMeta();
        meta.setQuery( query );
        meta.setTimeOfExecution( new Date() );

        List<Notification> listOfNotification = new ArrayList<>();
        Notification notification = new Notification();
        notification.setId( "Mock_" + Math.random() );
        notification.setSubject( "Group Summary" );
        notification.setPayload( null );
        notification.setType( TypeEnum.MESSAGE );

        listOfNotification.add( notification );
        // ImmutableMap immutableMap = new ImmutableMap<String, Integer>();
        @SuppressWarnings( "unused" )
        Map<String, Integer> map = new HashMap<>();

        /*
         * GroupSummary groupSummary = new GroupSummary().total( 19 ).subGroups( ImmutableMap.of( "5000", new
         * GroupSummary().total( 17 ), "7500", new GroupSummary().total( 2 ) ) );
         */
        Map<String, GroupSummary> subGroups = new HashMap<>();
        int total = 0;
        for ( Map<String, Integer> normalPriceValue : normalPriceValueMapList )
        {
            total = total + normalPriceValue.get( "totalCount" );
            subGroups.put(
                    normalPriceValue.get( "normalPrice" ).toString(),
                    new GroupSummary().total( normalPriceValue.get( "totalCount" ) ) );
        }
        GroupSummary groupSummary = new GroupSummary();
        groupSummary.setTotal( total );
        groupSummary.setSubGroups( subGroups );
        summaryResponse.setMeta( meta );
        summaryResponse.setSummary( groupSummary );
        summaryResponse.setNotifications( listOfNotification );

        Response mockPostResponse = smartJourneyMockService
                .mockPostSmartSummary( summaryResponse, query, smartjourneyBasePath, applicationContextPath );

        LOGGER.info( "mockPostResponse: " + mockPostResponse );
    }

}
