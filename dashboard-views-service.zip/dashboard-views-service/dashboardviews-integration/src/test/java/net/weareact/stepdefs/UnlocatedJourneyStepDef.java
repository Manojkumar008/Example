package net.weareact.stepdefs;

import java.security.KeyStore;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.weareact.app.mock.MockDistributionListService;
import net.weareact.app.mock.MockFinancialPeriodService;
import net.weareact.app.mock.MockSmartJourneyService;
import net.weareact.dashboardview.model.DistributionList.TypeEnum;
import net.weareact.financial.model.FinancialPeriod;
import net.weareact.financial.model.SchemeLink;
import net.weareact.jwt.JKSKeyStoreProvider;
import net.weareact.jwt.JWTBuilder;
import net.weareact.jwt.JWTBuilderRSA;
import net.weareact.model.DashboardView;
import net.weareact.model.DashboardViewResponse;
import net.weareact.model.GraphDataPoint;
import net.weareact.utils.DVSIntegrationUtil;

public class UnlocatedJourneyStepDef
{

    private Client                apiClient                 = ClientBuilder.newClient();
    private WebTarget             target;
    private Response              apiResponse;

    private static final String   API_HOST_NAME             = "localhost";
    private static final String   DASH_BOARD_VIEWS_API_PATH = "v1/dashboard-views";
    private static final String   JWT_ASSERTION_HEADER      = "X-JWT-Assertion";
    private static String         JWT_TOKEN_VALUE           = "eyJ0eXAiOiJKV1QiLCJ4NXQiOiJNbU15WW1GaVltRTNPV1U0TjJObE5tSmpNVEF4TVdFNE9UY3dNR0V6TnpZMVpHWTNOamN3TnciLCJhbGciOiJSUzI1NiJ9.eyJzY2hlbWVzIjpbeyJhYmJyZXZpYXRpb24iOiJBQ1QxIiwibGluayI6Ii9zY2hlbWVzL3NjaGVtZTEifSx7ImFiYnJldmlhdGlvbiI6IkFDVDIiLCJsaW5rIjoiL3NjaGVtZXMvc2NoZW1lMiJ9LHsiYWJicmV2aWF0aW9uIjoiQUNUMyIsImxpbmsiOiIvc2NoZW1lcy9zY2hlbWUzIn1dLCJzY29wZXMiOltdLCJvcmdhbmlzYXRpb24iOnt9LCJleHAiOiI5MjIzMzcyMDM2ODU0Nzc1ODA3In0.uR6SMUvbZsfTLi9NJXhacro6hjT3bOM1-zNa3ff6NulpqWnrd3_rAVUqIIXR3dFuT45lNjBiCu4hCS7P9DXRB60dfIprbQ0L81Vqo-jZz3jOC1ZgpKR53dLFPOXYsXX37yfT2odgOSb162LJsaUuU2MebQ3uVNz52QidQdN9Cy24GEcaA_rpw2QxpLW8Cj47GtrXr_eBjwu8OO_diFfmUskk6NOkc04Qvgw0ks5BHpZomwaJF54J13UR1WOHhCmnbltGNs8IH-yPWIsVDH6zJWoVECC4OpXnl0yASlFZaaOiXV9ex51RamtIqBbvKSNAcwU1GkBZ3eOWSSJA7HVzlQ";

    private static Integer        apiHttpPort               = 18090;

    private static final String   KEYSTORE_PATH             = "src/test/resources/keystore/actdev.jks";

    private static final String   KEYSTORE_PASSWORD         = "actdev";

    private static final String   KEYSTORE_ALIAS            = "wso2am.local";
    private DashboardViewResponse dashboardViewResponse;
    private DashboardView         dashboardView;

    private static final Logger   LOGGER                    = LoggerFactory
            .getLogger( UnlocatedJourneyStepDef.class.getName() );

    @Given( "^that I mock \"(.*?)\" objects for \"(.*?)\" graphs$" )
    public void that_I_mock_objects_for_graphs( String arg1, String arg2, DataTable table ) throws Throwable
    {

        LOGGER.info( "FinancialPeriodsStatusSteps >> create_Test_Data ::::::::::" );
        List<Map<String, String>> mapList = table.asMaps( String.class, String.class );
        List<FinancialPeriod> listOfFinancialPeriod = new ArrayList<>();
        String query = "";
        String fpLink = "";
        String contextPath = "";
        for ( Map<String, String> map : mapList )
        {
            SchemeLink scheme = new SchemeLink();
            scheme.setAbbreviation( map.get( "scheme.abbreviation" ) );
            scheme.setLink( map.get( "scheme.link" ) );
            FinancialPeriod fp = new FinancialPeriod();
            fp.setLength( map.get( "Length" ) );
            fp.setLengthUnit( FinancialPeriod.LengthUnitEnum.QUARTERS );
            fp.setNumberOfOccurrences( Integer.parseInt( map.get( "numberOfOccurrences" ) ) );
            fp.setScheme( scheme );

            fp.setStartDate( ZonedDateTime.parse( map.get( "startDate" ) ) );
            fp.setEndDate( ZonedDateTime.parse( map.get( "endDate" ) ) );
            fp.setStatus( FinancialPeriod.StatusEnum.ACTIVE );
            fp.setId( "ABCDEF" );
            fp.setName( map.get( "name" ) );
            fp.setPeriod( Integer.valueOf( map.get( "period" ) ) );
            fp.thisOccurrence( Integer.parseInt( map.get( "thisOccurrence" ) ) );
            fp.setDisplayEndDate( ZonedDateTime.parse( map.get( "displayEndDate" ) ) );
            int numberOfTimes = 1;
            query = "/v1/financial-periods?q=scheme.link=" + map.get( "scheme.link" );
            listOfFinancialPeriod.add( fp );
            fpLink = map.get( "financial-period-link" );

            contextPath = map.get( "applicationContextPath" );
        }

        MockFinancialPeriodService mockservice = new MockFinancialPeriodService();
        mockservice.createMockDataForFinancialPeriod( listOfFinancialPeriod, query, fpLink, contextPath );
    }

    @Given( "^User has access to following given schemes Data:$" )
    public void user_has_access_to_following_given_schemes_Data( DataTable arg1 ) throws Throwable
    {

        final List<Map<String, String>> data = arg1.asMaps( String.class, String.class );
        final KeyStore keyStore = new JKSKeyStoreProvider().getKeyStore( KEYSTORE_PATH, KEYSTORE_PASSWORD );
        JWTBuilder builder = new JWTBuilderRSA( keyStore, KEYSTORE_PASSWORD, KEYSTORE_ALIAS );
        for ( Map<String, String> row : data )
        {
            builder = builder.addProperty(
                    row.get( "name" ),
                    row.get( "value" ),
                    Boolean.parseBoolean( row.get( "array" ) ),
                    Boolean.parseBoolean( row.get( "json" ) ) );

        }
        JWT_TOKEN_VALUE = builder.build();

        LOGGER.info( " Method::mockJWTToken >> Value is - " + JWT_TOKEN_VALUE );

    }

    @Given( "^that I mock \"(.*?)\" object for \"(.*?)\" graphs:$" )
    public void that_I_mock_object_for_graphs( String arg1, String arg2, DataTable table ) throws Throwable
    {
        MockSmartJourneyService mockSmartJourneyService = new MockSmartJourneyService();
        String query = "";
        List<Map<String, Integer>> journeyValueMapList = new ArrayList();
        List<Map<String, String>> dataMapList = table.asMaps( String.class, String.class );

        for ( Map<String, String> values : dataMapList )
        {
            Map<String, Integer> normalPriceValueMap = new HashMap<>();
            normalPriceValueMap.put( "normalPrice", Integer.parseInt( values.get( "NormalPrice" ) ) );
            normalPriceValueMap.put( "totalCount", Integer.parseInt( values.get( "TotalCount" ) ) );
            journeyValueMapList.add( normalPriceValueMap );

            // String query = " q=startDateTime" >=2016-01-01T04:40:00Z AND startDateTime <= 2018-01-01T04:40:00Z;

        }
        for ( int i = 0; i < dataMapList.size(); i++ )
        {
            query = "/v1/journeys/summary?q=startDateTime >="
                    + dataMapList.get( i ).get( "minStartDateTime" )
                    + " AND startDateTime <="
                    + dataMapList.get( i ).get( "endDate" );
            mockSmartJourneyService.createMockDataForSummary(
                    query,
                    journeyValueMapList,
                    dataMapList.get( 0 ).get( "smartjourneylink" ),
                    dataMapList.get( 0 ).get( "applicationContextPath" ) );
        }
        Thread.sleep( 1000 );
    }

    @Given( "^FinancialPeriods List Service is running$" )
    public void financialperiods_List_Service_is_running() throws Throwable
    {
        LOGGER.info( "UnlocatedJourneyStepDef >> FinancialPeriods List Service is running ::::::::::" );
    }

    @Given( "^JourneySummery  Service is running$" )
    public void journeysummery_Service_is_running() throws Throwable
    {
        LOGGER.info( "UnlocatedJourneyStepDef >> JourneySummery Service is running ::::::::::" );

    }

    @When( "^I make call to DashboarViewsService for \"(.*?)\" graphs$" )
    public void i_make_call_to_DashboarViewsService_for_graphs( String graphId ) throws Throwable
    {
        String query = "q=scheme.link=/schemes/scheme1 AND numberOfFinancialPeriods=1";
        target = apiClient
                .target( "http://" + API_HOST_NAME + ":" + apiHttpPort + "/" + DASH_BOARD_VIEWS_API_PATH + "/" )
                .path( graphId )
                .queryParam( "q", query );
        apiResponse = target.request().header( JWT_ASSERTION_HEADER, JWT_TOKEN_VALUE ).get();
        // dashboardViewResponse = apiResponse.readEntity( DashboardViewResponse.class );
        // this.dashboardView = dashboardViewResponse.getDashboardView();

    }

    @When( "^I make call to DashboarViewsService for \"(.*?)\" graphs with query \"(.*?)\"$" )
    public void i_make_call_to_DashboarViewsService_for_graphs_with_query( String graphId, String query )
            throws Throwable
    {
        target = apiClient
                .target( "http://" + API_HOST_NAME + ":" + apiHttpPort + "/" + DASH_BOARD_VIEWS_API_PATH + "/" )
                .path( graphId )
                .queryParam( "q", query );
        apiResponse = target.request().header( JWT_ASSERTION_HEADER, JWT_TOKEN_VALUE ).get();

        dashboardViewResponse = apiResponse.readEntity( DashboardViewResponse.class );
        Thread.sleep( 2000 );
        this.dashboardView = dashboardViewResponse.getDashboardView();
        Thread.sleep( 2000 );
    }

    @Then( "^api response for UNLINKEDJOURNEY Graph should be (\\d+)$" )
    public void api_response_for_UNLINKEDJOURNEY_Graph_should_be( int statusCode ) throws Throwable
    {
        Assert.assertEquals( statusCode, apiResponse.getStatus() );
    }

    @Then( "^List<GraphData> for UNLINKED_JOURNEYS should be returned with following properties as:$" )
    public void list_GraphData_for_UNLINKED_JOURNEYS_should_be_returned_with_following_properties_as(
            String expectedGraphData ) throws Throwable
    {
        LOGGER.info( "assertDashboardAPIResponse:: Assert dashboardView response against expected outcome" );
        JSONArray jsonArray = new JSONArray( expectedGraphData );

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure( DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false );
        // for ( int i = 0; i < jsonArray.length(); i++ )
        // {
        GraphDataPoint graphDataPointExpected = mapper
                .readValue( jsonArray.getJSONObject( 0 ).toString(), GraphDataPoint.class );

        Assert.assertTrue(
                new DVSIntegrationUtil()
                        .comparePointDataList( graphDataPointExpected, dashboardView.getGraphData().get( 0 ) ) );
        // }
        LOGGER.info( "assertDashboardAPIResponse:: Assert dashboardView response against expected outcome - Done!!!!" );
    }

}
