/**
 * Copyright 2015 Applied Card Technologies Ltd
 */
package net.weareact.jwt;

import java.security.KeyStore;
import java.security.KeyStoreException;

public interface KeyStoreProvider
{
    KeyStore getKeyStore( final String keyStorePath, final String password ) throws KeyStoreException;
}
