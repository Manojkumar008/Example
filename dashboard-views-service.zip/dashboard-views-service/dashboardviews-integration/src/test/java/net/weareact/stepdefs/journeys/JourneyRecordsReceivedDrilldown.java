package net.weareact.stepdefs.journeys;

import java.time.DayOfWeek;
import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.weareact.CucumberIT;
import net.weareact.api.impl.utils.DateUtils;
import net.weareact.app.DashboardViewsConfiguration;
import net.weareact.common.dropwizard.DropwizardUtil;
import net.weareact.journeys.model.GroupSummary;
import net.weareact.journeys.model.SummaryResponse;
import net.weareact.model.DashboardView;
import net.weareact.model.DashboardViewResponse;
import net.weareact.model.GraphDataPoint;
import net.weareact.model.PointData;
import net.weareact.model.ServiceError;
import net.weareact.utils.DVSIntegrationUtil;

public class JourneyRecordsReceivedDrilldown
{

    private static final Integer        PORT                      = 18080;
    private static final String         HOST_NAME                 = "localhost";
    private static final String         API_HOST_NAME             = "localhost";
    private static final String         DASH_BOARD_VIEWS_API_PATH = "v1/dashboard-views";
    private static final String         JWT_ASSERTION_HEADER      = "X-JWT-Assertion";

    private Response                    apiResponse;

    private DVSIntegrationUtil          iUtil                     = new DVSIntegrationUtil();
    private DashboardViewResponse       dashboardViewResponse;

    private DashboardViewsConfiguration configuration             = CucumberIT.RULE.getConfiguration();

    private int                         apiHttpPort               = DropwizardUtil
                                                                          .getApplicationHttpPort( configuration );

    private Client                      apiClient                 = ClientBuilder.newClient();
    private ServiceError                errorResponse;

    @Given( "^Journey Service has drilldown data for the following schemes for columnIndex \"(.*?)\" and timeFilter last (\\d+) \"(.*?)\":$" )
    public void journey_Service_has_drilldown_data_for_the_following_schemes_for_columnIndex_and_timeFilter_last(
            String colIndex,
            int num,
            String timeFilter,
            List<Map<String, String>> data ) throws Throwable
    {
        mockJourneySummary( colIndex, num, timeFilter, data, "" );
    }

    @Given( "^Journey Service has drilldown data for the following schemes for scheme filter \"(.*?)\" and columnIndex \"(.*?)\" and timeFilter last (\\d+) \"(.*?)\" :$" )
    public void journey_Service_has_drilldown_data_for_the_following_schemes_for_scheme_filter_and_columnIndex_and_timeFilter_last(
            String schemeFilter,
            String colIndex,
            int num,
            String timeFilter,
            List<Map<String, String>> data ) throws Throwable
    {
        mockJourneySummary( colIndex, num, timeFilter, data, schemeFilter );
    }

    @Given( "^Journey Service has history drillDown data for the following schemes for scheme filter \"(.*?)\" andcolumnIndex (\\d+) and timeFilter last (\\d+) \"(.*?)\" and rollBackNumber is (\\d+):$" )
    public void journey_Service_has_history_drillDown_data_for_the_following_schemes_for_scheme_filter_andcolumnIndex_and_timeFilter_last_and_rollBackNumber_is(
            String schemeFilter,
            int colIndex,
            int arg3,
            String timeFilter,
            int rollBackNumber,
            List<Map<String, String>> data ) throws Throwable
    {
        mockHistoryJourneySummary( colIndex, rollBackNumber, timeFilter, data, schemeFilter );

    }

    @Given( "^Journey Service has history drillDown data for the following schemes for columnIndex (\\d+) and timeFilter last (\\d+) \"(.*?)\" and rollBackNumber is (\\d+):$" )
    public void journey_Service_has_history_drillDown_data_for_the_following_schemes_for_columnIndex_and_timeFilter_last_and_rollBackNumber_is(
            int colIndex,
            int num,
            String timeFilter,
            int rollBackNumber,
            List<Map<String, String>> data ) throws Throwable
    {
        mockHistoryJourneySummary( colIndex, rollBackNumber, timeFilter, data, "" );
    }

    private void mockHistoryJourneySummary(
            int colIndex,
            int rollBackNumber,
            String timeFilter,
            List<Map<String, String>> data,
            String schemeFilter )
    {
        String startDate = "", endDate = "";
        ZonedDateTime currentDataEndDate = null, currentDataStartDate = null;
        ZonedDateTime averageDataEndDate = null, averageDataStartDate = null;
        GroupSummary summary = new GroupSummary();
        Map<String, GroupSummary> map = new HashMap<>();
        for ( int i = 0; i < data.size(); i++ )
        {
            GroupSummary groupSummary = new GroupSummary();
            groupSummary.setTotal( Integer.parseInt( data.get( i ).get( "total" ) ) );
            map.put( data.get( i ).get( "scheme.abbreviation" ), groupSummary );
        }
        summary.setSubGroups( map );

        SummaryResponse response = new SummaryResponse();
        response.setSummary( summary );

        ZonedDateTime today = ZonedDateTime.now();
        switch ( timeFilter )
        {
        case "days":
        {
            // ZonedDateTime zdt = ZonedDateTime.now().minusDays( 8 - colIndex );
            currentDataStartDate = today.minusDays( 8 - colIndex ).withHour( 00 ).withMinute( 00 ).withSecond( 00 );
            currentDataEndDate = today.minusDays( 8 - colIndex ).withHour( 23 ).withMinute( 59 ).withSecond( 59 );

            for ( int i = 1; i <= rollBackNumber; i++ )
            {
                averageDataStartDate = currentDataStartDate.minusDays( i * 7 );
                averageDataEndDate = currentDataEndDate.minusDays( i * 7 );

                startDate = DateUtils.converDateToStringwithTimeZero( averageDataStartDate );
                endDate = DateUtils.converDateToStringwithTimeMax( averageDataEndDate );

                putHistoryJourney( startDate, endDate, schemeFilter, response );
            }

            break;
        }
        case "weeks":
        {
            currentDataEndDate = today
                    .minusWeeks( 8 - colIndex )
                    .with( DayOfWeek.SUNDAY )
                    .withHour( 23 )
                    .withMinute( 59 )
                    .withSecond( 59 );
            currentDataStartDate = currentDataEndDate.minusDays( 6 ).withHour( 00 ).withMinute( 00 ).withSecond( 00 );

            averageDataStartDate = currentDataStartDate.minusWeeks( rollBackNumber );
            averageDataEndDate = currentDataStartDate.minusSeconds( 1 );
            startDate = DateUtils.converDateToStringwithTimeZero( averageDataStartDate );
            endDate = DateUtils.converDateToStringwithTimeMax( averageDataEndDate );
            putHistoryJourney( startDate, endDate, schemeFilter, response );
        }

        case "months":
            ZonedDateTime month = today.minusMonths( 8 - colIndex );
            currentDataEndDate = month
                    .withDayOfMonth( month.getMonth().maxLength() )
                    .withHour( 23 )
                    .withMinute( 59 )
                    .withSecond( 59 );
            // currentDataStartDate = currentDataEndDate.minusMonths( month.getMonth().maxLength() - 1 );
            currentDataStartDate = currentDataEndDate
                    .withDayOfMonth( 1 )
                    .withHour( 00 )
                    .withMinute( 00 )
                    .withSecond( 00 );

            averageDataStartDate = currentDataStartDate.minusMonths( rollBackNumber );
            averageDataEndDate = currentDataStartDate.minusSeconds( 1 );
            startDate = DateUtils.converDateToStringwithTimeZero( averageDataStartDate );
            endDate = DateUtils.converDateToStringwithTimeMax( averageDataEndDate );
            putHistoryJourney( startDate, endDate, schemeFilter, response );

            break;
        }
    }

    private void putHistoryJourney( String startDate, String endDate, String schemeFilter, SummaryResponse response )
    {
        String query = "/v1/journeys/summary?q=created>="
                + startDate
                + " AND created<="
                + endDate
                + ( StringUtils.isNotBlank( schemeFilter ) ? " AND " + schemeFilter : "" )
                + "&grouping=scheme.abbreviation";
        Client client = ClientBuilder.newClient();
        client
                .target( "http://" + HOST_NAME + ":" + PORT )
                .path( "/mock/responses" )
                .queryParam( "apiPath", query )
                .request()
                .put( Entity.entity( response, MediaType.APPLICATION_JSON ) );

    }

    private void mockJourneySummary(
            String colIndex,
            int num,
            String timeFilter,
            List<Map<String, String>> data,
            String schemeFilter )
    {
        String startDate = "", endDate = "";
        GroupSummary summary = new GroupSummary();
        Map<String, GroupSummary> map = new HashMap<>();
        for ( int i = 0; i < data.size(); i++ )
        {
            GroupSummary groupSummary = new GroupSummary();
            groupSummary.setTotal( Integer.parseInt( data.get( i ).get( "total" ) ) );
            map.put( data.get( i ).get( "scheme.abbreviation" ), groupSummary );
        }
        summary.setSubGroups( map );

        SummaryResponse response = new SummaryResponse();
        response.setSummary( summary );

        switch ( timeFilter )
        {
        case "days":
        {
            ZonedDateTime zdt = ZonedDateTime.now().minusDays( 8 - Integer.parseInt( colIndex ) );
            startDate = DateUtils.converDateToStringwithTimeZero( zdt );
            endDate = DateUtils.converDateToStringwithTimeMax( zdt );

            break;
        }
        case "weeks":
        {
            ZonedDateTime zdt = ZonedDateTime
                    .now()
                    .minusWeeks( 8 - Integer.parseInt( colIndex ) )
                    .with( DayOfWeek.MONDAY );
            startDate = DateUtils.converDateToStringwithTimeZero( zdt );
            zdt = zdt.plusDays( 6 );
            endDate = DateUtils.converDateToStringwithTimeMax( zdt );
            break;
        }
        case "months":
        {
            ZonedDateTime zdt = ZonedDateTime.now().minusMonths( 8 - Integer.parseInt( colIndex ) ).withDayOfMonth( 1 );
            startDate = DateUtils.converDateToStringwithTimeZero( zdt );
            zdt = zdt.withDayOfMonth( zdt.getMonth().maxLength() );
            endDate = DateUtils.converDateToStringwithTimeMax( zdt );
            break;
        }
        }
        printSummaryInJsonFormat( response );
        String query = "/v1/journeys/summary?q=created>="
                + startDate
                + " AND created<="
                + endDate
                + ( StringUtils.isNotBlank( schemeFilter ) ? " AND " + schemeFilter : "" )
                + "&grouping=scheme.abbreviation";
        Client client = ClientBuilder.newClient();
        client
                .target( "http://" + HOST_NAME + ":" + PORT )
                .path( "/mock/responses" )
                .queryParam( "apiPath", query )
                .request()
                .put( Entity.entity( response, MediaType.APPLICATION_JSON ) );
    }

    @Then( "^Response status should be (\\d+)$" )
    public void response_status_should_be( int arg1 ) throws Throwable
    {
        dashboardViewResponse = apiResponse.readEntity( DashboardViewResponse.class );
        Assert.assertEquals( arg1, apiResponse.getStatus() );
    }

    @Then( "^Response should have following data for \"(.*?)\" legend$" )
    public void response_should_have_following_data_for_legend( String arg1, List<Map<String, String>> data )
            throws Throwable
    {
        DashboardView view = dashboardViewResponse.getDashboardView();
        GraphDataPoint graphData = null;
        if ( arg1.equals( "current" ) )
        {
            graphData = view.getGraphData().get( 0 );
        }
        else
        {
            graphData = view.getGraphData().get( 1 );

        }

        System.out.println( "dashboardViewResponse" + dashboardViewResponse );
        Assert.assertEquals( data.size(), graphData.getDataPointValues().size() );
        int counter = 0;
        for ( Iterator<Map<String, String>> iterator = data.iterator(); iterator.hasNext(); )
        {
            Map<String, String> map = iterator.next();
            PointData pd = graphData.getDataPointValues().get( counter++ );

            Assert.assertEquals( map.get( "pointKey" ), pd.getPointKey().get( "en" ) );
            Assert.assertEquals( map.get( "pointValue" ), pd.getPointValue().toString() );
            Assert.assertEquals( map.get( "pointLegend" ), pd.getPointLegend().get( "en" ) );

        }

    }

    @When( "^DashboardViews service is called to get data for \"(.*?)\" graph with query \"(.*?)\"$" )
    public void dashboardviews_service_is_called_to_get_data_for_graph_with_query( String graphID, String q )
            throws Throwable
    {
        WebTarget target = apiClient.target(
                "http://" + API_HOST_NAME + ":" + apiHttpPort + "/" + DASH_BOARD_VIEWS_API_PATH + "/" + graphID );

        target = target.queryParam( "q", q );

        apiResponse = target.request().header( JWT_ASSERTION_HEADER, iUtil.getJWT_TOKEN_VALUE() ).get();

    }

    @Then( "^Error Response status should be (\\d+)$" )
    public void error_Response_status_should_be( int arg1 ) throws Throwable
    {
        errorResponse = apiResponse.readEntity( ServiceError.class );
        Assert.assertEquals( arg1, apiResponse.getStatus() );
    }

    @Then( "^Response should have following data$" )
    public void response_should_have_following_data( List<String> data ) throws Throwable
    {
        Assert.assertEquals( data.get( 0 ), errorResponse.getErrorCode() );
        Assert.assertEquals( data.get( 1 ), errorResponse.getUserMessage() );
    }

    public void printSummaryInJsonFormat( SummaryResponse response )
    {
        ObjectMapper mapper = new ObjectMapper();
        try
        {
            System.out.println( mapper.writeValueAsString( response ) );
        }
        catch ( JsonProcessingException e )
        {
            e.printStackTrace();
        }

    }
}
