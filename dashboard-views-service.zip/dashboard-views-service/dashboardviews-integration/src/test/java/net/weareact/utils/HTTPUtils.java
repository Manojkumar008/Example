/**
 * Copyright 2015 Applied Card Technologies Ltd
 */
package net.weareact.utils;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import net.weareact.common.util.RestUtils;

/**
 *
 * @author dstorey
 */
public class HTTPUtils
{
    private static final Pattern PATTERN_URL_QUERY_PARAMETERS = Pattern.compile( "(?:\\?|\\&)([^\\=]+)\\=([^\\&]+)" );

    /**
     * Performs an HTTP request.
     *
     * @param requestMethod
     *            HTTP verb
     * @param port
     *            Host port
     * @param path
     *            Resource path
     * @param jwt
     *            Java Web Token
     * @return The response
     */
    public static Response connect( final String requestMethod, final int port, final String path, final String jwt )
    {
        return connect( requestMethod, port, path, null, null, jwt );
    }

    /**
     * Performs an HTTP request.
     *
     * @param requestMethod
     *            HTTP verb
     * @param port
     *            Host port
     * @param path
     *            Resource path
     * @param data
     *            Entity data
     * @param contentType
     * @param jwt
     *            Java Web Token
     * @return The response
     */
    public static Response connect(
            final String requestMethod,
            final int port,
            final String path,
            final Object data,
            final String contentType,
            final String jwt,
            final Map.Entry<String, String>... headers )
    {
        String encodedPath = null;

        try
        {
            encodedPath = encodeUrl( path );
        }
        catch ( UnsupportedEncodingException ex )
        {
            throw new RuntimeException( ex );
        }

        final WebTarget webTarget = RestUtils.getWebTarget( encodedPath, port );

        Invocation.Builder request = webTarget.request();

        if ( jwt != null )
        {
            request = request.header( "X-JWT-Assertion", jwt );
        }

        for ( final Map.Entry<String, String> entry : headers )
        {
            request = request.header( entry.getKey(), entry.getValue() );
        }

        switch ( requestMethod.toUpperCase() )
        {
        case "GET":
            return request.get();
        case "POST":
            return request.post( Entity.entity( data, contentType ) );
        case "PUT":
            return request.put( Entity.entity( data, contentType ) );
        case "PATCH":
            return request.method( "PATCH", Entity.entity( data, contentType ) );
        case "DELETE":
            return request.delete();
        default:
            throw new IllegalArgumentException( String.format( "Unknown request method %s", requestMethod ) );
        }
    }

    private static String encodeUrl( final String url ) throws UnsupportedEncodingException
    {
        final StringBuffer urlBuffer = new StringBuffer( url );

        final Matcher matcher = PATTERN_URL_QUERY_PARAMETERS.matcher( url );

        while ( matcher.find() )
        {
            urlBuffer.replace( matcher.start( 1 ), matcher.end( 1 ), URLEncoder.encode( matcher.group( 1 ), "UTF-8" ) );
            urlBuffer.replace( matcher.start( 2 ), matcher.end( 2 ), URLEncoder.encode( matcher.group( 2 ), "UTF-8" ) );
        }

        return urlBuffer.toString();
    }
}
