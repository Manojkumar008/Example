package net.weareact.drilldown.stepdefs;

import java.security.KeyStore;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.weareact.app.mock.MockDistributionListService;
import net.weareact.dashboardview.model.DistributionList.TypeEnum;
import net.weareact.jwt.JKSKeyStoreProvider;
import net.weareact.jwt.JWTBuilder;
import net.weareact.jwt.JWTBuilderRSA;
import net.weareact.model.DashboardView;
import net.weareact.model.DashboardViewResponse;
import net.weareact.model.GraphDataPoint;
import net.weareact.utils.DVSIntegrationUtil;

public class HotListGenerationDrillDownStepDefs
{

    private Client                apiClient                 = ClientBuilder.newClient();
    private WebTarget             target;
    private Response              apiResponse;

    private static final String   API_HOST_NAME             = "localhost";
    private static final String   DASH_BOARD_VIEWS_API_PATH = "v1/dashboard-views";
    private static final String   JWT_ASSERTION_HEADER      = "X-JWT-Assertion";
    private static String         JWT_TOKEN_VALUE           = "eyJ0eXAiOiJKV1QiLCJ4NXQiOiJNbU15WW1GaVltRTNPV1U0TjJObE5tSmpNVEF4TVdFNE9UY3dNR0V6TnpZMVpHWTNOamN3TnciLCJhbGciOiJSUzI1NiJ9.eyJzY2hlbWVzIjpbeyJhYmJyZXZpYXRpb24iOiJBQ1QxIiwibGluayI6InNjaGVtZXMvMSJ9LHsiYWJicmV2aWF0aW9uIjoiQUNUMiIsImxpbmsiOiJzY2hlbWVzLzIifSx7ImFiYnJldmlhdGlvbiI6IkFDVDMiLCJsaW5rIjoic2NoZW1lcy8zIn0seyJhYmJyZXZpYXRpb24iOiJBQ1Q0IiwibGluayI6InNjaGVtZXMvNCJ9XSwic2NvcGVzIjpbXSwib3JnYW5pc2F0aW9uIjp7fSwiZXhwIjoiOTIyMzM3MjAzNjg1NDc3NTgwNyJ9.Y5w7egYWGuBpmzHEoaQpRw7fZOu1BK5MwfoH_rO0njXQx4OsMYZw7tWnB3vNRO2JKjgT__w9VgY49Mq_J1heuvGVVNgZDxzORWpZUeh2MuzmY1ME6IEhe9-2R1J3SWoj8hJrnjB_ypfNI9W4QNUSwUVoyfNx77boH20Y8akUr8M38vTwI7E5qTVZ_JRjnUIpDV-Bi3bADfNyLo9c_r-ywcsNpeoyTivsI_iIHWbuKl5U0JKtCWmYHmfR-oKR9rwW5AGtKr5i6ap5jJWFxIfre-ffp8DPxxy7NsRIzk6r214fEgNVJvq-QgPobgy-iI9sGt21MDFahBd-SaEBn_IbPg";

    private static Integer        apiHttpPort               = 18090;

    private DashboardViewResponse dashboardViewResponse;
    private DashboardView         dashboardView;

    private static final String   KEYSTORE_PATH             = "src/test/resources/keystore/actdev.jks";

    private static final String   KEYSTORE_PASSWORD         = "actdev";

    private static final String   KEYSTORE_ALIAS            = "wso2am.local";

    private static final Logger   LOGGER                    = LoggerFactory
                                                                    .getLogger(
                                                                            HotListGenerationDrillDownStepDefs.class
                                                                                    .getName() );

    @Given( "^that I mock \"(.*?)\" objects for \"(.*?)\" graph$" )
    public void that_I_mock_objects_for_graph( final String type, final String graphId, final DataTable dataTable )
            throws Throwable
    {
        List<Map<String, String>> dataMapList = dataTable.asMaps( String.class, String.class );
        MockDistributionListService dlService = new MockDistributionListService();
        dlService.createAndMockDistributionList(
                dataMapList,
                TypeEnum.valueOf( type ),
                graphId,
                null,
                true,
                false,
                0L,
                0L,
                0L );
    }

    @Given( "^that I mock \"(.*?)\" objects for \"(.*?)\" graph at the endpoint \"(.*?)\" with following properties:$" )
    public void that_I_mock_objects_for_graph_at_the_endpoint_with_following_properties(
            final String type,
            final String graphId,
            final String q,
            final DataTable dataTable ) throws Throwable
    {
        List<Map<String, String>> dataMapList = dataTable.asMaps( String.class, String.class );
        MockDistributionListService dlService = new MockDistributionListService();
        dlService.createAndMockDistributionList(
                dataMapList,
                TypeEnum.valueOf( type ),
                graphId,
                q,
                true,
                false,
                0L,
                0L,
                0L );
    }

    @Given( "^User has access to below schemes:$" )
    public void mockJWTToken( final DataTable arg1 ) throws Throwable
    {
        final List<Map<String, String>> data = arg1.asMaps( String.class, String.class );
        final KeyStore keyStore = new JKSKeyStoreProvider().getKeyStore( KEYSTORE_PATH, KEYSTORE_PASSWORD );
        JWTBuilder builder = new JWTBuilderRSA( keyStore, KEYSTORE_PASSWORD, KEYSTORE_ALIAS );
        for ( Map<String, String> row : data )
        {
            builder = builder.addProperty(
                    row.get( "name" ),
                    row.get( "value" ),
                    Boolean.parseBoolean( row.get( "array" ) ),
                    Boolean.parseBoolean( row.get( "json" ) ) );

        }
        JWT_TOKEN_VALUE = builder.build();

        LOGGER.info( " Method::mockJWTToken >> Value is - " + JWT_TOKEN_VALUE );
    }

    @Then( "^List<GraphData> for HotList Generation should be returned with following properties as:$" )
    public void list_GraphData_for_HotList_Generation_should_be_returned_with_following_properties_as(
            final String expectedGraphData ) throws Throwable
    {
        LOGGER.info( "assertDashboardAPIResponse:: Assert dashboardView response against expected outcome" );
        JSONArray jsonArray = new JSONArray( expectedGraphData );

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure( DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false );
        // for ( int i = 0; i < jsonArray.length(); i++ )
        // {
        GraphDataPoint graphDataPointExpected = mapper
                .readValue( jsonArray.getJSONObject( 0 ).toString(), GraphDataPoint.class );

        Assert.assertTrue(
                new DVSIntegrationUtil()
                        .comparePointDataList( graphDataPointExpected, dashboardView.getGraphData().get( 0 ) ) );
        // }
        LOGGER.info( "assertDashboardAPIResponse:: Assert dashboardView response against expected outcome - Done!!!!" );
    }

    @Then( "^api response for HotListGenerationDrillDown Graph should be (\\d+)$" )
    public void api_response_for_HotListGenerationDrillDown_Graph_should_be( final int statusCode ) throws Throwable
    {
        Assert.assertEquals( statusCode, apiResponse.getStatus() );
    }

    @When( "^I make call to DashboarViewsService for \"(.*?)\" graph$" )
    public void i_make_call_to_DashboarViewsService_for_graph( final String graphId ) throws Throwable
    {
        target = apiClient
                .target( "http://" + API_HOST_NAME + ":" + apiHttpPort + "/" + DASH_BOARD_VIEWS_API_PATH + "/" )
                .path( graphId );
        apiResponse = target.request().header( JWT_ASSERTION_HEADER, JWT_TOKEN_VALUE ).get();
        // dashboardViewResponse = apiResponse.readEntity( DashboardViewResponse.class );
        // this.dashboardView = dashboardViewResponse.getDashboardView();
    }

    @When( "^I make call to DashboarViewsService for \"(.*?)\" graph with following properties:$" )
    public void i_make_call_to_DashboarViewsService_for_graph_with_following_properties(
            final String graphId,
            final DataTable dataTable ) throws Throwable
    {
        Map<String, String> dataMap = dataTable.asMap( String.class, String.class );
        String query = "startDate>="
                + dataMap.get( "startdate" )
                + " AND endDate<="
                + dataMap.get( "enddate" )
                + " AND time="
                + dataMap.get( "time" );

        if ( dataMap.get( "scheme" ) != null && !dataMap.get( "scheme" ).isEmpty() )
        {
            query = query + " AND scheme.link IN(" + dataMap.get( "scheme" ) + ")";

        }

        target = apiClient
                .target( "http://" + API_HOST_NAME + ":" + apiHttpPort + "/" + DASH_BOARD_VIEWS_API_PATH + "/" )
                .path( graphId )
                .queryParam( "q", query );
        apiResponse = target.request().header( JWT_ASSERTION_HEADER, JWT_TOKEN_VALUE ).get();
        dashboardViewResponse = apiResponse.readEntity( DashboardViewResponse.class );
        Thread.sleep( 2000 );
        this.dashboardView = dashboardViewResponse.getDashboardView();
        Thread.sleep( 2000 );
    }

    @Given( "^that I mock \"(.*?)\" objects for \"(.*?)\" graph at the endpoint \"(.*?)\"  with following properties and limit as (\\d+):$" )
    public void that_I_mock_objects_for_graph_at_the_endpoint_with_following_properties_and_limit_as(
            final String type,
            final String graphid,
            final String q,
            final int limit,
            final DataTable dataTable ) throws Throwable
    {
        List<Map<String, String>> dataMapList = dataTable.asMaps( String.class, String.class );
        List<Map<String, String>> tempMap = new ArrayList<>();
        tempMap.add( dataMapList.get( 0 ) );
        tempMap.add( dataMapList.get( 1 ) );
        tempMap.add( dataMapList.get( 2 ) );
        tempMap.add( dataMapList.get( 3 ) );
        MockDistributionListService dlService = new MockDistributionListService();
        dlService.createAndMockDistributionList(
                dataMapList,
                TypeEnum.valueOf( type ),
                graphid,
                q,
                true,
                true,
                Long.valueOf( limit ),
                0L,
                Long.valueOf( dataMapList.size() ) );

        tempMap = new ArrayList<>();

        tempMap.add( dataMapList.get( 4 ) );
        tempMap.add( dataMapList.get( 5 ) );
        tempMap.add( dataMapList.get( 6 ) );
        tempMap.add( dataMapList.get( 7 ) );
        dlService.createAndMockDistributionList(
                dataMapList,
                TypeEnum.valueOf( type ),
                graphid,
                q,
                true,
                true,
                Long.valueOf( limit ),
                1 * Long.valueOf( limit ),
                Long.valueOf( dataMapList.size() ) );

        tempMap = new ArrayList<>();

        tempMap.add( dataMapList.get( 8 ) );
        tempMap.add( dataMapList.get( 9 ) );
        tempMap.add( dataMapList.get( 10 ) );
        tempMap.add( dataMapList.get( 11 ) );

        dlService.createAndMockDistributionList(
                dataMapList,
                TypeEnum.valueOf( type ),
                graphid,
                q,
                true,
                true,
                Long.valueOf( limit ),
                2 * Long.valueOf( limit ),
                Long.valueOf( dataMapList.size() ) );
        tempMap = new ArrayList<>();

        tempMap.add( dataMapList.get( 12 ) );
        tempMap.add( dataMapList.get( 13 ) );
        tempMap.add( dataMapList.get( 14 ) );
        tempMap.add( dataMapList.get( 15 ) );
        dlService.createAndMockDistributionList(
                dataMapList,
                TypeEnum.valueOf( type ),
                graphid,
                q,
                true,
                true,
                Long.valueOf( limit ),
                3 * Long.valueOf( limit ),
                Long.valueOf( dataMapList.size() ) );

    }

}
