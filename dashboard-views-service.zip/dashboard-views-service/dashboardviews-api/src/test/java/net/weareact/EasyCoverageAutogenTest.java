/* **************************************************************************
 *             Copyright 2015 Applied Card Technologies Ltd
 ****************************************************************************/
package net.weareact;

import org.junit.Test;
import org.reflections.Reflections;
import org.reflections.scanners.SubTypesScanner;

import com.tocea.easycoverage.framework.checkers.ArrayIndexOutOfBoundExceptionChecker;
import com.tocea.easycoverage.framework.checkers.BijectiveCompareToChecker;
import com.tocea.easycoverage.framework.checkers.BijectiveEqualsChecker;
import com.tocea.easycoverage.framework.checkers.CloneChecker;
import com.tocea.easycoverage.framework.checkers.NPEConstructorChecker;
import com.tocea.easycoverage.framework.checkers.NPEMethodChecker;
import com.tocea.easycoverage.framework.checkers.NullValueEqualsChecker;
import com.tocea.easycoverage.framework.checkers.SetterChecker;
import com.tocea.easycoverage.framework.checkers.SynchronizedChecker;
import com.tocea.easycoverage.framework.checkers.ToStringNotNullChecker;
import com.tocea.easycoverage.framework.junit.JUnitTestSuiteProvider;

import junit.framework.TestSuite;
import net.weareact.common.util.easycoverage.DeepEqualsChecker;
import net.weareact.common.util.easycoverage.HashCodeChecker;

/**
 * @author {{actHeaderAuthor}}
 */
public final class EasyCoverageAutogenTest
{
    private JUnitTestSuiteProvider tsp;

    /**
     * Hidden Constructor.
     */
    private EasyCoverageAutogenTest()
    {
    }

    /**
     * @return Auto generated test suite for model package.
     */
    @Test
    public static TestSuite suite() throws Exception
    {
        EasyCoverageAutogenTest ecModel = new EasyCoverageAutogenTest();

        return ecModel.createTestSuite();
    }

    /**
     * @return Auto generated test suite for model package.
     */
    private TestSuite createTestSuite() throws Exception
    {
        tsp = new JUnitTestSuiteProvider();

        addPackage( "net.weareact.model" );

        tsp.addClassChecker( BijectiveCompareToChecker.class );
        tsp.addClassChecker( BijectiveEqualsChecker.class );
        tsp.addClassChecker( DeepEqualsChecker.class );
        tsp.addClassChecker( CloneChecker.class );
        tsp.addClassChecker( NPEConstructorChecker.class );
        tsp.addClassChecker( NullValueEqualsChecker.class );
        tsp.addClassChecker( SynchronizedChecker.class );
        tsp.addClassChecker( ToStringNotNullChecker.class );
        tsp.addClassChecker( HashCodeChecker.class );

        tsp.addMethodChecker( ArrayIndexOutOfBoundExceptionChecker.class );
        tsp.addMethodChecker( NPEMethodChecker.class );
        tsp.addMethodChecker( SetterChecker.class );

        return tsp.getTestSuite();
    }

    /**
     * @param pkg
     *            Name of package to add
     */
    private void addPackage( final String pkg )
    {
        Reflections refl = new Reflections( pkg, new SubTypesScanner( false ) );
        refl.getSubTypesOf( Object.class ).forEach( tsp::addClass );
    }
}
