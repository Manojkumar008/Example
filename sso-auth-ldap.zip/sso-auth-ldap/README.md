[![Build Status](https://travis-ci.org/malike/sso-auth-ldap.svg?branch=master)](https://travis-ci.org/malike/sso-auth-ldap)

# sso-auth-ldap

If you read this [Using Spring Security OAuth 2.0 and MongoDB For Single Sign Authentication Server](http://malike.github.io/Spring-Security-OAuth2/).
This is just building on it to get a single sign on microservice with LDAP integration.

The main focus of this is explore the functionality of AuthenticationProvider in Spring Security

Read more [here](http://malike.github.io/Spring-Security-OAuth2-With-LDAP/). 

You can use the client service I wrote to test this. The major changes worked on in this project are in
the auth-server. Which now supports LDAP for authentication.
